DECLARE @missedRecord INT, @tablename VARCHAR(100), @FromDB VARCHAR(100), @ToDB VARCHAR(100)
,@FromCompanyId INT, @ToCompanyId INT
,@moveid INT = 905

DECLARE @qry VARCHAR(MAX)
-- check whether fromId missed
SET @tablename = 'RT'
SELECT @FromDB = FromDB, @ToDB = ToDB, @FromCompanyId = FromCompany, @ToCompanyId = ToCompany FROM v3_Common.dbo.MoveFlag WHERE MoveId = @moveid

SET @qry = '
set nocount on
update ' +@ToDB +'.dbo.Mapping
set [ToCompany] = ''' + convert(varchar(100), @ToCompanyId) + '''
where tablename is not null
and FromCompany =  ''' + convert(varchar(100), @FromCompanyId) + '''

'
EXEC (@qry)

--SELECT @FromDB, @ToDB,@tablename,@FromCompanyId
SET @qry = '
set nocount on
SELECT ''Missing the following Requesttype from the source company '' , rt.RequestTypeid, rt.companyid FROM ' + @FromDB+'.dbo.RequestType rt LEFT OUTER JOIN 
 ' +@ToDB +'.dbo.Mapping mp on rt.RequestTypeId = mp.FromId
 and mp.tablename = '''+@tablename + '''
 where mp.fromId is null
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '

 EXECUTE (@qry)

 SET @tablename = 'Trade'

SET @qry = '
set nocount on
SELECT ''Missing the following Trade from the source company '' , rt.Tradeid, rt.companyid FROM ' + @FromDB+'.dbo.Trade rt LEFT OUTER JOIN 
 ' +@ToDB +'.dbo.Mapping mp on rt.TradeId = mp.FromId
 and mp.tablename = '''+@tablename + '''
 where mp.fromId is null
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 
 EXECUTE (@qry)

  
 SET @tablename = 'EquipmentClass'

SET @qry = '
set nocount on
SELECT ''Missing the following EquipmentClass from the source company '' , rt.EquipmentClassid, rt.companyid FROM ' + @FromDB+'.dbo.EquipmentClass rt LEFT OUTER JOIN 
 ' +@ToDB +'.dbo.Mapping mp on rt.EquipmentClassId = mp.FromId
 and mp.tablename = '''+@tablename + '''
 where mp.fromId is null
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 EXECUTE (@qry)

 
 SET @tablename = 'CommunicationType'

SET @qry = '
set nocount on
SELECT ''Missing the following CommunicationType from the source company '' , rt.CommunicationTypeid, rt.companyid FROM ' + @FromDB+'.dbo.CommunicationType rt LEFT OUTER JOIN 
 ' +@ToDB +'.dbo.Mapping mp on rt.CommunicationTypeId = mp.FromId
 and mp.tablename = '''+@tablename + '''
 where mp.fromId is null
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 ' 
 EXECUTE (@qry)

 
 SET @tablename = 'ResourceType'

SET @qry = '
set nocount on
SELECT ''Missing the following ResourceType from the source company '' , rt.ResourceTypeid, rt.companyid FROM ' + @FromDB+'.dbo.ResourceType rt LEFT OUTER JOIN 
 ' +@ToDB +'.dbo.Mapping mp on rt.ResourceTypeId = mp.FromId
 and mp.tablename = '''+@tablename + '''
 where mp.fromId is null
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 EXECUTE (@qry)

 SET @tablename = 'Category'

SET @qry = '
set nocount on
SELECT ''Missing the following Category from the source company '' , rt.Categoryid, rt.companyid FROM ' + @FromDB+'.dbo.FileDocumentCategory rt LEFT OUTER JOIN 
 ' +@ToDB +'.dbo.Mapping mp on rt.CategoryId = mp.FromId
 and mp.tablename = '''+@tablename + '''
 where mp.fromId is null
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 EXECUTE (@qry)

 
 SET @tablename = 'Task'

SET @qry = '
set nocount on
SELECT ''Missing the following assement Task from the source company '' , rt.Taskid, rt.companyid FROM ' + @FromDB+'.dbo.Task rt LEFT OUTER JOIN 
 ' +@ToDB +'.dbo.Mapping mp on rt.TaskId = mp.FromId
 and mp.tablename = '''+@tablename + '''
 where mp.fromId is null
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
  and rt.IsAssessmentTask =1
  and rt.PropertyId = 0
 '
 
 EXECUTE (@qry)

 ------------------------------verify NewID

 SET @tablename = 'RequestType'
 
--SELECT @ToDB, @ToDB,@tablename,@ToCompanyID
SET @qry = '
set nocount on
SELECT ''The following Requesttype from the destination company does not exist'' , mp.[newid], mp.Tocompany FROM ' + @ToDB+'.dbo.RequestType rt Right Outer Join 
 ' +@ToDB +'.dbo.Mapping mp on rt.RequestTypeId = mp.[newid]
 and mp.tablename = '''+@tablename + '''
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@ToCompanyID) + '''
  
 where rt.RequestTypeid is null
 
   and mp.tablename = ''' + @tablename + '''
   and mp.FromCompany = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 PRINT (@qry)
 EXECUTE (@qry)

 SET @tablename = 'Trade'

--SELECT @ToDB, @ToDB,@tablename,@ToCompanyID
SET @qry = '
set nocount on
SELECT ''The following Trade from the destination company does not exist'' , mp.[newid], mp.Tocompany FROM ' + @ToDB+'.dbo.Trade rt Right Outer Join 
 ' +@ToDB +'.dbo.Mapping mp on rt.TradeId = mp.[newid]
 and mp.tablename = '''+@tablename + '''
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@ToCompanyID) + '''
 where rt.Tradeid is null
 
   and mp.tablename = ''' + @tablename + '''
   and mp.FromCompany = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 PRINT (@qry)
 EXECUTE (@qry)

 
 SET @tablename = 'EquipmentClass'

 SET @qry = '
set nocount on
SELECT ''The following Equipmentclass from the destination company does not exist'' , mp.[newid], mp.Tocompany FROM ' + @ToDB+'.dbo.Equipmentclass rt Right Outer Join 
 ' +@ToDB +'.dbo.Mapping mp on rt.EquipmentclassId = mp.[newid]
 and mp.tablename = '''+@tablename + '''
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@ToCompanyID) + '''
 where rt.Equipmentclassid is null
 
   and mp.tablename = ''' + @tablename + '''
   and mp.FromCompany = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 EXECUTE (@qry)

 set @tablename = 'CommunicationType'


 SET @qry = '
set nocount on
SELECT ''The following CommunicationType from the destination company does not exist'' , mp.[newid], mp.Tocompany FROM ' + @ToDB+'.dbo.CommunicationType rt Right Outer Join 
 ' +@ToDB +'.dbo.Mapping mp on rt.CommunicationTypeId = mp.[newid]
 and mp.tablename = '''+@tablename + '''
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@ToCompanyID) + '''
 where rt.CommunicationTypeid is null
 
   and mp.tablename = ''' + @tablename + '''
   and mp.FromCompany = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 EXECUTE (@qry)

 
 SET @tablename = 'ResourceType'

 
SET @qry = '
set nocount on
SELECT ''The following Resourcetype from the destination company does not exist'' , mp.[newid], mp.Tocompany FROM ' + @ToDB+'.dbo.ResourceType rt Right Outer Join 
 ' +@ToDB +'.dbo.Mapping mp on rt.ResourceTypeId = mp.[newid]
 and mp.tablename = '''+@tablename + '''
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@ToCompanyID) + '''
 where rt.ResourceTypeid is null
 
   and mp.tablename = ''' + @tablename + '''
   and mp.FromCompany = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 EXECUTE (@qry)

 
 SET @tablename = 'Category'

SET @qry = '
set nocount on
SELECT ''The following Category from the destination company does not exist'' , mp.[newid], mp.Tocompany FROM ' + @ToDB+'.dbo.FileDocumentCategory rt Right Outer Join 
 ' +@ToDB +'.dbo.Mapping mp on rt.CategoryId = mp.[newid]
 and mp.tablename = '''+@tablename + '''
  AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@ToCompanyID) + '''
 where rt.Categoryid is null
 
   and mp.tablename = ''' + @tablename + '''
   and mp.FromCompany = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
 '
 
 EXECUTE (@qry)

 
 SET @tablename = 'Task'
 SET @qry = '
 set nocount on
SELECT ''Missing the following assement Task from the destination company '' , mp.[newid], mp.Tocompany FROM ' + @ToDB+'.dbo.Task rt Right Outer Join 
 ' +@ToDB +'.dbo.Mapping mp on rt.TaskId = mp.[newid]
 and mp.tablename = '''+@tablename + '''
 AND rt.CompanyId = ''' + CONVERT(VARCHAR(100),@ToCompanyID) + '''
 and rt.IsAssessmentTask =1
  and rt.PropertyId = 0
 where rt.taskid is null
    and mp.tablename = ''' + @tablename + '''
	and mp.FromCompany = ''' + CONVERT(VARCHAR(100),@FromCompanyId) + '''
  
 '
 
EXECUTE (@qry)