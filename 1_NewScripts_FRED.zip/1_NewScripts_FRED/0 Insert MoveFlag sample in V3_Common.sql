use v3_Common
go
select * from dbo.MoveFlag with (nolock) order by 1 desc
go
/*
select count(*) from v3Trizec..Workorder w --65636
join v3Trizec.dbo.Building b on b.BuildingId = w.BuildingId
where b.PropertyId in (14053)
go
select * from v3Trizec.dbo.Property where PropertyId in (14053)     -- !!!!! MAKE SURE TO RUN !!!  Property MUST be ACTIVE!!!!!!!
select * from v3Trizec.dbo.VendorTypeProperty where PropertyId in (14053)

insert dbo.MoveFlag(
    MoveId
    , FromServer
    , FromDB
    , ToDB
    , FromCompany
    , ToCompany
    , FromProperty
    , DoTR
    , DoPM
    , ResetDevice
    , ResetContactEmail
    , MoveName
    , IsMoved
    , IsRollback
    , DateEntered
    , DateCompleted
    , DoCOI
    , DoSurvey
    , DoDoc
    , DocFileDoc
    , DoACS
)
values(
    905                     -- MoveId - int
    , '[Bear\PG1]'               -- FromServer - varchar(20)
    , 'v3Trizec'             -- FromDB - varchar(20)
    , 'v3Carter'             -- ToDB - varchar(20)
    , '5023'                 -- FromCompany - varchar(20)
    , '1040'            -- ToCompany - varchar(20)
    , '(14053)'               -- FromProperty - varchar(2000)
    , '1'                    -- DoTR - varchar(2)
    , '1'                    -- DoPM - varchar(2)
    , '0'                    -- ResetDevice - varchar(2)
    , '0'                    -- ResetContactEmail - varchar(2)
    , 'MiamiCenter'           -- MoveName - varchar(50)
    , 0                      -- IsMoved - int
    , 0                      -- IsRollback - int
    , ''                     -- DateEntered - smalldatetime
    , ''                     -- DateCompleted - smalldatetime
    , '1'                    -- DoCOI - varchar(2)
    , '0'                    -- DoSurvey - varchar(2)
    , '0'                    -- DoDoc - varchar(2)
    , '1'                    -- DocFileDoc - varchar(2)  Resource Center
    , '0'                    -- DoACS - varchar(2)
)
*/

