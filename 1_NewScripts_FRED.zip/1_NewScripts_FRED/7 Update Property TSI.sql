use v3Carter
go
select * FROM dbo.Property WHERE PropertyId IN (SELECT NEWID FROM MoveMiamiCenter WHERE tablename='Property')

SELECT * FROM v3Carter..Property WHERE PropertyId in (xxx)
go
select * from Employee where employeeid in (905017419)
select * from EmployeeProperty where employeeid in (905017419) and PropertyId in (xxx)
go
---------------------------
EXEC v3_Common..SetCompanyContext @CompanyId = 1040  
--Employee to Scope : 905017419
set xact_abort on
begin tran
    update dbo.Property SET TenantWebsiteId=yyy WHERE PropertyId in (xxx)
    
    if not exists(select * from dbo.EmployeeProperty where EmployeeId=905017419 and PropertyId=xxx)
        insert into dbo.EmployeeProperty(PropertyId, EmployeeId, IsDefaultProperty, EmployeeProperty_CS_CompanyId)
        values(
            xxx   -- PropertyId - int
            , 905017419 -- EmployeeId - int
            , 0 -- IsDefaultProperty - int
            , 1040 -- EmployeeProperty_CS_CompanyId - int
        )

--rollback
commit 
