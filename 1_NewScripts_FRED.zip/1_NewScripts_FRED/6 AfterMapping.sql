use v3_common
go
----

Declare @s varchar(8000)
Declare @moveid int
Declare @movename varchar(50)
Declare @ToDB varchar(20)


Select distinct moveid into #moveid from v3_common.dbo.MoveDataDump

Declare c_Insert cursor local for
Select moveid, MoveName,ToDB from v3_common.dbo.Moveflag where
-- moveid not in 
--(Select moveid from #moveid) AND 
 moveid = 905                                                                         -- CHANGE MOVEID BECAUSE OLD MOVE HAS BEEN DUMPPED
Open c_Insert
fetch next from c_insert into @moveid, @moveName,@ToDB
While @@fetch_status = 0
begin
    set @movename = 'Move' + @Movename
    Set @s = ' 
        Select  M.OldID as OldRequestId,  M.[NewID] as NewRequestID, T.TenantName
        From '+ @TODB +'.dbo.'+  @MoveName + ' as M 
		inner join '+ @TODB +'.dbo.Request R on M.[NewID] = R.RequestID
		inner join '+ @TODB +'.dbo.Tenant T on R.TenantID = T.TenantID where tablename = ''Request'' 
		


        Select OldID as OldWorkorderId, [NewID] as NewWorkorderID
        From '+ @TODB +'.dbo.'+  @MoveName + ' as M
		inner join '+ @TODB +'.dbo.workorder w on m.[NewID] = w.workorderid where tablename = ''Workorder'' 
		and w.WOType = ''PM''


		 Select OldID as OldWorkorderId, [NewID] as NewWorkorderID
        From '+ @TODB +'.dbo.'+  @MoveName + ' as M
		inner join '+ @TODB +'.dbo.workorder w on m.[NewID] = w.workorderid where tablename = ''Workorder'' 
		and w.WOType = ''TR''
		and w.ReservationId is not null
		'
    print (@s)

	EXEC(@s)

--     set @s = 'Drop table '+ @TODB +'.dbo.'+  @MoveName
--      Exec (@s)
fetch next from c_insert into @moveid, @moveName,@ToDB
End
Close c_Insert
Deallocate c_insert

Drop table #moveid