use v3Carter
go
exec v3_Common..SetCompanyContext @CompanyId = 1040       
go
declare @CompanyID int = 1040 


declare @PropertyList table (PropertyID int);
insert into @PropertyList (PropertyID)
select 
    PropertyID 
from 
    dbo.Property 
where 
    companyID = @CompanyID AND PropertyID in (xxx) 
    and IsActiveProperty=1


declare @CommunicationList PKListTableType;
insert into @CommunicationList (PrimaryKeyID) 
values (yyy)

--select
--    co.CompanyId
--    , co.CompanyName
--    , p.PropertyId
--    , p.PropertyName
--    , ct.CommunicationTypeId
--    , ctl.CommunicationTypeName
--from
--    dbo.Company                            co with (nolock)
--    inner join dbo.CommunicationType       ct with (nolock) on co.CompanyId            = ct.CompanyId
--    inner join dbo.CommunicationTypeLocale ctl with (nolock) on ct.CommunicationTypeId = ctl.CommunicationTypeId and ctl.LocaleCode = 'en-US'
--    inner join dbo.Property                p with (nolock) on co.CompanyId             = p.CompanyId
--    inner join @PropertyList           pl on p.PropertyId                          = pl.PropertyID
--    inner join @CommunicationList      cl on ct.CommunicationTypeId                = cl.PrimaryKeyID
--where
--    co.CompanyId = @CompanyID and   cl.PrimaryKeyID > 0;


declare @NewSubscriptions table (
    CommunicationSubscriptionId int
    , CommunicationTypeId       int
    , ContactId                 int
    , EmployeeId                int
          default 0
    , EmployeeIdEnteredBy       int
          default 0
);

insert into @NewSubscriptions (
    CommunicationSubscriptionId
    , CommunicationTypeId
    , ContactId
    , EmployeeId
    , EmployeeIdEnteredBy
)
select
    CommunicationSubscriptionId = next value for seq_CommunicationSubscription
    , CommunicationTypeID       = cmt.PrimaryKeyID
    , ContactID                 = ct.ContactId
    , EmployeeId                = 0
    , EmployeeIdEnteredBy       = 0
from
    Contact                       as ct
    inner join Area               as a on ct.BaseAreaId = a.AreaId
    inner join Building           as b on a.BuildingId = b.BuildingId
    inner join Property           as p on b.PropertyId = p.PropertyId
    inner join @PropertyList      pl on p.PropertyId = pl.PropertyID
    cross join @CommunicationList cmt
    left join CommunicationSubscription as cs on ct.ContactId = cs.ContactId and cs.CommunicationTypeId = cmt.PrimaryKeyID
where
    p.CompanyId = @CompanyID and cs.CommunicationSubscriptionId is null and cmt.PrimaryKeyID > 0 --and ct.IsActiveContact=1;

--select
--    CommunicationSubscriptionId
--    , CommunicationTypeId
--    , ContactId
--    , EmployeeId
--    , EmployeeIdEnteredBy
--from
--    @NewSubscriptions;

if 1 = 1 begin


    set nocount off;

    begin transaction;

    begin try

        insert into CommunicationSubscription (
            CommunicationSubscriptionId
            , CommunicationTypeId
            , ContactId
            , EmployeeId
            , EmployeeIdEnteredBy
            , CommunicationSubscription_CS_CompanyId
        )
        select
            CommunicationSubscriptionId
            , CommunicationTypeId
            , ContactId
            , EmployeeId
            , EmployeeIdEnteredBy
            , @CompanyID
        from
            @NewSubscriptions;



        if @@TRANCOUNT > 0 begin
            commit;
        end;


        select
            cs.CommunicationSubscriptionId
            , cs.CommunicationTypeId
            , cs.ContactId
            , cs.EmployeeId
            , cs.EmployeeIdEnteredBy
        from
            CommunicationSubscription    cs with (nolock)
            inner join @NewSubscriptions ns on cs.CommunicationSubscriptionId = ns.CommunicationSubscriptionId;

    end try
    begin catch
        select
            error_number()      as ErrorNumber
            , error_severity()  as ErrorSeverity
            , error_state()     as ErrorState
            , error_procedure() as ErrorProcedure
            , error_line()      as ErrorLine
            , error_message()   as ErrorMessage;
        print 'error'
        if @@TRANCOUNT > 0 rollback;
    end catch;
end;
