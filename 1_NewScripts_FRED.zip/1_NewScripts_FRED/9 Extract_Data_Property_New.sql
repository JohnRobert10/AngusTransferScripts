USE v3_Common
go

------Move property-----
---DBName,CompanyId,PropertyId,ExtractionDate

DECLARE @PropertyId VARCHAR(10);
DECLARE @FromProperty VARCHAR(8000);
DECLARE @DB VARCHAR(10);
DECLARE @CompanyID VARCHAR(10);
DECLARE @Flag INT;
DECLARE @s VARCHAR(8000);

DECLARE @Moveid VARCHAR(20);
SET @Moveid = 905                  ;
DECLARE @moveticket VARCHAR(20);
SET @moveticket = '8773';


DECLARE c_Property CURSOR
FOR
SELECT FromDB,
    FromCompany,
    FromProperty
FROM v3_Common..MoveFlag
WHERE MoveId = @Moveid;
OPEN c_Property;
FETCH NEXT FROM c_Property
INTO @DB,
    @CompanyID,
    @FromProperty;
WHILE @@fetch_status = 0
BEGIN
    SET @FromProperty = REPLACE(@FromProperty, '(', '');
    SET @FromProperty = REPLACE(@FromProperty, ')', '');

    SELECT @Flag = CHARINDEX(',', @FromProperty);
    WHILE (
              @Flag > 0
          )
    BEGIN
        SET @PropertyId = LEFT(@FromProperty, @Flag - 1);
        SET @FromProperty
            = SUBSTRING(@FromProperty, @Flag + 1, LEN(@FromProperty));

        IF NOT EXISTS
        (
            SELECT *
            FROM v3_Common..ExtractProperty ep
            WHERE CompanyId = @CompanyID
                  AND PropertyId = @PropertyId
                  AND dbo.fnZeroHour(ep.DateToExtract) = dbo.fnZeroHour(
                                                                 GETDATE()
                                                                       )
        )
        BEGIN
            SELECT @s
                = 'EXEC v3_Common.dbo.Admin_ExtractPropertyI_SP 
		'''       + @DB + ''',  --DBName
		'''       + @CompanyID + ''', --CompanyId
		'''       + @PropertyId + ''', -- PropertyId
		'''       + CONVERT(VARCHAR(20), DATEADD(MINUTE, 10, GETDATE()), 120)
                  + ''', -- ExtractionDate
		''John Robert'', 
		--''DataServices@angus-systems.com;MengJiao.Wang@mrisoftware.com;Ataullah.Toffar@mrisoftware.com'',
		''Angus.DataServicesGroup@MRISoftware.com;MengJiao.Wang@mrisoftware.com;Mariel.Hasenkopf@mrisoftware.com;Ataullah.Toffar@mrisoftware.com'',
		''Property Move '+@moveticket+''', 
		1, 1, 1 
		Go';
        END;
        PRINT (@s);
        SELECT @Flag = CHARINDEX(',', @FromProperty);
    END;
    FETCH NEXT FROM c_Property
    INTO @DB,
        @CompanyID,
        @FromProperty;
END;


SET @PropertyId = @FromProperty;


IF NOT EXISTS
(
    SELECT *
    FROM v3_Common..ExtractProperty ep
    WHERE CompanyId = @CompanyID
          AND PropertyId = @PropertyId
          AND dbo.fnZeroHour(ep.DateToExtract) = dbo.fnZeroHour(GETDATE())
)
BEGIN
    SELECT @s
        = 'EXEC v3_Common.dbo.Admin_ExtractPropertyI_SP 
		'''+@DB + ''',  --DBName
		'''+@CompanyID + ''', --CompanyId
		'''+@PropertyId + ''', -- PropertyId
		'''+CONVERT(VARCHAR(20), DATEADD(MINUTE, 10, GETDATE()), 120)
          + ''', -- ExtractionDate
		''John Robert'', 
--		''DataServices@angus-systems.com;MengJiao.Wang@mrisoftware.com'',
		''Angus.DataServicesGroup@MRISoftware.com;MengJiao.Wang@mrisoftware.com;Mariel.Hasenkopf@mrisoftware.com;Ataullah.Toffar@mrisoftware.com'',
		''Property Move '+@moveticket+''', 
		1, 1, 1 
		Go';
    PRINT (@s);
END;
CLOSE c_Property;
DEALLOCATE c_Property;