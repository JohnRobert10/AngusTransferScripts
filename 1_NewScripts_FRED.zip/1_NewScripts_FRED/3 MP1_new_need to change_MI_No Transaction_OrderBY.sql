use  v3Carter
go

SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET NUMERIC_ROUNDABORT OFF;
SET DEADLOCK_PRIORITY HIGH;
GO
IF EXISTS
(
    SELECT *
FROM sys.objects o inner join sys.schemas s on o.schema_id = s.schema_id
WHERE o.type = 'P'
    AND o.name = 'MoveProperties1'
    AND s.name = 'gpsAdmin'
)
    DROP PROC gpsAdmin.MoveProperties1;
go
create or alter proc gpsAdmin.MoveProperties1(@MoveId     int,
    @IsCorpTask int = 0)
as
begin
    SET ARITHABORT ON;
    SET CONCAT_NULL_YIELDS_NULL ON;
    SET QUOTED_IDENTIFIER ON;
    SET ANSI_NULLS ON;
    SET ANSI_PADDING ON;
    SET ANSI_WARNINGS ON;
    SET NUMERIC_ROUNDABORT OFF;
    DECLARE @name VARCHAR(50);
    DECLARE deleteTemp CURSOR LOCAL
         FOR SELECT name
    FROM sysobjects
    WHERE name LIKE 'temp%'
    and name<>'temp_Tyngsborough_contact_Import'
        AND xtype = 'U';
    OPEN deletetemp;
    FETCH NEXT FROM deletetemp INTO @name;
    WHILE @@fetch_status = 0
             BEGIN
        EXEC ('drop table '+@name+'');
        fetch next from deletetemp into @name;
    end;
    CLOSE deleteTemp;
    DEALLOCATE deletetemp;
    IF EXISTS
         (
             SELECT *
    FROM sysobjects
    WHERE TYPE = 'U'
        AND name = 'tmpt'
         )
             BEGIN
        DROP TABLE tmpt;
    END;
    SET NOCOUNT ON;
    -- Comment out for testing
    -- Drop triggers before run this SP
    -- Visitor and T3 not included
    -- companylevel table
     SET XACT_ABORT ON;
     --BEGIN TRAN;
    begin try
    SET CONTEXT_INFO 0xFE21232F297A57A5A743894A0E4A801FC3FE;
    DECLARE @sql VARCHAR(MAX);
    DECLARE @sql1 VARCHAR(MAX);
    DECLARE @s NVARCHAR(MAX);
    DECLARE @lookup VARCHAR(50);
    DECLARE @lookupIX VARCHAR(50);
    DECLARE @FromDB VARCHAR(20);
    DECLARE @FromServer VARCHAR(20);
    DECLARE @ToDB VARCHAR(20);
    DECLARE @FromCompany VARCHAR(10);
    DECLARE @ToCompany VARCHAR(10);
    DECLARE @FromProperty VARCHAR(MAX);
    DECLARE @DoTR VARCHAR(2);
    DECLARE @DoPM VARCHAR(2);
    DECLARE @DoACS VARCHAR(2);
    DECLARE @ResetDevice VARCHAR(2);
    DECLARE @ResetContactEmail VARCHAR(2);
    DECLARE @maxid INT;
    DECLARE @IsMoved INT;
    DECLARE @c1 VARCHAR(MAX);
    DECLARE @c2 VARCHAR(MAX);
    DECLARE @DoCOI VARCHAR(2);
    DECLARE @DoSurvey VARCHAR(2);
    DECLARE @DoDoc VARCHAR(2);
    DECLARE @DoFileDoc VARCHAR(2);
	--------------------
	DECLARE @DoPI int = 1;		--Inspection Module=PI
	DECLARE @DoVisit int = 1;	--Visit Module 
	--------------------
    SELECT @IsMoved = IsMoved
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    IF @IsMoved = 1
             BEGIN
        --RAISERROR 52001 'Property(s) already moved'
        RAISERROR('Property(s) already moved', 10, 1);
        --ROLLBACK;
        return;
    end;

    --EXEC v3_Common.dbo.SetUserContext  @toCompany 
    SELECT @FromServer = FromServer
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @lookup = movename
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @FromDB = FromDB
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @ToDB = ToDB
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @FromCompany = FromCompany
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @ToCompany = ToCompany
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @FromProperty = FromProperty
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @DoTR = DoTR
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @DoACS = DoACS
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @DoCOI = DoCOI
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @DoSurvey = DoSurvey
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @DoDoc = DoDoc
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @DoPM = DoPM
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @ResetDevice = ResetDevice
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @ResetContactEmail = ResetContactEmail
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
    SELECT @DoFileDoc = DocFileDoc
    FROM V3_common.dbo.moveflag
    WHERE MoveId = @MoveId;
	----1 New Added
    SET @sql = 'If exists (Select * from '+@ToDB+'.dbo.sysobjects where type = ''U'' and name ='''+'Move'+@lookup+''') drop table '+@ToDB+'.dbo.'+'Move'+@lookup
	--print @SQL
    exec (@sql);
 ---------

    /*   SELECT
          @DoFileDoc = '0'
 */

    --    FROM
    --        V3_common.dbo.moveflag
    --    WHERE
    --        MoveId = @Move


    UPDATE V3_common.dbo.moveflag
           SET
               DateEntered = GETDATE()
         WHERE MoveId = @MoveId;
    SET @lookupIX = 'IX'+@lookup+CONVERT(VARCHAR(4), CONVERT(INT, RAND() * 1000));
    SET @lookup = '[Move'+@lookup+']';
    -- USE DB not working without GO below statement just for make me feel better
    SET @sql = 'Use '+@ToDB+'';
    EXEC (@sql);
    DELETE mapping
         WHERE fromid IS NULL;
    -- Select * into tempe from mapping where tablename = 'employee'
    -- delete mapping where tablename = 'employee'
    SET @sql = 'If exists (Select * from '+@ToDB+'.dbo.sysobjects where type = ''U'' and name ='''+@lookup+''') drop table '+@ToDB+'.dbo.'+@lookup+'

Create table '+@ToDB+'.dbo.'+@lookup+'
(
	TableName Varchar(100) Not Null,
    ColumnName varchar(200) not null,
    OldId    int not null,
    [NewId]    int Not null,
	IsDeReferenced bit DEFAULT 0 NOT NULL
) ON [Primary]

CREATE CLUSTERED INDEX '+@lookupIX+'
    ON dbo.'+@lookup+' (TableName,OldID, [NewID])
  WITH PAD_INDEX,
       FILLFACTOR = 10
    ON [Primary]
';
    EXEC (@sql);
    SET @sql = '
insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Employee'', ''EmployeeId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''CommonEmployee'', ''EmployeeId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Resource'', ''ResourceId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Reservation'', ''ReservationId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Region'', ''RegionId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''VendorType'', ''VendorTypeId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Ers_PropertySet'', ''PropertySetId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Ers_Market'', ''MarketId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Ers_region'', ''Ersregionid'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Area'', ''AreaId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Tenant'', ''TenantId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Building'', ''BuildingId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Lease'', ''LeaseId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Contact'', ''ContactId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Trade'', ''TradeId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''RequestType'', ''RequestTypeId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''EquipmentClass'', ''EquipmentClassId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Department'', ''DepartmentId'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
values (''Service'', ''serviceid'', 0, 0)

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
select ''EquipmentClass'', ''EquipmentClassId'', fromid, [NewId] from '+@ToDB+'.dbo.Mapping
where tablename = ''EquipmentClass'' and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
select ''RequestType'', ''RequestTypeId'', fromid, [NewId] from '+@ToDB+'.dbo.Mapping
where tablename = ''RT'' and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
select ''Trade'', ''TradeId'', fromid, [NewId] from '+@ToDB+'.dbo.Mapping
where tablename = ''Trade'' and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'


insert dbo.'+@lookup+' (TableName,ColumnName,OldId,[NewId])
select ''VendorType'', ''VendorTypeId'', fromid, [NewId] from '+@ToDB+'.dbo.Mapping
where tablename = ''VendorType'' and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'
';
    EXEC (@sql);
    SET @sql = '
If exists (select * FROM         '+@Fromserver+'.'+@FromDB+'.dbo.WorkOrder  wo INNER JOIN
                      '+@Fromserver+'.'+@FromDB+'.dbo.Equipment  eq ON wo.EquipmentId = eq.EquipmentId INNER JOIN
                      '+@Fromserver+'.'+@FromDB+'.dbo.Area a ON eq.AreaId = a.AreaId INNER JOIN
                      '+@Fromserver+'.'+@FromDB+'.dbo.Building b ON a.BuildingId = b.BuildingId INNER JOIN
                      '+@Fromserver+'.'+@FromDB+'.dbo.Building Building_1  ON wo.BuildingId = Building_1.BuildingId
WHERE     (eq.EquipmentId > 0) AND (NOT (b.PropertyId IN '+@FromProperty+')) AND (Building_1.PropertyId IN '+@FromProperty+'))
Begin
Begin
    exec v3_Common..SetCompanyContext @CompanyId= '+@FromCompany+'
    update wo
    set
        wo.Buildingid = b.Buildingid
    FROM         '+@Fromserver+'.'+@FromDB+'.dbo.WorkOrder  wo INNER JOIN
                          '+@Fromserver+'.'+@FromDB+'.dbo.Equipment  eq ON wo.EquipmentId = eq.EquipmentId INNER JOIN
                          '+@Fromserver+'.'+@FromDB+'.dbo.Area a ON eq.AreaId = a.AreaId INNER JOIN
                          '+@Fromserver+'.'+@FromDB+'.dbo.Building b ON a.BuildingId = b.BuildingId INNER JOIN
                          '+@Fromserver+'.'+@FromDB+'.dbo.Building Building_1  ON wo.BuildingId = Building_1.BuildingId
    WHERE     (eq.EquipmentId > 0) AND (NOT (b.PropertyId IN '+@FromProperty+')) AND (Building_1.PropertyId IN '+@FromProperty+')
end
exec v3_Common..SetCompanyContext @CompanyId= '+@ToCompany+'
end
';
    EXEC (@sql);



    PRINT 'Insert Property';
    SET @sql = '
Select  next value for seq_Property  over (order by p.propertyid)  as newPropertyId, p.*
into dbo.TempProperty
from '+@Fromserver+'.'+@FromDB+'.dbo.Property p
where p.propertyid in '+@FromProperty+'
----order by p.propertyid

---------------
EXEC v3_Common.dbo.SetUserContext  ' + @fromcompany + '
update '+@FromServer+'.'+@FromDB+'.dbo.Property
set IntegrationIdentifier = Newid()
where propertyid in '+@FromProperty+' and Propertyid <> 0 

EXEC v3_Common.dbo.SetUserContext  ' + @ToCompany + '
----------------------
select newPropertyId from tempproperty

Update TempProperty
set TenantWebsiteId = 0,
    CompanyId = '+@ToCompany+'

Update TempProperty
set
    PropertySetId = 0

if exists (select * from tempproperty) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Property'',
        	''PropertyId'',
        	PropertyId,
        	newPropertyId
        From
           	dbo.tempProperty

update tempProperty set PropertySetId = -3, RegionId = -3

Update tempProperty
set
	PropertySetId = 0



Update P
set
	P.RegionId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempProperty p with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Property FP on P.Propertyid = FP.Propertyid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FP.RegionId = ulk.oldid
where
	P.RegionId = -3 and ulk.tablename = ''Region''

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempProperty''
  ,@ToTable =''Property''
  ,@CompanyId = '+@ToCompany+'


End



-- RequestTypeProperty
insert into
dbo.RequestTypeProperty (

RequestTypeId
, PropertyId
, Status
, ShowInTsi
, DateCreated
, DateUpdated
,RequestTypePropertyId
,tmpRequestTypePropertyID
,RequestTypeProperty_cs_companyid
)
select
rt.RequestTypeId
,tp.NewPropertyID
,  1  as status   -- default all to subscribed
, 1 as showInTsi    -- default TSI on
, getDate() as DateCreated
, getDate() as DateUpdated
, next value for seq_RequestTypeProperty as newRequestTypePropertyId
,-1 as tmpRequestTypePropertyID
, '+@ToCompany+' as RequestTypeProperty_cs_companyid
from
dbo.RequestType rt with (nolock) cross join tempProperty tp
where
(rt.CompanyId = '+@ToCompany+'
or rt.RequestTypeId = 0
)
';
    EXEC (@sql);

    -- Insert '+@ToDB+'.dbo.Property
    --     (
    --         [PropertyId]
    --        ,[CompanyId]
    --        ,[RegionId]
    --        ,[DocumentRegionId]
    --        ,[PropertySetId]
    --        ,[TenantWebsiteId]
    --        ,[PropertyName]
    --        ,[ExternalPropertyCode]
    --        ,[PropertyAddress]
    --        ,[ShowBuildingAddress]
    --        ,[IsActiveProperty]
    --        ,[IsPropertyLevelRoute]
    --        ,[IsInERS]
    --        ,[UsesDst]
    --        ,[UsesPropertyDocuments]
    --        ,[HasTR]
    --        ,[HasVS]
    --        ,[HasPM]
    --        ,[HasSM]
    --        ,[HasSR]
    --        ,[HasIT]
    --        ,[HasPD]
    --        ,[HasEECO]
    --        ,[HasSurvey]
    --        ,[HasVendorCOI]
    --        ,[HasTenantCOI]
    --        ,[HasEmergency]
    --        ,[HasCommunication]
    --        ,[TimeZoneOffset]
    --        ,[DispatchHours]
    --        ,[DispatchDays]
    --        ,[PhoneNumber]
    --        ,[FaxNumber]
    --        ,[PropertyDispatchNote]
    --        ,[COIContactName]
    --        ,[COIContactEmail]
    --        ,[COIContactPhone]
    --        ,[COIContactFax]
    --        ,[SecondaryAddress]
    --        ,[PropertyCustom1]
    --        ,[PropertyCustom2]
    --        ,[SurveyEscalationEmail]
    --        ,[NameInsured]
    --        ,[DateCreated]
    --        ,[DateUpdated]
    --        ,[tmpRegionId]
    --        ,[tmpPropertyId]
    --        ,[tmpRegionName]
    --        ,[ASGL_ProjectId]
    --        ,[ASGL_ProjectNumber]
    --        ,[ShowTsiOnlineHelp]
    --        ,[ShowTsiCalendar]
    --        ,[ShowTsiCommunications]
    --        ,[ShowTsiContactInformation]
    --        ,[MaxStorage]
    --        ,[HasResourceCenter]
    --        --,[DateUpdatedUtc]
    --        --,[DateCreatedUtc]
    --        ,[ShowTsiBillingReports]
    --        ,[ShowTsiResourceCenter]
    --        ,[HasPackagePass]
    --        ,[BypassPrinterDialog]
    --        ,[ShowTsiMobileAd]
	--    ,UsesKiosk
	--    ,KioskWelcomeMessage
	--    ,ShowServicesOnMobile
	--    ,HasInspections
	--    ,IanaTimeZone
	--    ,FeatureVisitorAutoInvite
	-- 	, HasTac
	-- 	,[UsesMultiDayPass]
	-- 	,QRSIsEnabled
	-- 	,VisitorAutoInviteHours
	-- 	,ShowTspPriority
	-- 	,Property_cs_companyid
	-- 	,HasLicenseScan
	-- 	,DefaultScanOption
	-- 	,UsesVisitorExpiry
	-- 	,IsVisitorExpiryRequired
	-- 	,UsesVisitorSingleUse
	-- 	,DefaultVisitorSingleUse
	-- 	,VisitorAutoInviteBufferHours
	-- 	,UsesGeoDispatch    
	-- 	,[UsesRrPanel]
	-- 	,[DateSentPanelAccessCodes]
	-- 	,[UsesVsTenantSync]
	-- 	,IntegrationIdentifier 
	-- 	,WelcomeMessageDateSentUtc
    --     ,VisitorAutoInviteBufferMinutes 
	-- 	,ForceEsc3Recalc

    --     )
    -- Select
	--    newPropertyId
    --        ,[CompanyId]
    --        ,0 as [RegionId]
    --        ,0 as [DocumentRegionId]
    --        ,0 as [PropertySetId]
    --        ,[TenantWebsiteId]
    --        ,[PropertyName]
    --        ,[ExternalPropertyCode]
    --        ,[PropertyAddress]
    --        ,[ShowBuildingAddress]
    --        ,[IsActiveProperty]
    --        ,[IsPropertyLevelRoute]
    --        ,0 as [IsInERS]
    --        ,[UsesDst]
    --        ,[UsesPropertyDocuments]
    --        ,[HasTR]
    --        ,[HasVS]
    --        ,[HasPM]
    --        ,[HasSM]
    --        ,[HasSR]
    --        ,[HasIT]
    --        ,[HasPD]
    --        ,[HasEECO]
    --        ,[HasSurvey]
    --        ,[HasVendorCOI]
    --        ,[HasTenantCOI]
    --        ,[HasEmergency]
    --        ,[HasCommunication]
    --        ,[TimeZoneOffset]
    --        ,[DispatchHours]
    --        ,[DispatchDays]
    --        ,[PhoneNumber]
    --        ,[FaxNumber]
    --        ,[PropertyDispatchNote]
    --        ,[COIContactName]
    --        ,[COIContactEmail]
    --        ,[COIContactPhone]
    --        ,[COIContactFax]
    --        ,[SecondaryAddress]
    --        ,[PropertyCustom1]
    --        ,[PropertyCustom2]
    --        ,[SurveyEscalationEmail]
    --        ,[NameInsured]
    --        ,getdate() as [DateCreated]
    --        ,getdate() as [DateUpdated]
    --        ,-1 as [tmpRegionId]
    --        ,-1 as [tmpPropertyId]
    --        ,[tmpRegionName]
    --        ,[ASGL_ProjectId]
    --        ,[ASGL_ProjectNumber]
    --        ,[ShowTsiOnlineHelp]
    --        ,[ShowTsiCalendar]
    --        ,[ShowTsiCommunications]
    --        ,[ShowTsiContactInformation]
    --        ,[MaxStorage]
    --        ,[HasResourceCenter]
    --        --,[DateUpdatedUtc]
    --        --,[DateCreatedUtc]
    --        ,[ShowTsiBillingReports]
    --        ,[ShowTsiResourceCenter]
    --        ,[HasPackagePass]
    --        ,[BypassPrinterDialog]
    --        ,[ShowTsiMobileAd]
	--    ,UsesKiosk
	--    ,KioskWelcomeMessage
	--    ,ShowServicesOnMobile
	--    ,HasInspections
	--   ,IanaTimeZone
    --       ,FeatureVisitorAutoInvite
	-- 	  ,HasTac
	-- 	  ,[UsesMultiDayPass]
	-- 	  ,QRSIsEnabled
	-- 	  ,VisitorAutoInviteHours
	-- 	  ,ShowTspPriority
	-- 	  ,'+@ToCompany+' as Property_cs_companyid
	-- 	  ,HasLicenseScan
	-- 	,DefaultScanOption
	-- 	,UsesVisitorExpiry
	-- 	,IsVisitorExpiryRequired
	-- 	,UsesVisitorSingleUse
	-- 	,DefaultVisitorSingleUse
	-- 	,VisitorAutoInviteBufferHours
	-- 	,UsesGeoDispatch 
	-- 	,[UsesRrPanel]
	-- 	,[DateSentPanelAccessCodes]
	-- 	,[UsesVsTenantSync]
	-- 	,IntegrationIdentifier 
	-- 	,WelcomeMessageDateSentUtc
    --     ,VisitorAutoInviteBufferMinutes 
	-- 	,ForceEsc3Recalc
    -- From
    --     tempProperty


    IF EXISTS
         (
             SELECT *
    FROM sysobjects
    WHERE TYPE = 'U'
        AND name = 'fep'
         )
             BEGIN
        DROP TABLE dbo.fep;
    END;
    PRINT 'Insert CommonEmployee';
    SET @sql = '
select * into dbo.fep
from
'+@Fromserver+'.'+@FromDB+'.dbo.employeeproperty where propertyid in '+@FromProperty+'
and
employeeid not in (select employeeid from '+@Fromserver+'.'+@FromDB+'.dbo.employeeproperty where propertyid not in '+@FromProperty+')
';
    EXEC (@sql);
    SET @c1 = '
select distinct a.employeeid into tmpt from (
select EmployeeId from '+@Fromserver+'.'+@FromDB+'.dbo.employeeproperty where propertyid in '+@FromProperty+'
union all
select EmployeeIdFrom from '+@Fromserver+'.'+@FromDB+'.dbo.message where propertyid in '+@FromProperty+'
union all
select EmployeeIdTo from '+@Fromserver+'.'+@FromDB+'.dbo.message where propertyid in '+@FromProperty+'
union all
select rh.EmployeeIdCreated from '+@Fromserver+'.'+@FromDB+'.dbo.reqhistory rh inner join '+@Fromserver+'.'+@FromDB+'.dbo.request r on coalesce(r.requestid, r.requestid ) = rh.requestid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = coalesce(b.buildingid, b.buildingid )
where b.propertyid in '+@FromProperty+'
union all
select rh.EmployeeIdUpdated from '+@Fromserver+'.'+@FromDB+'.dbo.reqhistory rh inner join '+@Fromserver+'.'+@FromDB+'.dbo.request r on coalesce(r.requestid, r.requestid ) = rh.requestid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = coalesce(b.buildingid, b.buildingid )
where b.propertyid in '+@FromProperty+'
union all
select r.EmployeeIdOwner from '+@Fromserver+'.'+@FromDB+'.dbo.request r inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = b.buildingid where b.propertyid in '+@FromProperty+'
union all
select r.EmployeeIdRequested from '+@Fromserver+'.'+@FromDB+'.dbo.request r inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = b.buildingid where b.propertyid in '+@FromProperty+'
union all
select r.EmployeeIdCreated from '+@Fromserver+'.'+@FromDB+'.dbo.request r inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = b.buildingid where b.propertyid in '+@FromProperty+'
union all
select r.EmployeeIdUpdated from '+@Fromserver+'.'+@FromDB+'.dbo.request r inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = b.buildingid where b.propertyid in '+@FromProperty+'
union all
select EmployeeIdEnteredBy from '+@Fromserver+'.'+@FromDB+'.dbo.reservation r inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = b.buildingid where b.propertyid in '+@FromProperty+'


union all
select e.EmployeeIdAlternate from '+@Fromserver+'.'+@FromDB+'.dbo.Employee e inner join
   '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty   ep    on e.EmployeeId   = ep.employeeid
 where ep.propertyid in '+@FromProperty+' and e.EmployeeIdAlternate is not null
Union all
Select EST.EmployeeIDCreated
from '+@Fromserver+'.'+@FromDB+'.dbo.Estimate EST  inner join  '+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on EST.EstimateId = wo.EstimateId
Inner join   '+@Fromserver+'.'+@FromDB+'.dbo.Area ta on wo.Areaid = ta.Areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b  on b.buildingid = ta.buildingid
where b.propertyid in '+@FromProperty+' and wo.wotype = ''TR''
Union all
Select EST.EmployeeIDUpdated
from '+@Fromserver+'.'+@FromDB+'.dbo.Estimate EST  inner join  '+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on EST.EstimateId = wo.EstimateId
Inner join   '+@Fromserver+'.'+@FromDB+'.dbo.Area ta on wo.Areaid = ta.Areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b  on b.buildingid = ta.buildingid
where b.propertyid in '+@FromProperty+' and wo.wotype = ''TR''
Union all
select rh.EmployeeIdEnteredBy from '+@Fromserver+'.'+@FromDB+'.dbo.reservationhistory rh inner join '+@Fromserver+'.'+@FromDB+'.dbo.reservation r on r.ReservationId = rh.ReservationId
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = b.buildingid where b.propertyid in '+@FromProperty+'

union all
select rwo.EmployeeIdDispatchTo from '+@Fromserver+'.'+@FromDB+'.dbo.resourcewo rwo inner join '+@Fromserver+'.'+@FromDB+'.dbo.resource r on rwo.resourceid = r.resourceid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.area a on r.areaid = a.areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on a.buildingid = b.buildingid where b.propertyid in '+@FromProperty+'
union all
select r.EmployeeId from '+@Fromserver+'.'+@FromDB+'.dbo.route r inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = r.buildingid where b.propertyid in '+@FromProperty+'
union all
select sc.EmployeeIdAssigned from '+@Fromserver+'.'+@FromDB+'.dbo.schedule sc inner join '+@Fromserver+'.'+@FromDB+'.dbo.equipment eq on eq.equipmentid = sc.equipmentid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.area a on a.areaid = eq.areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = a.buildingid where b.propertyid in '+@FromProperty+'
union all
select v.EmployeeIdEnteredBy from '+@Fromserver+'.'+@FromDB+'.dbo.visit v inner join '+@Fromserver+'.'+@FromDB+'.dbo.area a on v.AreaIdDestination = a.areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = a.buildingid where b.propertyid in '+@FromProperty+'
union all
select v.EmployeeIdCheckedInBy from '+@Fromserver+'.'+@FromDB+'.dbo.Visitor v inner join '+@Fromserver+'.'+@FromDB+'.dbo.visit vt on v.visitid = vt.visitid inner join '+@Fromserver+'.'+@FromDB+'.dbo.area a on vt.AreaIdDestination = a.areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = a.buildingid where b.propertyid in '+@FromProperty+'
union all
select v.EmployeeIdCheckedOutBy from '+@Fromserver+'.'+@FromDB+'.dbo.Visitor v inner join '+@Fromserver+'.'+@FromDB+'.dbo.visit vt on v.visitid = vt.visitid inner join '+@Fromserver+'.'+@FromDB+'.dbo.area a on vt.AreaIdDestination = a.areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = a.buildingid where b.propertyid in '+@FromProperty+'
union all
select v.EmployeeIdBadgePrintedBy from '+@Fromserver+'.'+@FromDB+'.dbo.Visitor v inner join '+@Fromserver+'.'+@FromDB+'.dbo.visit vt on v.visitid = vt.visitid inner join '+@Fromserver+'.'+@FromDB+'.dbo.area a on vt.AreaIdDestination = a.areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = a.buildingid where b.propertyid in '+@FromProperty+'
union all
select wo.EmployeeIdAssigned from '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = wo.buildingid where b.propertyid in '+@FromProperty+'
union all
select wo.EmployeeIdOwner from '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = wo.buildingid where b.propertyid in '+@FromProperty+'
union all
select wo.EmployeeIdRequested from '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = wo.buildingid where b.propertyid in '+@FromProperty+'
union all
select wo.EmployeeIdCreated from '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = wo.buildingid where b.propertyid in '+@FromProperty+'
union all
select wo.EmployeeIdUpdated from '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on b.buildingid = wo.buildingid where b.propertyid in '+@FromProperty+'
union all
select woh.EmployeeId from '+@Fromserver+'.'+@FromDB+'.dbo.wohistory woh inner join '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo on coalesce(wo.workorderid, wo.workorderid) = woh.workorderid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on coalesce(b.buildingid, b.buildingid ) = wo.buildingid where b.propertyid in '+@FromProperty+'
Union All
select wohdetail.WoHistoryDetailEmployeeId from '+@Fromserver+'.'+@FromDB+'.dbo.wohistorydetail wohdetail inner join '+@Fromserver+'.'+@FromDB+'.dbo.woHistory woh on wohdetail.WoHistoryId = woh.woHistoryID
inner join '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo on coalesce(wo.workorderid, wo.workorderid) = woh.workorderid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on coalesce(b.buildingid, b.buildingid ) = wo.buildingid where b.propertyid in '+@FromProperty+'
Union all
select wohdetail.EmployeeIdCreated from '+@Fromserver+'.'+@FromDB+'.dbo.wohistorydetail wohdetail inner join '+@Fromserver+'.'+@FromDB+'.dbo.woHistory woh on wohdetail.WoHistoryId = woh.woHistoryID
inner join '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo on coalesce(wo.workorderid, wo.workorderid) = woh.workorderid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on coalesce(b.buildingid, b.buildingid ) = wo.buildingid where b.propertyid in '+@FromProperty+'
Union all
select wohdetail.EmployeeIdUpdated from '+@Fromserver+'.'+@FromDB+'.dbo.wohistorydetail wohdetail inner join '+@Fromserver+'.'+@FromDB+'.dbo.woHistory woh on wohdetail.WoHistoryId = woh.woHistoryID
inner join '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo on coalesce(wo.workorderid, wo.workorderid) = woh.workorderid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on coalesce(b.buildingid, b.buildingid ) = wo.buildingid where b.propertyid in '+@FromProperty+'

union all
select woh.EmployeeIdCreated from '+@Fromserver+'.'+@FromDB+'.dbo.wohistory woh inner join '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo on coalesce(wo.workorderid, wo.workorderid) = woh.workorderid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on coalesce(b.buildingid, b.buildingid ) = wo.buildingid where b.propertyid in '+@FromProperty+'
union all
select EmployeeIdCreated from '+@Fromserver+'.'+@FromDB+'.dbo.RestrictedVisitor where propertyid in '+@FromProperty+'
union all
select EmployeeIdUpdated from '+@Fromserver+'.'+@FromDB+'.dbo.RestrictedVisitor where propertyid in '+@FromProperty+'
Union All
select r.EmployeeIdCreated from '+@Fromserver+'.'+@FromDB+'.dbo.FileDocument r  inner join '+@Fromserver+'.'+@FromDB+'.dbo.FileDocumentProperty FDP
on r.FileDocumentId = FDP.FileDocumentID where FDP.propertyid in '+@FromProperty+'
union all
select r.EmployeeIdUpdated from  '+@Fromserver+'.'+@FromDB+'.dbo.FileDocument r  inner join '+@Fromserver+'.'+@FromDB+'.dbo.FileDocumentProperty FDP
on r.FileDocumentId = FDP.FileDocumentID where FDP.propertyid in '+@FromProperty+'

union all
select woh.EmployeeIdUpdated from '+@Fromserver+'.'+@FromDB+'.dbo.wohistory woh inner join '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo on coalesce(wo.workorderid, wo.workorderid) = woh.workorderid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on coalesce(b.buildingid, b.buildingid ) = wo.buildingid where b.propertyid in '+@FromProperty+'
---
union all
select InsTemp.EmployeeId_CreatedBy from  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate as InsTemp inner join
'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule InsSch on InsTemp.InspectionTemplateId = InsSch.InspectionTemplateId
where InsSch.PropertyId in  '+@FromProperty+'

Union All
select InsSch.EmployeeId_AssignedToSchedule from  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule InsSch
where InsSch.PropertyId in  '+@FromProperty+' and InsSch.EmployeeId_AssignedToSchedule > 0
Union All
select InsSch.EmployeeId_AssignedToNextInspection from  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule InsSch
where InsSch.PropertyId in  '+@FromProperty+' and InsSch.EmployeeId_AssignedToNextInspection >0

Union All
select Insp.EmployeeId_Assigned from  '+@Fromserver+'.'+@FromDB+'.dbo.Inspection as Insp inner join   '+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule InsSch on Insp.InspectionScheduleId = InsSch.InspectionScheduleId
where InsSch.PropertyId in  '+@FromProperty+' and Insp.EmployeeId_Assigned > 0
Union All
select Insp.EmployeeId_CompletedBy from  '+@Fromserver+'.'+@FromDB+'.dbo.Inspection as Insp inner join   '+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule InsSch on Insp.InspectionScheduleId = InsSch.InspectionScheduleId
where InsSch.PropertyId in  '+@FromProperty+' and Insp.EmployeeId_CompletedBy > 0

Union All
select InspecH.EmployeeId_History from  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory InspecH inner join '+@Fromserver+'.'+@FromDB+'.dbo.Inspection as Insp on InspecH.InspectionId = Insp.Inspectionid
inner join   '+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule InsSch on Insp.InspectionScheduleId = InsSch.InspectionScheduleId
where InsSch.PropertyId in  '+@FromProperty+' and InspecH.EmployeeId_History >0

Union All
select InspecH.EmployeeId_Updated from  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory InspecH inner join '+@Fromserver+'.'+@FromDB+'.dbo.Inspection as Insp on InspecH.InspectionId = Insp.Inspectionid
inner join   '+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule InsSch on Insp.InspectionScheduleId = InsSch.InspectionScheduleId
where InsSch.PropertyId in  '+@FromProperty+' and InspecH.EmployeeId_Updated >0

union all
select es.employeeid from   '+@Fromserver+'.'+@FromDB+'.dbo.employeeSubscription es inner join  '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty ep on es.employeeid = ep.employeeid
where ep.propertyid in '+@FromProperty+'

union all
select es.EmployeeIdCreated from   '+@Fromserver+'.'+@FromDB+'.dbo.employeeSubscription es inner join  '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty ep on es.EmployeeIdCreated = ep.employeeid
where ep.propertyid in '+@FromProperty+'
 
union all
select v.Employeeid 
from   '+@Fromserver+'.'+@FromDB+'.dbo.COI c1 
inner join  '+@Fromserver+'.'+@FromDB+'.dbo.vendor v on c1.vendorid=v.vendorid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.employee em on v.Employeeid=em.employeeId
inner join '+@Fromserver+'.'+@FromDB+'.dbo.COIProperty cop on c1.COIID=cop.COIID
where cop.propertyid in '+@FromProperty+' and em.employeeid is not null and v.employeeid > 0

union all
select es.EmployeeIdUpdated from   '+@Fromserver+'.'+@FromDB+'.dbo.employeeSubscription es inner join  '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty ep on es.EmployeeIdUpdated = ep.employeeid
where ep.propertyid in '+@FromProperty+'

union all
select es.Employeeid from   '+@Fromserver+'.'+@FromDB+'.dbo.photo es inner join  '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty ep on es.employeeid = ep.employeeid
where ep.propertyid in '+@FromProperty+' and es.employeeid is not null and es.employeeid <> 0

union all
select es.Employeeid from   '+@Fromserver+'.'+@FromDB+'.dbo.BulletinHistory es inner join  '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty ep on es.employeeid = ep.employeeid
where ep.propertyid in '+@FromProperty+' and es.employeeid is not null and es.employeeid <> 0

union all
select es.Employeeid from   '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeBulletin es inner join  '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty ep on es.employeeid = ep.employeeid
where ep.propertyid in '+@FromProperty+' and es.employeeid is not null and es.employeeid <> 0

union all
select es.DispatchEmployeeid from   '+@Fromserver+'.'+@FromDB+'.dbo.GeoDispatchResponse es inner join  '+@Fromserver+'.'+@FromDB+'.dbo.Property p on es.Propertyid = p.Propertyid
where p.propertyid in '+@FromProperty+' and es.DispatchEmployeeid is not null and es.DispatchEmployeeid <> 0
) a
where a.employeeid > 0
';
    --PRINT (@c1)
    --PRINT(@c2)
    EXEC (@c1);
    SET @c2 = '
	  select next value for v3_Common.[dbo].[seq_CommonEmployee] as newCommonEmployeeId,
	  next value for seq_Employee as newemployeeid,
      ce.[CompanyId]
           ,ce.[EmployeeId]
           ,ce.[IsVendor]
           ,ce.[EmployeeFirstName]
           ,ce.[EmployeeLastName]
           ,ce.[UserName]
           ,ce.[TRDeviceAddress]
           ,ce.[PMDeviceAddress]
           ,ce.[EncryptedPassword]
           ,ce.[tmpemployeeid]
		   ,ce.PrimaryEmailAddress
		   ,ce.IsPrimaryEmailVerified	 
into dbo.Tempce
from '+@FromServer+'.v3_common.dbo.CommonEmployee ce
where ce.employeeid in ( select employeeid from  tmpt   )
and ce.companyId = '+@FromCompany+'
----order by ce.employeeId
';
    --print (@c2)
    EXEC (@c2);
    SET @c1 = '
update tempce
set companyId = '+@ToCompany+'

update tempce
set
    username = '''',
    EncryptedPassword = Encryptedpassword + 1
from
    tempce with (nolock) left outer join
    fep with (nolock)
on tempce.employeeid = fep.employeeid
where
    fep.employeeid is null


EXEC v3_Common.dbo.SetUserContext  ' + @fromcompany + '
update ce
set
    username = '''',
    Encryptedpassword = Encryptedpassword + 1, -- changed temporary
	isactiveemployee = 0,
	PMDeviceAddress = '''',
	TRDeviceAddress = ''''
from
  '+@FromServer+'.'+@FromDB+'.dbo.employee ce inner join fep on ce.employeeid = fep.employeeid
  where ce.isvendor = 0

-- below update is not needed if From database triggers are not disabled or dropped
update ce
set
    ce.username = e.Username ,
    ce.Encryptedpassword = e.Encryptedpassword
from
    '+@FromServer+'.v3_common.dbo.commonemployee ce inner join
	'+@FromServer+'.'+@FromDB+'.dbo.employee e on ce.employeeid = e.employeeid inner join
	fep on ce.employeeid = fep.employeeid
	where ce.companyid = '+@FromCompany+'
	and e.isvendor = 0

update tempce
set PMDeviceAddress = ''''
where PMDeviceAddress in (
select pmdeviceaddress from v3_common.dbo.commonemployee with (nolock)
union all
select TRDeviceAddress from v3_common.dbo.commonemployee with (nolock)
)

-- add to exclue vendor
and employeeid not in
(
select ce.employeeid
from
    '+@FromServer+'.v3_common.dbo.commonemployee ce inner join
	'+@FromServer+'.'+@FromDB+'.dbo.employee e on ce.employeeid = e.employeeid inner join
	fep on ce.employeeid = fep.employeeid
	where ce.companyid = '+@FromCompany+'
	and e.isvendor = 1
)

';
    EXEC v3_Common.dbo.SetUserContext  @toCompany
    SET @c2 = '
		 EXEC v3_Common.dbo.SetUserContext  ' + @toCompany + '
update tempce
set TRDeviceAddress = ''''
where TRDeviceAddress in (
select pmdeviceaddress from v3_common.dbo.commonemployee with (nolock)
union all
select TRDeviceAddress from v3_common.dbo.commonemployee with (nolock)
)
-- add to exclude vendor
and employeeid not in
(
select ce.employeeid
from
    '+@FromServer+'.v3_common.dbo.commonemployee ce inner join
	'+@FromServer+'.'+@FromDB+'.dbo.employee e on ce.employeeid = e.employeeid inner join
	fep on ce.employeeid = fep.employeeid
	where ce.companyid = '+@FromCompany+'
	and e.isvendor = 1
)

update tempce
set username = ''''
where username in (
select username from v3_common.dbo.commonemployee with (nolock)
)

update tempce
set PMDeviceAddress = ''''
where TRDeviceAddress = PMDeviceAddress and PMDeviceAddress <> ''''
-- add to exclude vendor
and employeeid not in
(
select ce.employeeid
from
    '+@FromServer+'.v3_common.dbo.commonemployee ce inner join
	'+@FromServer+'.'+@FromDB+'.dbo.employee e on ce.employeeid = e.employeeid inner join
	fep on ce.employeeid = fep.employeeid
	where ce.companyid = '+@FromCompany+'
	and e.isvendor = 1
)

Update tempce
set
	PMDeviceAddress = '''',
	TRDeviceAddress = ''''
From tempce inner join tempce as t1 on tempce.TRDeviceAddress = T1.TRDeviceAddress and tempce.NewEmployeeID <> T1.NewEmployeeID
where
	tempce.TRDeviceAddress <>''''
-- add to exclude vendor
and tempce.employeeid not in
(
select ce.employeeid
from
    '+@FromServer+'.v3_common.dbo.commonemployee ce inner join
	'+@FromServer+'.'+@FromDB+'.dbo.employee e on ce.employeeid = e.employeeid inner join
	fep on ce.employeeid = fep.employeeid
	where ce.companyid = '+@FromCompany+'
	and e.isvendor = 1
)

Update tempce
set
	PMDeviceAddress = '''',
	TRDeviceAddress = ''''
From tempce inner join tempce as t1 on tempce.TRDeviceAddress = T1.PMDeviceAddress and tempce.NewEmployeeID <> T1.NewEmployeeID
where
	tempce.TRDeviceAddress <>''''
-- add to exclude vendor
and tempce.employeeid not in
(
select ce.employeeid
from
    '+@FromServer+'.v3_common.dbo.commonemployee ce inner join
	'+@FromServer+'.'+@FromDB+'.dbo.employee e on ce.employeeid = e.employeeid inner join
	fep on ce.employeeid = fep.employeeid
	where ce.companyid = '+@FromCompany+'
	and e.isvendor = 1
)


Update tempce
set PMDeviceAddress = ''''
where employeeid not in
(select min(employeeid) from tempce group by PMDeviceAddress
)
and employeeid not in
(
select ce.employeeid
from
    '+@FromServer+'.v3_common.dbo.commonemployee ce inner join
	'+@FromServer+'.'+@FromDB+'.dbo.employee e on ce.employeeid = e.employeeid inner join
	fep on ce.employeeid = fep.employeeid
	where ce.companyid = '+@FromCompany+'
	and e.isvendor = 1
)


Update tempce
set TRDeviceAddress = ''''
where employeeid not in
(select min(employeeid) from tempce group by TRDeviceAddress
)
and employeeid not in
(
select ce.employeeid
from
    '+@FromServer+'.v3_common.dbo.commonemployee ce inner join
	'+@FromServer+'.'+@FromDB+'.dbo.employee e on ce.employeeid = e.employeeid inner join
	fep on ce.employeeid = fep.employeeid
	where ce.companyid = '+@FromCompany+'
	and e.isvendor = 1
)

--------------
If exists (select * from tempce) begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''CommonEmployee'',
        	''EmployeeId'',
        	EmployeeId,
        	newEmployeeId
        From
           	dbo.tempce


    Insert V3_Common.dbo.Commonemployee
        (
            [CommonEmployeeId]
           ,[CompanyId]
           ,[EmployeeId]
           ,[IsVendor]
           ,[EmployeeFirstName]
           ,[EmployeeLastName]
           ,[UserName]
           ,[TRDeviceAddress]
           ,[PMDeviceAddress]
           ,[EncryptedPassword]
           , tmpemployeeid
		   ,PrimaryEmailAddress
		   ,IsPrimaryEmailVerified
        )
    select
			NewCommonEmployeeId,
            CompanyId         ,
            newEmployeeId        ,
			IsVendor,
            EmployeeFirstName ,
            EmployeeLastName  ,
            UserName          ,
            TRDeviceAddress   ,
            PMDeviceAddress   ,
            EncryptedPassword ,
			-1,
			--'''' as PrimaryEmailAddress
			PrimaryEmailAddress,
			IsPrimaryEmailVerified		-- new column
    From
            tempce
End
';
    --Print (@c1 + @c2)

    EXEC (@c1+@c2);

    EXEC v3_Common.dbo.SetUserContext @ToCompany
    PRINT 'Insert Employee';
    SET @sql = '
select
    distinct e.*,
    ce.newemployeeid,
    ce.username as ceusername,
    ce.EncryptedPassword as ceEncryptedPassword,
    ce.companyid as cecompanyid,
    ce.TRDeviceAddress as ceTRDeviceAddress,
    ce.PMDeviceAddress as cePMDeviceAddress
into tempe
from
    '+@Fromserver+'.'+@FromDB+'.dbo.employee e  inner join tempce ce
on
    ce.employeeid = e.employeeid

if '+@ResetDevice+' = 1 Begin
    update tempe
    set ceTRDeviceAddress = '''',
        cePMDeviceAddress = '''',
	    TRCCEmailAddress = '''',
        PMDeviceType = 4,
        TRDeviceType = 4,
        TRDeviceTypeDescription = ''Printer'',
        PMDeviceTypeDescription = ''Printer''
End

update tempe
set tempe.IsActiveEmployee = 0
from
    tempe with (nolock) left outer join
    fep with (nolock)
on tempe.employeeid = fep.employeeid
where
    fep.employeeid is null

--Update tempe
--set    employeeIdAlternate = ce.NewemployeeId
--from
--   dbo.tempe e  inner join tempce ce
--on
--    ce.employeeid = e.employeeIdAlternate
-- Where e.EmployeeIdAlternate is not null


 Update tempe
set    employeeIdAlternate = null

Update tempe
set    employeeIdAlternate = Null
WHERE employeeIDAlternate NOT IN (SELECT employeeID FROM Employee)


--
-- update tempe
-- set tempe.IsActiveEmployee = 1
-- from
--     tempe with (nolock) inner join
--     fep with (nolock)
-- on tempe.employeeid = fep.employeeid

if exists (select * from tempe) begin
    Insert  dbo.'+@lookup+'
        (
      	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Employee'',
        	''EmployeeId'',
        	EmployeeId,
        	newEmployeeId
        From
           	dbo.tempe
---- merge data
--    EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
--   ,@ToSchema =''dbo''
--   ,@FromTable =''tempe''
--   ,@ToTable =''employee''
--   ,@CompanyId = '+@ToCompany+'

    Insert '+@ToDB+'.dbo.employee
        (
            EmployeeId              ,
            CompanyId,
            RoleId,
            IsActiveEmployee,
            IsTrAvailable,
            IsPmAvailable,
            IsCallCenter,
            IsVendor,
            IsAccountLocked,
		    IsMasterAuthor,
    		IsPropertyAuthor,
			IsSubscriptionEnabled,
            ShowTR,
            ShowPM,
            ShowSM,
            UsesReports,
            UsesSetup,
            EmployeeHomePage,
            ReceivesNewsletters,
            ReceivesAnnouncements ,
            ReceivesServiceAlerts,
            NotifyMissingValues,
            NotifyCallAttention,
            FailedLoginAttempts,
            EmployeeFirstName,
            EmployeeLastName,
            UserName,
            ExternalEmployeeCode,
            PhoneNumber,
            TRDeviceType,
            TRDeviceAddress,
            TRCCEmailAddress,
            PMDeviceType,
            PMDeviceAddress,
            TRDeviceTypeDescription,
            PMDeviceTypeDescription,
            NotifyEmailAddress,
            LocaleCode,
            PasswordChangeDate,
            LastLoginDate,
            PasswordExpiryDate,
            EncryptedPassword,
            tmpEmployeeId ,
			IsEecoAvailable,
			ShowEECO,
			EECODeviceType,
			EECODeviceAddress,
			EmergencyPhone1,
			EmergencyPhone2,
			EmergencySMS,
			EmergencyEmail,
			EmergencyEmployeeIdEnteredBy,
			EmergencyDateFrom,
			IsPool,
            EmployeeIdAlternate,
            MobileVersion,
			ForwardStartDate,
			ForwardEndDate,
			[UsesMobile],
			[AppleDeviceToken],
			[ShowWelcomePage],
			[ShowVendorCoi],
			[ShowTenantCoi] ,
			[IsTenantCoiContact],
			[IsVendorCoiContact],
			[EmployeeSignature],
			DateCreated,
			Dateupdated,
			[CanViewPortfolioData]       ,
			[SubscriptionEmailAddress],
			IsPiAvailable,
			showPI ,
			[CanCreatePIProperty] ,
			[PrimaryEmailAddress]  ,
			[EmployeeTitle]              ,
			[DeviceNotes] ,
			Employee_cs_companyid,
			TenantIdScope,
			LearningId,
			LearningUserType,
			GeoDispatchEnabled,
			EmployeeStatus,
			TravellingMethod,
			DateEmployeeStatusUpdated,
			GPSMode,
			CredentialTokenDateExpiryUtc,
			CredentialToken,
			CanSSOLogin,
            CanScanAssetCode ,
			UsesGen5,
			IsPrimaryEmailVerified, -- new column
			UsesBeta				-- new column

        )
     select
            newEmployeeId ,
            ceCompanyId,
            RoleId,
            IsActiveEmployee,
            IsTrAvailable,
            IsPmAvailable,
            IsCallCenter,
            IsVendor,
            IsAccountLocked,
    	    IsMasterAuthor,
    		IsPropertyAuthor,
			0 as IsSubscriptionEnabled,
            ShowTR,
            ShowPM,
            ShowSM,
            UsesReports,
            UsesSetup,
            EmployeeHomePage,
            ReceivesNewsletters,
            ReceivesAnnouncements ,
            ReceivesServiceAlerts,
            NotifyMissingValues,
            NotifyCallAttention,
            FailedLoginAttempts,
            EmployeeFirstName,
            EmployeeLastName,
            ceUserName,
            ExternalEmployeeCode,
            PhoneNumber,
            TRDeviceType,
            ceTRDeviceAddress,
            TRCCEmailAddress,
            PMDeviceType,
            cePMDeviceAddress,
            TRDeviceTypeDescription,
            PMDeviceTypeDescription,
            NotifyEmailAddress,
            LocaleCode,
            PasswordChangeDate,
            LastLoginDate,
            PasswordExpiryDate,
            ceEncryptedPassword,
            -1,
			IsEecoAvailable,
			ShowEECO,
			EECODeviceType,
			EECODeviceAddress,
			EmergencyPhone1,
			EmergencyPhone2,
			EmergencySMS,
			EmergencyEmail,
			0 as EmergencyEmployeeIdEnteredBy,
			EmergencyDateFrom,
			--0 as IsPool,
			IsPool,
            employeeIdAlternate,
            MobileVersion,
			ForwardStartDate,
			ForwardEndDate,
			[UsesMobile],
			[AppleDeviceToken],
			[ShowWelcomePage],
			[ShowVendorCoi],
			[ShowTenantCoi] ,
			[IsTenantCoiContact],
			[IsVendorCoiContact],
			[EmployeeSignature]  ,
			getdate() as DateCreated,
			getdate() as Dateupdated,
			[CanViewPortfolioData],
			[SubscriptionEmailAddress],
			IsPiAvailable,
			showPI        ,
			[CanCreatePIProperty] ,
			'''' as [PrimaryEmailAddress]  ,
		    [EmployeeTitle]              ,
		    [DeviceNotes],
			'+@ToCompany+' as Employee_cs_companyid,
			TenantIdScope,
			-1 as LearningId,
			LearningUserType,
			GeoDispatchEnabled,
			EmployeeStatus,
			TravellingMethod,
			DateEmployeeStatusUpdated,
			GPSMode,
			CredentialTokenDateExpiryUtc,
			CredentialToken,
			CanSSOLogin,
            CanScanAssetCode ,
			UsesGen5,
			IsPrimaryEmailVerified,     -- new column
			UsesBeta					-- new column

    from
            tempe
end
';
    EXEC (@sql);

    PRINT 'Insert EmployeeAvailability';
    SET @sql = '
	  Select next value for seq_EmployeeAvailability over (Order By EmployeeAvailability.EmployeeAvailabilityId) as newEmployeeAvailabilityID, EmployeeAvailability.* into tempEmployeeAvailability from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeAvailability
	  inner join tempe on EmployeeAvailability.EmployeeId = tempe.EmployeeID
	  where tempe.employeeid <> 0

	  Update tempEmployeeAvailability
	  set employeeId = -3
	  where employeeId is not null and employeeId <> 0 

	  
		update vd
		set
			vd.employeeid = ulk.[NewID]
		From
			'+@ToDB+'.dbo.tempEmployeeAvailability vd with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeAvailability Fvd on vd.EmployeeAvailabilityID = Fvd.EmployeeAvailabilityID inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeid = ulk.oldid
		where
			vd.employeeid = -3 and ulk.tablename = ''Employee''

	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EmployeeAvailability'',
        	''EmployeeAvailabilityID'',
        	EmployeeAvailabilityID,
        	newEmployeeAvailabilityID
        From
           	dbo.tempEmployeeAvailability
			
---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEmployeeAvailability''
  ,@ToTable =''EmployeeAvailability''
  ,@CompanyId = '+@ToCompany+'


	  ';
    EXEC (@sql);
-- INSERT INTO [dbo].[EmployeeAvailability]
--            ([EmployeeAvailabilityId]
--            ,[EmployeeId]
--            ,[DayOfWeekFrom]
--            ,[DayOfWeekTo]
--            ,[TimeFrom]
--            ,[TimeTo]
--            ,[DateCreated]
--            ,[DateUpdated]
--            ,[EmployeeAvailability_CS_CompanyId]
-- 		   )

-- 		   select 
-- 		   [NewEmployeeAvailabilityId]
--            ,[EmployeeId]
--            ,[DayOfWeekFrom]
--            ,[DayOfWeekTo]
--            ,[TimeFrom]
--            ,[TimeTo]
--            ,[DateCreated]
--            ,[DateUpdated]
--             ,'+@ToCompany+' as  cs_companyid
-- 		   From tempEmployeeAvailability
	  

    PRINT 'Insert EmployeeLocation';
    SET @sql = '
	  Select next value for seq_EmployeeLocation over (Order By EmployeeLocation.EmployeeLocationId) as newEmployeeLocationID, EmployeeLocation.* into tempEmployeeLocation from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeLocation
	  inner join tempe on EmployeeLocation.EmployeeId = tempe.EmployeeID
	  where tempe.employeeid <> 0

	  Update tempEmployeeLocation
	  set employeeId = -3
	  where employeeId is not null and employeeId <> 0 

	  
		update vd
		set
			vd.employeeid = ulk.[NewID]
		From
			'+@ToDB+'.dbo.tempEmployeeLocation vd with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeLocation Fvd on vd.EmployeeLocationID = Fvd.EmployeeLocationID inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeid = ulk.oldid
		where
			vd.employeeid = -3 and ulk.tablename = ''Employee''

	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EmployeeLocation'',
        	''EmployeeLocationID'',
        	EmployeeLocationID,
        	newEmployeeLocationID
        From
           	dbo.tempEmployeeLocation
	---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEmployeeLocation''
  ,@ToTable =''EmployeeLocation''
  ,@CompanyId = '+@ToCompany+'

		

	  ';
    EXEC (@sql);
-- INSERT INTO [dbo].[EmployeeLocation]
--            (
-- 		   [EmployeeLocationId]
--            ,[EmployeeId]
--            ,[Longitude]
--            ,[Latitude]
--            ,[Speed]
--            ,[Bearing]
--            ,[Course]
--            ,[Accuracy]
--            ,[DateUpdated]
--            ,[EmployeeLocation_CS_CompanyId]
-- 		   )

-- 		   select 
-- 		   [NewEmployeeLocationId]
--            ,[EmployeeId]
--            ,[Longitude]
--            ,[Latitude]
--            ,[Speed]
--            ,[Bearing]
--            ,[Course]
--            ,[Accuracy]
--            ,[DateUpdated]
--            ,'+@ToCompany+' as  cs_companyid
-- 		   From tempEmployeeLocation	  

    PRINT 'Insert EmployeeVacation';
    SET @sql = '
	  Select next value for seq_EmployeeVacation over (Order By EmployeeVacation.EmployeeVacationId) as newEmployeeVacationID, EmployeeVacation.* into tempEmployeeVacation from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeVacation
	  inner join tempe on EmployeeVacation.EmployeeId = tempe.EmployeeID
	  where tempe.employeeid <> 0

	  Update tempEmployeeVacation
	  set employeeId = -3
	  where employeeId is not null and employeeId <> 0 

	  
		update vd
		set
			vd.employeeid = ulk.[NewID]
		From
			'+@ToDB+'.dbo.tempEmployeeVacation vd with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeVacation Fvd on vd.EmployeeVacationID = Fvd.EmployeeVacationID inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeid = ulk.oldid
		where
			vd.employeeid = -3 and ulk.tablename = ''Employee''

	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EmployeeVacation'',
        	''EmployeeVacationID'',
        	EmployeeVacationID,
        	newEmployeeVacationID
        From
           	dbo.tempEmployeeVacation
			
	---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEmployeeVacation''
  ,@ToTable =''EmployeeVacation''
  ,@CompanyId = '+@ToCompany+'


	  ';
    EXEC (@sql);
-- INSERT INTO [dbo].[EmployeeVacation]
--            (
-- 		  [EmployeeVacationId]
--            ,[EmployeeId]
--            ,[DateFrom]
--            ,[DateTo]
--            ,[DateCreated]
--            ,[DateUpdated]
--            ,[EmployeeVacation_CS_CompanyId]
-- 		   )

-- 		   select 
-- 		   [NewEmployeeVacationId]
--            ,[EmployeeId]
--            ,[DateFrom]
--            ,[DateTo]
--            ,[DateCreated]
--            ,[DateUpdated]
--            ,'+@ToCompany+' as  cs_companyid
-- 		   From tempEmployeeVacation
	  

/*
----------New Table 2022-11-19 no need for Transfer-----------
    PRINT 'Insert EmployeeLink';
    SET @sql = '
	  Select next value for seq_EmployeeLink as newEmployeeLinkID, EmployeeLink.* into tempEmployeeLink from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeLink
	  inner join tempe on EmployeeLink.EmployeeId = tempe.EmployeeID
	  where tempe.employeeid <> 0

	  Update tempEmployeeLink
	  set employeeId = -3, EmployeeIdLinked = -3
	  where employeeId is not null and employeeId <> 0 
  
	  update vd
	  set
	  	vd.employeeid = ulk.[NewID]
	  From
	  	'+@ToDB+'.dbo.tempEmployeeLink vd with (nolock) inner join
	  	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeLink Fvd on vd.EmployeeLinkID = Fvd.EmployeeLinkID inner join
	  	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeid = ulk.oldid
	  where
	  	vd.employeeid = -3 and ulk.tablename = ''Employee''

	  update vd
	  set
	  	vd.EmployeeIdLinked = ulk.[NewID]
	  From
	  	'+@ToDB+'.dbo.tempEmployeeLink vd with (nolock) 
		inner join 	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeLink Fvd on vd.EmployeeLinkID = Fvd.EmployeeLinkID 
		inner join 	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdLinked = ulk.oldid
	  where
	  	vd.EmployeeIdLinked = -3 and ulk.tablename = ''Employee''

	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EmployeeLink'',
        	''EmployeeLinkID'',
        	EmployeeLinkID,
        	newEmployeeLinkID
        From
           	dbo.tempEmployeeLink

INSERT INTO [dbo].[EmployeeLink]
           (
			EmployeeLinkId
			, EmployeeId
			, EmployeeIdLinked
			, Status
			, EmployeeLink_CS_CompanyId
		   )

		   select 
		    [NewEmployeeLinkId]
            ,[EmployeeId]
			, EmployeeIdLinked
			, Status
			, '+@ToCompany+' as  EmployeeLink_CS_CompanyId
		   From tempEmployeeLink	  

	  ';
    EXEC (@sql);
*/
-----------------------------------------
    PRINT 'Insert POOL';
    SET @sql = '
	  Select tempe.newEmployeeId as newPoolID, Pool.* into tempPool from '+@Fromserver+'.'+@FromDB+'.dbo.Pool
	  inner join tempe on Pool.Poolid = tempe.EmployeeID
	  where tempe.employeeid <> 0

	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Pool'',
        	''PoolID'',
        	PoolID,
        	newPoolID
        From
           	dbo.tempPool

	---- merge data
--    EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
--   ,@ToSchema =''dbo''
--   ,@FromTable =''pool''
--   ,@ToTable =''tempPool''
--   ,@CompanyId = '+@ToCompany+'

	  Insert into dbo.Pool
	  (Poolid, DispatchOption,pool_cs_companyid)
	  Select NewPoolID, DispatchOption , '+@ToCompany+' as pool_cs_companyid
	  from tempPool

	  Insert into dbo.EmployeePool
	  (PoolID,EmployeeID, employeePool_cs_companyid)

	  Select distinct tp.NewPoolid, te.NewEmployeeId ,'+@ToCompany+' as employeePool_cs_companyid 
	   from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeePool ep
	  inner join tempPool tp on ep.Poolid = tp.PoolId
	  inner join tempe te on ep.EmployeeId = te.EmployeeID

	  ';
    EXEC (@sql);
    PRINT 'Insert AvailableHour';
    SET @sql = '
select * into tempah
from '+@Fromserver+'.'+@FromDB+'.dbo.availablehour where propertyid in '+@FromProperty+'

update tempah
set
    tempah.propertyid = newPropertyid,
    tempah.companyid = '+@ToCompany+'
from
    tempproperty with (nolock)
where
    tempah.propertyid = tempproperty.propertyid


insert dbo.availablehour
(
	[CompanyId]
    ,[PropertyId]
    ,[DateStartOfWeek]
    ,[TRAvailableHours]
    ,[PMAvailableHours]
	,AvailableHour_cs_companyid
)
	select
	tah.[CompanyId]
	,tah.[PropertyId]
	,tah.[DateStartOfWeek]
	,tah.[TRAvailableHours]
	,tah.[PMAvailableHours]
	,'+@ToCompany+' as AvailableHour_cs_companyid
from tempah tah with (nolock) left outer join availablehour ah with (nolock) on tah.propertyid = ah.propertyid
where ah.propertyid is null
';
    EXEC (@sql);
    PRINT 'Insert WorkHour';
    SET @sql = '
Select  next value for seq_WorkHour over (order by wh.shiftid) as newshiftid, wh.*
into dbo.tempwh
from '+@Fromserver+'.'+@FromDB+'.dbo.workhour wh
where wh.propertyid in '+@FromProperty+'
--order by wh.shiftid

update tempwh
set
    tempwh.propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    tempwh.propertyid = tempproperty.propertyid

if exists (select * from tempwh) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''WorkHour'',
        	''ShiftID'',
        	ShiftID,
        	newShiftID
        From
           	dbo.tempwh

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempwh''
  ,@ToTable =''WorkHour''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.WorkHour
    --     (
    -- ShiftId       ,
    --         PropertyId    ,
    --         DowStart      ,
    --         DowEnd        ,
    --         TimeEnd       ,
    --         TimeStart     ,
    --         tmpBuildingId ,
	-- 		WorkHour_cs_companyid
    --     )
    -- select
    --         newShiftId       ,
    --         PropertyId    ,
    --         DowStart      ,
    --         DowEnd        ,
    --         TimeEnd       ,
    --         TimeStart     ,
    --         -1 ,
	-- 		'+@ToCompany+' as workhour_cs_companyid
    -- From
    --     tempwh

    PRINT 'Insert Event';
    SET @sql = '
Select  next value for seq_Event over (order by ev.eventid) as newEventId, ev.*
into dbo.TempEvent
from '+@Fromserver+'.'+@FromDB+'.dbo.Event ev
where ev.propertyid in '+@FromProperty+'
--order by ev.eventid

update TempEvent
set
    TempEvent.propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    TempEvent.propertyid = tempproperty.propertyid

if exists (select * from tempevent) Begin
    
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Event'',
        	''EventID'',
        	EventID,
        	newEventID
        From
           	dbo.tempEvent

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEvent''
  ,@ToTable =''Event''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Event
    --     (
    --        [EventId]
    --        ,[EventLevel]
    --        ,[PropertyId]
    --        ,[DateStart]
    --        ,[DateEnd]
    --        ,[EventDetail]
    --        ,[EventSubject]
    --        ,[tmpEventId]
	-- 	   ,event_cs_companyid
    --     ) Output
    --      ''Event'' as TableName ,
    --     ''EventID'' as columnname,
    --     INSERTED.tmpEventID as oldId,
    --     INSERTED.EventID     as [NewId]
	-- 	Into dbo.'+@lookup+'
	-- 		(
    -- 			TableName,
    --     		ColumnName,
    --     		OldId,
    --     		[NewId]
	-- 		)
    -- select
	-- 		[NewEventId]
    --        ,[EventLevel]
    --        ,[PropertyId]
    --        ,[DateStart]
    --        ,[DateEnd]
    --        ,[EventDetail]
    --        ,[EventSubject]
    --        ,EventID as [tmpEventId]
	-- 	   ,'+@ToCompany+' as event_cs_companyid 
    -- From
    --     dbo.tempevent

    PRINT 'Insert Escalation';
    SET @sql = '
Select  next value for seq_Escalation over (Order by Escalation.EscalationID) as newEscalationid, * into tempEsc
from '+@Fromserver+'.'+@FromDB+'.dbo.Escalation
where propertyId in '+@FromProperty+'

update tempEsc
set tempEsc.propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    tempEsc.propertyid = tempproperty.propertyid

update tempEsc
set tempEsc.requesttypeid = mapping.[NewId]
from
    mapping with (nolock)
where
    tempEsc.requesttypeid = mapping.fromId
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'
and
    mapping.tablename = ''RT''


 --select  PropertyId,RequestTypeId
	--	From tempesc where RequestTypeId not in (Select RequestTypeId from requesttype where companyid = '+@ToCompany+')
	--	order by 1,2
If exists (select * from tempesc) Begin

  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Escalation'',
        	''EscalationID'',
        	EscalationID,
        	newEscalationID
        From
           	dbo.tempesc


    Insert '+@ToDB+'.dbo.Escalation
        (
			EscalationId,
            PropertyId           ,
            RequestTypeId        ,
            MinutesEscalateOne   ,
            MinutesEscalateTwo   ,
            MinutesEscalateThree ,
            tmpBuildingId ,
			Escalation_cs_companyid
        )


    select
			max(NewEscalationId),
            PropertyId           ,
            RequestTypeId       ,
            (select top 1 te.MinutesEscalateOne from tempesc te with (nolock) where te.propertyid = tempesc.propertyid and te.requesttypeid = tempesc.requesttypeid) as MinutesEscalateOne,
            (select top 1 te.MinutesEscalateTwo from tempesc te with (nolock) where te.propertyid = tempesc.propertyid and te.requesttypeid = tempesc.requesttypeid) as MinutesEscalateTwo,
            (select top 1 te.MinutesEscalateThree from tempesc te with (nolock) where te.propertyid = tempesc.propertyid and te.requesttypeid = tempesc.requesttypeid) as MinutesEscalateThree,
			-1,
			'+@ToCompany+' as  Escalation_cs_companyid
		From
				tempesc
	Group by
		PropertyId,
		RequestTypeId

End
';
   EXEC (@sql);  -- Comment back
    PRINT 'Insert EP';
    SET @sql = '
select * into tempep
from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty
where propertyid in '+@FromProperty+'

update tempep
set tempep.propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    tempep.propertyid = tempproperty.propertyid

update tempep
set tempep.employeeid = tempce.newemployeeid
from
    tempce with (nolock)
where
    tempep.employeeid = tempce.employeeid

if exists (select * from tempep) Begin
    Insert '+@ToDB+'.dbo.employeeproperty
        (
            PropertyId        ,
            EmployeeId        ,
            IsDefaultProperty ,
			employeeproperty_cs_companyid
)
    select
            PropertyId        ,
            EmployeeId        ,
            IsDefaultProperty ,
			'+@ToCompany+' as employeeproperty_cs_companyid
    From
        tempep
End
';
    EXEC (@sql);

    PRINT 'Insert Building';
    SET @sql = '
Select next value for seq_building over (order by buildingId) as newbuildingid, b.*
into dbo.TempBuilding
from '+@Fromserver+'.'+@FromDB+'.dbo.Building b
where b.propertyid in '+@FromProperty+'
--order by buildingId
--------------
EXEC v3_Common.dbo.SetUserContext  ' + @fromcompany + '

update '+@FromServer+'.'+@FromDB+'.dbo.Building
set IntegrationIdentifier = Newid()
where propertyid in '+@FromProperty+' and buildingid <> 0 

EXEC v3_Common.dbo.SetUserContext  ' + @ToCompany + '
--------------
update tempbuilding
set  tempbuilding.propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    tempbuilding.propertyid = tempproperty.propertyid

if exists (select * from tempbuilding) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Building'',
        	''BuildingID'',
        	BuildingID,
        	NewBuildingID
        From
           	dbo.TempBuilding
Update TempBuilding set PropertyId = -3
update b
set
	b.propertyid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempBuilding b with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.building Fb on b.Buildingid = Fb.Buildingid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fb.propertyid = ulk.oldid
where
	b.propertyid = -3 and ulk.tablename = ''Property''

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempBuilding''
  ,@ToTable =''building''
  ,@CompanyId = '+@ToCompany+'


End
';
    EXEC (@sql);
    --  insert '+@ToDB+'.dbo.building
    --     (
    --         BuildingId              ,
    --         PropertyId              ,
    --         IsAddressSameAsProperty ,
    --         IsCommonBuilding        ,
    --         IsActiveBuilding        ,
    --         BuildingName            ,
    --         ExternalBuildingCode    ,
    --         BuildingAddress         ,
    --         ActiveUntil             ,
    --         DatetoDelete            ,
    --         SquareFootage           ,
    --         BuildingType            ,
    --         BuildingState           ,
    --         tmpPropertyId          ,
	-- 		City,
	-- 		State,
	-- 		StreetAddress,
	-- 		LocationCode,
	-- 		Country,
	-- 		YearBuilt ,
	-- 		ESCompanyID ,
	-- 		ESBuildingID,
	-- 		[CurrentEnergyStarRating],
    --         [DateEnergyStarRatingUpdated],
	-- 		ASGL_ProjectId,
    --         ASGL_ProjectNumber       ,
    --         BuildingClassId			,
	-- 		SecuritySystemAuthenticationToken,
	-- 		NameInsured,
	-- 		AcsId ,
	-- 		building_cs_companyid,
	-- 		buildingLatitude,
	-- 		BuildingLongitude,
	-- 		IntegrationIdentifier,
    --         AciServer 

    --     )
    -- select
    --         newBuildingId              ,
    --         PropertyId              ,
    --         IsAddressSameAsProperty ,
    --         IsCommonBuilding        ,
    --         IsActiveBuilding        ,
    --         BuildingName            ,
    --         ExternalBuildingCode    ,
    --         BuildingAddress         ,
    --         ActiveUntil             ,
    --         DatetoDelete            ,
    --         SquareFootage           ,
    --         BuildingType            ,
    --         BuildingState           ,
    --         -1,
	-- 		City,
	-- 		State,
	-- 		StreetAddress,
	-- 		LocationCode,
	-- 		Country,
	-- 		YearBuilt ,
	-- 		ESCompanyID ,
	-- 		ESBuildingID,
	-- 		[CurrentEnergyStarRating],
    --         [DateEnergyStarRatingUpdated],
	-- 		ASGL_ProjectId,
    --         ASGL_ProjectNumber ,
    --         BuildingClassId ,
	-- 		SecuritySystemAuthenticationToken,
	-- 		NameInsured,
	-- 		AcsId,
	-- 		'+@ToCompany+' as building_cs_companyid,
	-- 		buildingLatitude,
	-- 		BuildingLongitude,
	-- 		IntegrationIdentifier,
    --         AciServer 

    -- From
    --     tempbuilding
/*
    PRINT 'Insert LicenseCardAccessKey';
    SET @sql = '
Select next value for seq_LicenseCardAccessKey as newLicenseCardAccessKeyid, l.*
into dbo.TempLicenseCardAccessKey
from '+@Fromserver+'.'+@FromDB+'.dbo.LicenseCardAccessKey l
inner join building bu on l.buildingid = bu.buildingid
where bu.buildingid in '+@FromProperty+'



if exists (select * from tempLicenseCardAccessKey) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''LicenseCardAccessKey'',
        	''LicenseCardAccessKeyID'',
        	LicenseCardAccessKeyID,
        	NewLicenseCardAccessKeyID
        From
           	dbo.TempLicenseCardAccessKey

Update TempLicenseCardAccessKey set buildingid = -3
where buildingid is not null and buildingid <> 0 

update b
set
	b.buildingid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempLicenseCardAccessKey b with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.LicenseCardAccessKey Fb on b.LicenseCardAccessKeyid = Fb.LicenseCardAccessKeyid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fb.buildingid = ulk.oldid
where
	b.buildingid = -3 and ulk.tablename = ''building''

Update tempLicenseCardAccessKey
set CompanyId = ' + @ToCompany + '

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempLicenseCardAccessKey''
  ,@ToTable =''LicenseCardAccessKey''
  ,@CompanyId = '+@ToCompany+'

    --  insert '+@ToDB+'.dbo.LicenseCardAccessKey
    --     (
    --        [LicenseCardAccessKeyId]
    --        ,[CompanyId]
    --        ,[BuildingId]
    --        ,[ScannerAccessKey]
    --        ,[ScannerDescription]
    --        ,[DriverOnlineStatus]
    --        ,[LicenseCardAccessKey_CS_CompanyId]

    --     )
    -- select
    --         newLicenseCardAccessKeyId              ,
    --         ,[CompanyId]
    --        ,[BuildingId]
    --        ,[ScannerAccessKey]
    --        ,[ScannerDescription]
    --        ,[DriverOnlineStatus]
	-- 		'+@ToCompany+' as LicenseCardAccessKey_cs_companyid

    -- From
        -- tempLicenseCardAccessKey
End
';
    --  EXEC (@sql);  -- for now, do not copy it until Doug clarify it.
*/
    PRINT 'Insert Route';
    SET @sql = '
Select next value for seq_route over (Order By r.RouteId) as newrouteId, r.* into temproute
from '+@Fromserver+'.'+@FromDB+'.dbo.route r  inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b  on b.buildingid = r.buildingid
inner join  '+@Fromserver+'.'+@FromDB+'.dbo.WorkHour wh  on r.shiftid = wh.Shiftid
where b.propertyId in '+@FromProperty+'
and (wh.propertyid in '+@FromProperty+'   or wh.propertyid = 0)

update temproute
set temproute.Buildingid = tempbuilding.newBuildingid
from
    tempbuilding with (nolock)
where
    temproute.Buildingid =  tempbuilding.Buildingid

update temproute
set temproute.requesttypeid = mapping.[NewId]
from
    mapping with (nolock)
where
    temproute.requesttypeid = mapping.fromId
and
    mapping.tablename = ''RT''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update temproute
set temproute.shiftid = tempwh.newshiftId
from
    tempwh with (nolock)
where
    temproute.shiftid = tempwh.shiftId

update temproute
set temproute.employeeid = tempce.newemployeeid
from
    tempce with (nolock)
where
    temproute.employeeid = tempce.employeeid

if exists (select * from temproute) Begin

  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Route'',
        	''RouteID'',
        	RouteID,
        	NewRouteID
        From
           	dbo.temproute


     insert '+@ToDB+'.dbo.Route
        (
			[RouteId] ,
            Buildingid    ,
            RequestTypeId ,
            ShiftId       ,
            EmployeeId    ,
            DispatchNote  ,
            IsPropertyLevelRoute,
            IsPropertyLevelNote,
            tmpBuildingId ,
			route_cs_companyid
        )

    Select
		max(NewRouteId),
            Buildingid    ,
            RequestTypeId,
            ShiftId,
       --     EmployeeId  ,
            (select top 1 te.EmployeeId from temproute te where te.Buildingid = temproute.Buildingid and te.requesttypeid = temproute.requesttypeid and te.shiftid = temproute.shiftid)  as employeeId,
            (select top 1 te.DispatchNote from temproute te where te.Buildingid = temproute.Buildingid and te.requesttypeid = temproute.requesttypeid and te.shiftid = temproute.shiftid)  as DispatchNote,
            (select top 1 te.IsPropertyLevelRoute from temproute te where te.Buildingid = temproute.Buildingid and te.requesttypeid = temproute.requesttypeid and te.shiftid = temproute.shiftid)  as IsPropertyLevelRoute,
--			IsPropertyLevelRoute,
            (select top 1 te.IsPropertyLevelNote from temproute te where te.Buildingid = temproute.Buildingid and te.requesttypeid = temproute.requesttypeid and te.shiftid = temproute.shiftid)  as IsPropertyLevelNote,
            -1,
			'+@ToCompany+' as route_cs_companyid

    From
        temproute
		Group by
			 Buildingid    ,
            RequestTypeId,
            ShiftId
End
';
   EXEC (@sql);
    PRINT 'Insert Area';
    SET @sql = '
Select next value for seq_Area over (order by a.areaid) as  newareaid, a.*
into temparea
from '+@Fromserver+'.'+@FromDB+'.dbo.area a  inner join tempbuilding b  on b.buildingid = a.buildingid
--order by a.areaid
-----------------------
EXEC v3_Common.dbo.SetUserContext  ' + @fromcompany + '

update a
set IntegrationIdentifier = Newid()
from '+@FromServer+'.'+@FromDB+'.dbo.area  a 
inner join '+@FromServer+'.'+@FromDB+'.dbo.Building b on b.buildingid =  a.buildingid
where b.propertyid in '+@FromProperty+' and  a.areaid <> 0 

EXEC v3_Common.dbo.SetUserContext  ' + @ToCompany + '
-----------------------

update temparea
set temparea.buildingid = b.newbuildingid
from
    tempbuilding b with (nolock)
where
    temparea.buildingid = b.buildingid

If exists (select * from temparea) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Area'',
        	''AreaID'',
        	areaID,
        	Newareaid
        From
           	dbo.Temparea
update Temparea set BuildingId = -3
update a
set
	a.buildingId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Temparea a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.area Fa on a.areaid = Fa.areaid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.buildingid = ulk.oldid
where
	a.buildingid = -3 and ulk.tablename = ''building''

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] 
   @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''temparea''
  ,@ToTable =''area''
  ,@CompanyId = '+@ToCompany+'
    

End
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.area
    --     (
    --         AreaId            ,
    --         BuildingId        ,
    --         IsTrArea          ,
    --         IsPmArea          ,
    --         IsCommonArea      ,
	-- 		IsActiveArea      ,
    --         Floor ,
    --         Suite             ,
    --         ExternalFloorCode ,
    --         ExternalSuiteCode ,
    --         tmpSubLocationId   ,
	-- 		AciVisitorAccessLevel,
	-- 		area_cs_companyid,
	-- 		AciSegmentName,
	-- 		IntegrationIdentifier 
    --     )
    -- Select
    --         newAreaId         ,
    --         BuildingId        ,
    --         IsTrArea          ,
    --         IsPmArea          ,
    --         IsCommonArea      ,
    --         IsActiveArea      ,
    --         Floor             ,
    --         Suite             ,
    --         ExternalFloorCode ,
    --         ExternalSuiteCode ,
    --         -1,
	-- 		AciVisitorAccessLevel,
	-- 		'+@ToCompany+' as area_cs_companyid,
	-- 		AciSegmentName,
	-- 		IntegrationIdentifier 
    -- From
    --     temparea
    PRINT 'Insert Tenant';
    SET @sql = '
Select next value for seq_tenant over (order by t.TenantId)  as newTenantId, t.*
into dbo.Temptenant
from '+@Fromserver+'.'+@FromDB+'.dbo.tenant t  inner join tempproperty p  on p.propertyid = t.BasePropertyId
--order by t.tenantid
-----------------------
EXEC v3_Common.dbo.SetUserContext  ' + @fromcompany + '

update '+@FromServer+'.'+@FromDB+'.dbo.Tenant
set IntegrationIdentifier = Newid()
where BasePropertyID in  '+@FromProperty+'

EXEC v3_Common.dbo.SetUserContext  ' + @ToCompany + '
-----------------------


Alter table tempTenant
add NewTenantIdParent int

update temptenant
set BasePropertyId = newpropertyid
from
    tempproperty with (nolock)
where
    BasePropertyId = propertyid

Update temptenant
set
	TenantGroupID = 0


Update temptenant
set
	NewTenantIdParent = TenantIdParent

Update temptenant set TenantIdParent= 0



if exists (select * from temptenant) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Tenant'',
        	''TenantID'',
        	TenantID,
        	NewTenantID
        From
           	dbo.TempTenant

update TempTenant set basepropertyid = -3
update t
set
	t.basepropertyid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTenant t with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.tenant Ft on t.tenantid = Ft.tenantid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ft.BasePropertyid = ulk.oldid
where
	t.basepropertyid = -3 and ulk.tablename = ''Property''

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempTenant''
  ,@ToTable =''Tenant''
  ,@CompanyId = '+@ToCompany+'
  



--Update TempTenant
--set
--	NewTenantID = m.[NewID]
--From
--	TempTenant inner join dbo.'+@lookup+' m on TempTenant.TenantID = m.OldID
--where
--	m.Tablename = ''Tenant''



update t1
set t1.TenantIdParent = t2.newtenantid
from
    temptenant t1 with (nolock) inner join temptenant t2 with (nolock) on t1.NewTenantIdParent = t2.tenantid

Update Tenant
set
	TenantIdParent = t1.TenantIdParent
from
	Tenant inner join temptenant t1 on Tenant.tmpTenantID = t1.TenantID inner join
dbo.'+@lookup+' m on Tenant.TenantID = m.[NewID]
where
	m.Tablename = ''Tenant''

End
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Tenant
    --     (
	-- 		[TenantId]
    --        ,[BasePropertyId]
    --        ,[TenantIdParent]
    --        ,[TenantGroupId]
    --        ,[IsActiveTenant]
    --        ,[IsTenantTaxExempt]
    --        ,[IsTenantAutoVerified]
    --        ,[IsCorporateTenant]
    --        ,[AuthorizationType]
    --        ,[BillableResRequireAuth]
    --        ,[TenantName]
    --        ,[TenantPhone]
    --        ,[ExternalTenantCode]
    --        ,[BaseExternalServiceAddressCode]
    --        ,[BillingAddress]
    --        ,[TenantCustom1]
    --        ,[TenantCustom2]
    --        ,[tmpTenantId]
    --        ,[IsBillable]
    --        ,[TenantFax]
    --        ,[Notes]
	-- 	   ,IsCoiRequired
	-- 	   ,BusinessNameAlias
	-- 	   ,ShowInDirectory
		   
	-- 	   ,Tenant_cs_companyid
	-- 	   ,DateToDeactivate 
	-- 	   ,IntegrationIdentifier
	-- 	   ,UsesSSO 
    --     )

    -- Select
    --         NewTenantId
    --         ,[BasePropertyId]
    --        ,[TenantIdParent]
    --        ,[TenantGroupId]
    --        ,[IsActiveTenant]
    --        ,[IsTenantTaxExempt]
    --        ,[IsTenantAutoVerified]
    --        ,[IsCorporateTenant]
    --        ,[AuthorizationType]
    --        ,[BillableResRequireAuth]
    --        ,[TenantName]
    --        ,[TenantPhone]
    --        ,[ExternalTenantCode]
    --        ,[BaseExternalServiceAddressCode]
    --        ,[BillingAddress]
    --        ,[TenantCustom1]
    --        ,[TenantCustom2]
    --        ,[tmpTenantId]
    --        ,[IsBillable]
    --        ,[TenantFax]
    --        ,[Notes]
	-- 	   ,IsCoiRequired
	-- 	   ,BusinessNameAlias
	-- 	   ,ShowInDirectory
    --        ,'+@ToCompany+' as  Tenant_cs_companyid
	-- 	   ,DateToDeactivate 
	-- 	   ,IntegrationIdentifier 
	-- 	   ,UsesSSO
    -- From
	-- 		TempTenant
    PRINT 'Insert TenantBilling';
    SET @sql = '
Select next value for seq_TenantBilling over (order by d.TenantBillingId) as NewTenantBillingId, d.*
into tempTenantbilling
from '+@Fromserver+'.'+@FromDB+'.dbo.TenantBilling d  inner join temptenant tt  on tt.tenantid = d.tenantid
--order by TenantBillingID

Update temptenantBilling
set tenantID = -3
where TenantID <> 0

update d
set
	d.tenantid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempTenantbilling d with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Tenantbilling Fd on d.TenantBillingID = Fd.TenantbillingID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fd.tenantid = ulk.oldid
where
	d.tenantid = -3 and ulk.tablename = ''tenant''


	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''TenantBilling'',
        	''TenantBillingID'',
        	TenantBillingID,
        	NewTenantBillingID
        From
           	dbo.tempTenantbilling

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempTenantbilling''
  ,@ToTable =''TenantBilling''
  ,@CompanyId = '+@ToCompany+'
  

        ';
    EXEC (@sql);
--  insert '+@ToDB+'.dbo.[TenantBilling]
--     (
--         TenantBillingId
-- 		,[TenantId]
--         ,[ShippingCode]
--         ,[BillingCode]
--         ,[DivisionCode]
--         ,[SubDivisionCode]
-- 		,TenantBilling_cs_companyid
--     )

--     Select
-- 		   NewTenantBillingId
--            ,[TenantId]
--            ,[ShippingCode]
--            ,[BillingCode]
--            ,[DivisionCode]
--            ,[SubDivisionCode]
-- 		   ,'+@ToCompany+' as  TenantBilling_cs_companyid

--     From
--         tempTenantbilling

    PRINT 'Insert Address';
    SET @sql = '
Select  next value for seq_Address over (order by a.AddressId) as newAddressId, a.*
into dbo.tempaddress
from '+@Fromserver+'.'+@FromDB+'.dbo.address a
inner join tempbuilding b  on b.BuildingId = a.BuildingId
where a.TenantId = 0 or a.TenantId in (select TenantId from temptenant)
--order by a.AddressId

update tempaddress
set
    tempaddress.buildingid = tempbuilding.newbuildingid
from
    tempbuilding with (nolock)
where
    tempaddress.buildingid = tempbuilding.buildingid

update tempaddress
set
    tempaddress.tenantid = temptenant.newtenantid
from
    temptenant with (nolock)
where
    tempaddress.tenantid = temptenant.tenantid

if exists (select * from TempAddress) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Address'',
        	''AddressID'',
        	AddressID,
        	newAddressID
        From
           	dbo.TempAddress

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAddress''
  ,@ToTable =''Address''
  ,@CompanyId = '+@ToCompany+'


End
';
    EXEC (@sql);
--     insert '+@ToDB+'.dbo.Address
--     (
--         AddressId              ,
--         TenantId               ,
--         BuildingId             ,
--         ExternalAddressCode    ,
--         ExternalAltAddressCode ,
--         TenantName             ,
--         TenantAddress          ,
-- 		ExternalPropertyCode ,
-- 		Address_cs_Companyid
-- )
--     Select
--         newAddressId              ,
--         TenantId               ,
--         BuildingId             ,
--         ExternalAddressCode    ,
--         ExternalAltAddressCode ,
--         TenantName             ,
--         TenantAddress          ,
--         ExternalPropertyCode ,
-- 		'+@ToCompany+' as  cs_companyid
--     From
-- 		TempAddress
    PRINT 'Insert Departmant';
    SET @sql = '
Select next value for seq_Department  over (order by d.DepartmentId) as newDepartmentId, d.*
into tempd
from '+@Fromserver+'.'+@FromDB+'.dbo.Department d  inner join temptenant tt  on tt.tenantid = d.tenantid
--order by DepartmentId

update tempd
set
    tempd.tenantid = temptenant.newtenantid
from
    temptenant with (nolock)
where
    tempd.tenantid = temptenant.tenantid

if exists (select * from tempd) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Department'',
        	''DepartmentId'',
    	DepartmentId,
        	newDepartmentId
        From
           	dbo.Tempd

update Tempd set TenantId = -3
update d
set
	d.tenantid = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempd d with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Department Fd on d.Departmentid = Fd.Departmentid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fd.tenantid = ulk.oldid
where
	d.tenantid = -3 and ulk.tablename = ''tenant''

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempd''
  ,@ToTable =''Department''
  ,@CompanyId = '+@ToCompany+'
  
end
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Department
    -- (

    --    [DepartmentId]
    --        ,[TenantId]
    --        ,[BillableResRequireAuth]
    --        ,[DepartmentName]
    --        ,[tmpDepartmentId]
	-- 	   ,Department_cs_companyid
    -- )
    -- Select
    --     NewDepartmentId,
    --     tenantid,
    --     BillableResRequireAuth ,
	-- 	DepartmentName         ,
    --     DepartmentID as tmpDepartmentID
	-- 	 ,'+@ToCompany+' as  cs_companyid
    -- From
    --     tempd

    PRINT 'Insert Contact';
    SET @sql = '
Select next value for seq_Contact over (order by c.ContactId) as newContactId, c.*
into dbo.TempContact
from '+@Fromserver+'.'+@FromDB+'.dbo.contact c  
inner join temptenant tt  on tt.tenantid = c.BaseTenantId
--order by c.contactid
-----------------------
EXEC v3_Common.dbo.SetUserContext  ' + @fromcompany + '

update '+@FromServer+'.'+@FromDB+'.dbo.contact
    set	IntegrationIdentifier = Newid()
where ContactId>0 and ContactId in (select ContactId from tempcontact)

exec v3_Common.dbo.SetUserContext  ' + @ToCompany + '
--------------------------
update tempcontact
set
    tempcontact.BaseAreaId = temparea.newareaid
from
    temparea with (nolock)
where
    tempcontact.BaseAreaId = temparea.areaid

update tempcontact
set
    tempcontact.DepartmentId = tempd.newDepartmentId
from
    tempd with (nolock)
where
    tempcontact.DepartmentId = tempd.DepartmentId

update tempcontact
set
    tempcontact.BaseTenantId = temptenant.newTenantId
from
    temptenant with (nolock)
where
    tempcontact.BaseTenantId = temptenant.TenantId

if '+@ResetContactEmail+' = 1 Begin
    Update tempcontact
    Set ContactEmailAddress = ''''
End
if exists (select * from tempcontact) Begin

update tempcontact set basetenantid = -3, baseareaid = -3, DepartmentId = -3
update tempcontact set EmergencyEmployeeIdEnteredBy = -3 where EmergencyEmployeeIdEnteredBy is not null and EmergencyEmployeeIdEnteredBy <> 0

update c
set
	c.basetenantid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempcontact c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.contact Fc on c.contactid = Fc.contactid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.basetenantid = ulk.oldid
where
	c.basetenantid = -3 and ulk.tablename = ''tenant''

update c
set
	c.baseareaid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempcontact c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.contact Fc on c.contactid = Fc.contactid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.baseareaid = ulk.oldid
where
	c.baseareaid = -3 and ulk.tablename = ''area''

update c
set
	c.DepartmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempcontact c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.contact Fc on c.contactid = Fc.contactid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.DepartmentId = ulk.oldid
where
	c.DepartmentId = -3 and ulk.tablename = ''Department''


update c
set
	c.EmergencyEmployeeIdEnteredBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempcontact c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.contact Fc on c.contactid = Fc.contactid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.EmergencyEmployeeIdEnteredBy = ulk.oldid
where
	c.EmergencyEmployeeIdEnteredBy = -3 and ulk.tablename = ''Employee''

Update tempcontact
set EmergencyEmployeeIdEnteredBy = 0
where EmergencyEmployeeIdEnteredBy = -3

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Contact'',
        	''ContactId'',
       		ContactId,
  			newContactId
        From
      	dbo.tempcontact

		--select * from tempcontact where baseAreaid not in (Select areaid from area)


		Update tempcontact
		set baseAreaid = (select top 1 newAreaId from tempArea where newAreaId <> 0)
		 where baseAreaid not in (Select areaid from area)


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempContact''
  ,@ToTable =''contact''
  ,@CompanyId = '+@ToCompany+'



End
';
    EXEC (@sql);
	-- insert '+@ToDB+'.dbo.contact
    -- (
    --     ContactId,
    --     BaseTenantId,
    --     BaseAreaId,
    --     DepartmentId,
    --     IsActiveContact,
    --     IsRequester,
    --     IsAuthorizer,
    --     IsHost,
    --     IsReceptionist,
    --     IsReserver,
    --     IsAdministrator,
    --     IsTenantAuthorizer,
	-- 	IsCOISubscribed,
    --     WantsAuthorizationEmail,
    --     CanViewColleaguesRequests,
    --     CanViewColleaguesReservations,
    --     CanViewColleaguesVisits,
    --     CanGrantColleaguesRequests,
    --     CanGrantColleaguesReservations,
    --     LastLoginDate,
    --     LastPasswordChangeDate,
    --    -- ContactName,
    --     ExternalContactCode,
    --     Username,
    --     ContactEmailAddress,
    --     AlternateEmailAddress,
    --     ContactPhoneNumber,
    --     ContactFaxNumber,
    --     LocaleCode,
    --     EncryptedPassword,
    --     tmpContactId,
	-- 	EmergencyPhone1,
	-- 	EmergencyPhone2,
	-- 	EmergencyEmail,
	-- 	EmergencySms,
	-- 	EmergencyEmployeeIdEnteredBy,
	-- 	EmergencyDateFrom,
    --     CanGrantColleaguesVisits,
    --     [CanSubscribeToAnnouncement],
	-- 	[CanSubscribeToEmergency] ,
	-- 	[CanGrantColleaguesAnnouncement],
	-- 	[CanGrantColleaguesEmergency]    ,
	-- 	ContactTitle,
	-- 	ContactNotes   ,
	-- 	[CanAccessTenantGroupProperties],
	-- 	[CanAccessBillingReport]    ,
	-- 	[AccessCardNumber]  ,
	-- 	CanGrantColleagesBillingReports,
	-- 	[UsesMobile],
	-- 	ContactFirstName,
	-- 	ContactLastName,
	-- 	ShowInDirectory,
	-- 	WasTerminated,
	-- 	UsesTenantIntegration,
	-- 	contact_cs_companyid
	-- 	,DateToDeactivate 
	-- 	,IntegrationIdentifier 
	-- 	,ExternalSource
	-- 	,CredentialTokenDateExpiryUtc
	-- 	,CredentialToken
	-- 	,CanSSOLogin
    -- )
    -- Select
    --     newContactId               ,
    --     BaseTenantId,
    --     BaseAreaId,
    --     DepartmentId,
    --     IsActiveContact,
    --     IsRequester,
    --     IsAuthorizer,
    --     IsHost,
    --     IsReceptionist,
    --     IsReserver,
    --     IsAdministrator,
    --     IsTenantAuthorizer,
	-- 	IsCOISubscribed,
    --     WantsAuthorizationEmail,
    --     CanViewColleaguesRequests,
    --     CanViewColleaguesReservations,
    --     CanViewColleaguesVisits,
    --     CanGrantColleaguesRequests,
    --     CanGrantColleaguesReservations,
    --     LastLoginDate,
    --     LastPasswordChangeDate,
    --     --ContactName,
    --     ExternalContactCode,
    --     Username,
    --     ContactEmailAddress,
    --     AlternateEmailAddress,
    --     ContactPhoneNumber,
    --     ContactFaxNumber,
    --     LocaleCode,
    --     EncryptedPassword,
    --     -1,
	-- 	EmergencyPhone1,
	-- 	EmergencyPhone2,
	-- 	EmergencyEmail,
	-- 	EmergencySms,
	-- 	EmergencyEmployeeIdEnteredBy,
	-- 	EmergencyDateFrom ,
    --     CanGrantColleaguesVisits,
    --     [CanSubscribeToAnnouncement],
	-- 	[CanSubscribeToEmergency] ,
	-- 	[CanGrantColleaguesAnnouncement],
	-- 	[CanGrantColleaguesEmergency] ,
	-- 	ContactTitle,
	-- 	ContactNotes ,
	-- 	[CanAccessTenantGroupProperties],
	-- 	[CanAccessBillingReport]  ,
	-- 	[AccessCardNumber],
	-- 	CanGrantColleagesBillingReports,
	-- 	[UsesMobile],
	-- 	ContactFirstName,
	-- 	ContactLastName,
	-- 	ShowInDirectory,
	-- 	WasTerminated,
	-- 	UsesTenantIntegration
	-- 	 ,'+@ToCompany+' as  cs_companyid
	-- 	 ,DateToDeactivate 
	-- 	 ,IntegrationIdentifier 
	-- 	 ,ExternalSource
	-- 	 ,CredentialTokenDateExpiryUtc
	-- 	 ,CredentialToken
	-- 	 ,CanSSOLogin

    -- From
    --     tempContact

    PRINT 'Insert ContactSecurityDesignation';
    SET @sql = '
Select  next value for seq_ContactSecurityDesignation over (Order By c.ContactSecurityDesignationId) as NewContactSecurityDesignationId, c.*
into dbo.TempContactSecurityDesignation
from '+@Fromserver+'.'+@FromDB+'.dbo.ContactSecurityDesignation c  inner join tempContact tt  on tt.ContactId = c.ContactId


update tempContactSecurityDesignation set [ContactId] = -3
where [ContactId]  is not null or ContactId <> 0


update c
set
	c.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempContactSecurityDesignation c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ContactSecurityDesignation Fc on c.ContactSecurityDesignationid = Fc.ContactSecurityDesignationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ContactId = ulk.oldid
where
	c.ContactId = -3 and ulk.tablename = ''Contact''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ContactSecurityDesignation'',
        	''ContactSecurityDesignationId'',
       		ContactSecurityDesignationId,
  			newContactSecurityDesignationId
        From
      	dbo.TempContactSecurityDesignation

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempContactSecurityDesignation''
  ,@ToTable =''ContactSecurityDesignation''
  ,@CompanyId = '+@ToCompany+'
  

';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ContactSecurityDesignation
    -- (

	-- 	[ContactSecurityDesignationId]
    --        ,[ContactId]
    --        ,[SecurityDesignationTypeId]
	-- 	   ,ContactSecurityDesignation_cs_companyid
    -- )
    -- Select
	-- 	[NewContactSecurityDesignationId]
    --        ,[ContactId]
    --        ,[SecurityDesignationTypeId]
	-- 	    ,'+@ToCompany+' as  cs_companyid
    -- From
    --     tempContactSecurityDesignation


    PRINT 'Insert PackagePass';
    SET @sql = '
Select  next value for seq_PackagePass over (order by c.PackagePassId) as NewPackagePassId, c.*
into dbo.TempPackagePass
from '+@Fromserver+'.'+@FromDB+'.dbo.PackagePass c  inner join temptenant tt  on tt.tenantid = c.TenantId
--order by c.PackagePassid

update tempPackagePass set [TenantId] = -3
where [TenantId]  is not null or Tenantid <> 0


update tempPackagePass
set [AreaId] = -3
where Areaid is not null or Areaid <>0


update tempPackagePass
set [ContactIdEnteredBy] = -3
where ContactIdEnteredBy is not null or ContactIdEnteredBy <>0


update tempPackagePass
set [ContactIdFor] = -3
where [ContactIdFor] is not null or [ContactIdFor] <>0

update c
set
	c.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempPackagePass c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.PackagePass Fc on c.PackagePassid = Fc.PackagePassid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.TenantId = ulk.oldid
where
	c.TenantId = -3 and ulk.tablename = ''tenant''

update c
set
	c.AreaId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempPackagePass c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.PackagePass Fc on c.PackagePassid = Fc.PackagePassid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.AreaId = ulk.oldid
where
	c.AreaId = -3 and ulk.tablename = ''area''

update c
set
	c.ContactIdEnteredBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempPackagePass c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.PackagePass Fc on c.PackagePassid = Fc.PackagePassid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ContactIdEnteredBy = ulk.oldid
where
	c.ContactIdEnteredBy = -3 and ulk.tablename = ''Contact''

update c
set
	c.ContactIdFor = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempPackagePass c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.PackagePass Fc on c.PackagePassid = Fc.PackagePassid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ContactIdFor = ulk.oldid
where
	c.ContactIdFor = -3 and ulk.tablename = ''Contact''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''PackagePass'',
        	''PackagePassId'',
       		PackagePassId,
  			newPackagePassId
        From
      	dbo.TempPackagePass

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempPackagePass''
  ,@ToTable =''PackagePass''
  ,@CompanyId = '+@ToCompany+'

';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.PackagePass
    -- (

	-- 	[PackagePassId]
    --     ,[TenantId]
    --     ,[AreaId]
    --     ,[ContactIdEnteredBy]
    --    -- ,[DateCreatedUtc]
    --     ,[DateExpiry]
    --     ,[ContactIdFor]
    --     ,[ContactNameFor]
    --     ,[Details]
    --     ,[Status]
    --     ,[AuthorizationNotes]
	-- 	,PackagePass_cs_companyid
        
    -- )
    -- Select
	-- 	[NewPackagePassId]
    --     ,[TenantId]
    --     ,[AreaId]
    --     ,[ContactIdEnteredBy]
    --     --,[DateCreatedUtc]
    --     ,[DateExpiry]
    --     ,[ContactIdFor]
    --     ,[ContactNameFor]
    --     ,[Details]
    --     ,[Status]
    --     ,[AuthorizationNotes]
	-- 	,'+@ToCompany+' as  cs_companyid
	-- 	--,[DateAuthorizedUtc]
    -- From
    --     tempPackagePass
    PRINT 'Insert Reservation';
    SET @sql = '
Select next value for seq_Document over (order by r.ReservationId) as newReservationId, r.*
into dbo.TempReservation
from '+@Fromserver+'.'+@FromDB+'.dbo.Reservation r  
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b on r.buildingid = b.buildingid
where b.propertyid in '+@FromProperty+'

update tr
set
    tr.contactid = c.newcontactid
from
    TempReservation tr with (nolock) inner join tempcontact c with (nolock)
on
    tr.contactid = c.contactid

update tr
set
    tr.tenantid = c.newtenantid
from
    TempReservation tr with (nolock) inner join temptenant c with (nolock)
on
    tr.tenantid = c.tenantid

update tr
set
    tr.BuildingId = c.newBuildingId
from
    TempReservation tr with (nolock) inner join tempBuilding c with (nolock)
on
    tr.BuildingId = c.BuildingId

update tr
set
    tr.ContactIdEnteredBy = c.newcontactid
from
    TempReservation tr with (nolock) inner join tempcontact c with (nolock)
on
    tr.ContactIdEnteredBy = c.contactid


update tr
set
    tr.EmployeeIdEnteredBy = c.newEmployeeId
from
    TempReservation tr with (nolock) inner join tempce c with (nolock)
on
    tr.EmployeeIdEnteredBy = c.EmployeeId



update tr
set
    tr.EmployeeIdReviewedBy = c.newEmployeeId
from
    TempReservation tr with (nolock) inner join tempce c with (nolock)
on
    tr.EmployeeIdReviewedBy = c.EmployeeId



if exists (select * from TempReservation) Begin

update TempReservation set ContactId = -3, TenantId = -3,  buildingID = -3,ContactIdEnteredBy = -3, EmployeeIdEnteredBy = -3, EmployeeIDReviewedBy = -3

update TempReservation
set ContactIdEditedBy = -3
where ContactIdEditedBy is not null and ContactIdEditedBy <> 0


update TempReservation
set EmployeeIdEditedBy = -3
where EmployeeIdEditedBy is not null and EmployeeIdEditedBy <> 0

update r
set
	r.contactid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservation r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reservation Fr on r.Reservationid = Fr.Reservationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.contactid = ulk.oldid
where
	r.contactid = -3 and ulk.tablename = ''contact''


update r
set
	r.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservation r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reservation Fr on r.Reservationid = Fr.Reservationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.TenantId = ulk.oldid
where
	r.TenantId = -3 and ulk.tablename = ''Tenant''

update r
set
	r.BuildingId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservation r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reservation Fr on r.Reservationid = Fr.Reservationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.BuildingId = ulk.oldid
where
	r.BuildingId = -3 and ulk.tablename = ''Building''

update r
set
	r.ContactIdEnteredBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservation r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reservation Fr on r.Reservationid = Fr.Reservationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.ContactIdEnteredBy = ulk.oldid
where
	r.ContactIdEnteredBy = -3 and ulk.tablename = ''Contact''

update r
set
	r.EmployeeIdEnteredBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservation r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reservation Fr on r.Reservationid = Fr.Reservationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.EmployeeIdEnteredBy = ulk.oldid
where
	r.EmployeeIdEnteredBy = -3 and ulk.tablename = ''CommonEmployee''


update r
set
	r.EmployeeIdReviewedBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservation r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reservation Fr on r.Reservationid = Fr.Reservationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.EmployeeIdReviewedBy = ulk.oldid
where
	r.EmployeeIdReviewedBy = -3 and ulk.tablename = ''CommonEmployee''


update r
set
	r.ContactIdEditedBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservation r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reservation Fr on r.Reservationid = Fr.Reservationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.contactid = ulk.oldid
where
	r.ContactIdEditedBy = -3 and ulk.tablename = ''contact''


update r
set
	r.EmployeeIdEditedBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservation r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reservation Fr on r.Reservationid = Fr.Reservationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.EmployeeIdEnteredBy = ulk.oldid
where
	r.EmployeeIdEditedBy = -3 and ulk.tablename = ''CommonEmployee''


	select * from TempReservation where tenantid not in (select Tenantid from tenant)

	Update TempReservation set tenantid = 0 where tenantid not in (select Tenantid from tenant)

	
	select * from TempReservation where contactid not in (select contactid from contact)

	Update TempReservation set contactid = 0 where contactid not in (select contactid from contact)

	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Reservation'',
        	''ReservationId'',
        	ReservationId,
        	newReservationId
        From
           	dbo.TempReservation

 Select
        newReservationId       ,
        ReservationStatus,
        ContactId,
        TenantId,
        BuildingId,
        ContactIdEnteredBy,
        EmployeeIdEnteredBy,
        EmployeeIdReviewedBy,
        IsCancellationChargeApplied,
        DurationMinutes,
        DateCreated,
        DateRequired,
        DateReviewed,
		DateUpdated,
        ReservationNotes,
        InternalNotes,
        ReasonForRejection  ,

		IsReschedulingChargeApplied,
		ApplyCancellationChargeLater,
		ApplyReschedulingChargeLater,
		ContactIdEditedBy,
		EmployeeIdEditedBy,
		BusinessLogicVersion,
		
		Reservation_cs_companyid,
		[TnCAccepted],
		[DocPendingEmailReminderVersion],
		[DisplayPreference],
		[HostCompanyName]
    From
        TempReservation
		where EmployeeIdEnteredBy  not in (Select employeeid from employee)

		Update TempReservation
		set EmployeeIdReviewedBy = 0
		where EmployeeIdReviewedBy  not in (Select employeeid from employee)

	select * from TempReservation where ContactIdEnteredBy not in (select contactid from contact)
	Update TempReservation set ContactIdEnteredBy = 0 where ContactIdEnteredBy not in (select contactid from contact)


	select * from TempReservation where ContactIdEnteredBy < 0 or EmployeeIdEnteredBy < 0 
	delete from TempReservation where ContactIdEnteredBy < 0 or EmployeeIdEnteredBy < 0 

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempReservation''
  ,@ToTable =''Reservation''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);
  
    -- insert '+@ToDB+'.dbo.Reservation
    -- (
    --     ReservationId,
    --     ReservationStatus,
    --     ContactId,
    --     TenantId,
    --     buildingId,
    --     ContactIdEnteredBy,
    --     EmployeeIdEnteredBy,
    --     EmployeeIdReviewedBy,
    --     IsCancellationChargeApplied,
    --     DurationMinutes,
    --     DateCreated,
    --     DateRequired,
    --     DateReviewed,
	-- 	DateUpdated,
    --     ReservationNotes,
    --     InternalNotes,
    --     ReasonForRejection,

	-- 	IsReschedulingChargeApplied,
	-- 	ApplyCancellationChargeLater,
	-- 	ApplyReschedulingChargeLater,
	-- 	ContactIdEditedBy,
	-- 	EmployeeIdEditedBy,
	-- 	BusinessLogicVersion,
	-- 	Reservation_cs_companyid,
	-- 	TnCAccepted,
	-- 	DocPendingEmailReminderVersion,
	-- 	[DisplayPreference],
	-- 	[HostCompanyName]
    -- )
    -- Select
    --     newReservationId       ,
    --     ReservationStatus,
    --     ContactId,
    --     TenantId,
    --     buildingId,
    --     ContactIdEnteredBy,
    --     EmployeeIdEnteredBy,
    --     EmployeeIdReviewedBy,
    --     IsCancellationChargeApplied,
    --     DurationMinutes,
    --     DateCreated,
    --     DateRequired,
    --     DateReviewed,
	-- 	DateUpdated,
    --     ReservationNotes,
    --     InternalNotes,
    --     ReasonForRejection  ,

	-- 	IsReschedulingChargeApplied,
	-- 	ApplyCancellationChargeLater,
	-- 	ApplyReschedulingChargeLater,
	-- 	ContactIdEditedBy,
	-- 	EmployeeIdEditedBy,
	-- 	BusinessLogicVersion
	-- 	,'+@ToCompany+' as  cs_companyid,
	-- 	TnCAccepted,
	-- 	DocPendingEmailReminderVersion,
	-- 	[DisplayPreference],
	-- 	[HostCompanyName]
    -- From
    --     TempReservation
    PRINT 'Insert ReservationHistory';
    SET @sql = '
Select next value for seq_ReservationHistory over (order by ReservationHistory.ReservationHistoryId) as newReservationHistoryid, ReservationHistory.*
into tempReservationHistory
from '+@Fromserver+'.'+@FromDB+'.dbo.ReservationHistory ReservationHistory inner join TempReservation tp  on tp.Reservationid = ReservationHistory.Reservationid
--order by ReservationHistory.ReservationHistoryid



if exists (select * from tempReservationHistory) Begin

update tempReservationHistory set employeeidEnteredBy = -3, ContactIDEnteredBy = -3, ReservationID = -3

update vd
set
	vd.ReservationID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempReservationHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationHistory Fvd on vd.ReservationHistoryid = Fvd.ReservationHistoryid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ReservationID = ulk.oldid
where
	vd.ReservationID = -3 and ulk.tablename = ''Reservation''

update vd
set
	vd.employeeidEnteredBy = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempReservationHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationHistory Fvd on vd.ReservationHistoryid = Fvd.ReservationHistoryid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeidEnteredBy = ulk.oldid
where
	vd.employeeidEnteredBy = -3 and ulk.tablename = ''Commonemployee''



update vd
set
	vd.ContactIDEnteredBy = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempReservationHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationHistory Fvd on vd.ReservationHistoryid = Fvd.ReservationHistoryid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ContactIDEnteredBy = ulk.oldid
where
	vd.ContactIDEnteredBy = -3 and ulk.tablename = ''Contact''


	Update tempReservationHistory set employeeidEnteredBy = (Select top 1 newemployeeid from tempce where newemployeeid <> 0 )
	 where employeeidEnteredBy =0 and ContactIdEnteredBy <=0 

	 Update tempReservationHistory set ContactIdEnteredBy = (Select top 1 newcontactid from tempcontact where newcontactid <> 0 )
	 where (employeeidEnteredBy =0 and ContactIdEnteredBy =0 ) or ContactIdEnteredBy < 0



	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ReservationHistory'',
        	''ReservationHistoryID'',
        	ReservationHistoryID,
        	NewReservationHistoryID
        From
           	dbo.tempReservationHistory

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempReservationHistory''
  ,@ToTable =''ReservationHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ReservationHistory
    --     (
    --         ReservationHistoryId,
    --         ReservationId,
    --         EmployeeIdEnteredBy,
    --         ContactIdEnteredBy,
    --         ReservationHistoryEvent,
    --         DateCreatedOffset,
    --         HistoryDateOffset,
    --         ReservationHistoryDetails,
	-- 		ReservationHistory_cs_companyid
    --     )
    -- select
    --         newReservationHistoryId ,
    --         ReservationId,
    --         EmployeeIdEnteredBy,
    --         ContactIdEnteredBy,
    --         ReservationHistoryEvent,
    --         DateCreatedOffset,
    --         HistoryDateOffset,
    --         ReservationHistoryDetails
	-- 		,'+@ToCompany+' as  cs_companyid

    -- From
    --     tempReservationHistory
    PRINT 'Insert Resource';
    SET @sql = '
Select next value for seq_Resource over (order by r.ResourceId) as newResourceId, r.*
into dbo.TempResource
from '+@Fromserver+'.'+@FromDB+'.dbo.Resource r  inner join temparea a  on r.areaid = a.areaid
--order by r.ResourceId

update TempResource
set
    TempResource.areaid = temparea.newareaid
from
    temparea with (nolock)
where
    TempResource.areaid = temparea.areaid


update tr
set
    tr.Resourcetypeid = b.[newid]
from
    TempResource tr with (nolock) inner join mapping b with (nolock)
on
    tr.Resourcetypeid = b.fromid
where
    b.tablename = ''ResourceType''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

select * from TempResource where Resourcetypeid not in (Select Resourcetypeid from Resourcetype)
 Update TempResource
 set Resourcetypeid = 0
  where Resourcetypeid not in (Select Resourcetypeid from Resourcetype)


if exists (select * from TempResource) Begin

update TempResource set AreaId = -3
update r
set
	r.AreaId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempResource r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Resource Fr on r.Resourceid = Fr.Resourceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.areaid = ulk.oldid
where
	r.AreaId = -3 and ulk.tablename = ''Area''



	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Resource'',
        	''ResourceId'',
        	ResourceId,
        	newResourceId
        From
           	dbo.TempResource

select * from TempResource
---- merge data
--    EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
--   ,@ToSchema =''dbo''
--   ,@FromTable =''tempResource''
--   ,@ToTable =''Resource''
--   ,@CompanyId = '+@ToCompany+'

  select * from resource where ResourceId in (select NewResourceId from tempResource)
  
    insert '+@ToDB+'.dbo.Resource
    (
        ResourceId           ,
        --DateCreated          ,
        ResourceName         ,
        ResourceTypeId       ,
        AreaId               ,
        --IsActive             ,
        IsApprovalRequired   ,
        IsBillable           ,
        ResDurationMax       ,
        ResDurationMaxUnit   ,
        ResStartTimeMin      ,
        ResStartTimeMinUnit  ,
        ResEndTimeMax        ,
        ResEndTimeMaxUnit  ,
		ResBuffer            ,
        ResBufferUnit        ,
        ResourceDescription  ,
        ResourceInstructions ,
        EmailNotificationList,
        IsReservedRegionWide,
		DateInactiveOffset,
		DateCreatedOffset,
		DateUpdatedOffset,
		Resource_cs_companyid,
		TnCAcceptanceRequired,
		DocRequiredReminderDuration,
		DocRequiredReminderDurationUnit,
		TenantRestriction,
		AllowConcurrentReservations
    )
    Select
        newResourceId           ,
        --DateCreated          ,
        ResourceName         ,
        ResourceTypeId       ,
        AreaId,
        --IsActive             ,
        IsApprovalRequired   ,
        IsBillable           ,
        ResDurationMax       ,
        ResDurationMaxUnit   ,
        ResStartTimeMin      ,
        ResStartTimeMinUnit  ,
        ResEndTimeMax        ,
        ResEndTimeMaxUnit    ,
        ResBuffer            ,
        ResBufferUnit        ,
        ResourceDescription  ,
        ResourceInstructions ,
        EmailNotificationList,
        IsReservedRegionWide,
		DateInactiveOffset,
		DateCreatedOffset,
		DateUpdatedOffset
		,'+@ToCompany+' as  cs_companyid,
		TnCAcceptanceRequired,
		DocRequiredReminderDuration,
		DocRequiredReminderDurationUnit,
		TenantRestriction,
		AllowConcurrentReservations
    From
        dbo.TempResource
End
';
    EXEC (@sql);


    PRINT 'Insert ResourceQuestion';
    SET @sql = '
Select  next value for seq_ResourceQuestion over (order by c.ResourceQuestionId) as NewResourceQuestionId, c.*
into dbo.TempResourceQuestion
from '+@Fromserver+'.'+@FromDB+'.dbo.ResourceQuestion c  inner join TempResource tt  on tt.resourceId = c.resourceId


update tempResourceQuestion set [resourceId] = -3
where [resourceId]  is not null or resourceId <> 0


update c
set
	c.resourceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempResourceQuestion c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceQuestion Fc on c.ResourceQuestionid = Fc.ResourceQuestionid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.resourceId = ulk.oldid
where
	c.resourceId = -3 and ulk.tablename = ''Resource''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ResourceQuestion'',
        	''ResourceQuestionId'',
       		ResourceQuestionId,
  			newResourceQuestionId
        From
      	dbo.TempResourceQuestion

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempResourceQuestion''
  ,@ToTable =''ResourceQuestion''
  ,@CompanyId = '+@ToCompany+'
  
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ResourceQuestion
    -- (

	-- 	[ResourceQuestionId]
    --        ,[ResourceId]
    --        ,[QuestionText]
    --        ,[QuestionType]
    --        ,[Options]
    --        ,[Inactive]
    --        ,[DisplayOrder]
    --        ,[DateInactive]
	-- 	   ,ResourceQuestion_cs_companyid
    -- )
    -- Select
	-- 	[NewResourceQuestionId]
    --         ,[ResourceId]
    --        ,[QuestionText]
    --        ,[QuestionType]
    --        ,[Options]
    --        ,[Inactive]
    --        ,[DisplayOrder]
    --        ,[DateInactive]
	-- 	   ,'+@ToCompany+' as  cs_companyid
    -- From
    --     tempResourceQuestion


    PRINT 'Insert ReservationAnswer';
    SET @sql = '
Select  next value for seq_ReservationAnswer over (order by c.ReservationAnswerId) as NewReservationAnswerId, c.*
into dbo.TempReservationAnswer
from '+@Fromserver+'.'+@FromDB+'.dbo.ReservationAnswer c  inner join TempResourceQuestion tt  on tt.ResourceQuestionId = c.ResourceQuestionId
inner join TempReservation tr on c.ReservationID = tr.ReservationID


update TempReservationAnswer set [ResourceQuestionId] = -3
where [ResourceQuestionId]  is not null or ResourceQuestionId <> 0

update TempReservationAnswer set [ReservationID] = -3
where [ReservationID]  is not null or ReservationID <> 0

update TempReservationAnswer set [ResourceID] = -3
where [ResourceID]  is not null or ResourceID <> 0

update c
set
	c.ResourceQuestionId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationAnswer c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationAnswer Fc on c.ReservationAnswerid = Fc.ReservationAnswerid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ResourceQuestionId = ulk.oldid
where
	c.ResourceQuestionId = -3 and ulk.tablename = ''ResourceQuestion''

	
update c
set
	c.ReservationID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationAnswer c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationAnswer Fc on c.ReservationAnswerid = Fc.ReservationAnswerid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ReservationID = ulk.oldid
where
	c.ReservationID = -3 and ulk.tablename = ''Reservation''

	
update c
set
	c.ResourceID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationAnswer c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationAnswer Fc on c.ReservationAnswerid = Fc.ReservationAnswerid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ResourceID = ulk.oldid
where
	c.ResourceID = -3 and ulk.tablename = ''Resource''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ReservationAnswer'',
        	''ReservationAnswerId'',
       		ReservationAnswerId,
  			newReservationAnswerId
        From
      	dbo.TempReservationAnswer

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempReservationAnswer''
  ,@ToTable =''ReservationAnswer''
  ,@CompanyId = '+@ToCompany+'

';
    EXEC (@sql);
  
    -- insert '+@ToDB+'.dbo.ReservationAnswer
    -- (
	-- 	[ReservationAnswerId]
    --        ,[ResourceQuestionId]
    --        ,[Answer]
    --        ,[ReservationId]
    --        ,[ResourceId]
	-- 	   ,ReservationAnswer_cs_companyid
    -- )
    -- Select
	-- 	[NewReservationAnswerId]
    --         ,[ResourceQuestionId]
    --        ,[Answer]
    --        ,[ReservationId]
    --        ,[ResourceId]
	-- 	   ,'+@ToCompany+' as  cs_companyid
    -- From
    --     TempReservationAnswer
    PRINT 'Insert ResourceAmenity';
    SET @sql = '
Select  next value for seq_ResourceAmenity over (order by c.ResourceAmenityId) as NewResourceAmenityId, c.*
into dbo.TempResourceAmenity
from '+@Fromserver+'.'+@FromDB+'.dbo.ResourceAmenity c  inner join TempResource tt  on tt.resourceId = c.resourceId


update tempResourceAmenity set [resourceId] = -3
where [resourceId]  is not null or resourceId <> 0


update c
set
	c.resourceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempResourceAmenity c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceAmenity Fc on c.ResourceAmenityid = Fc.ResourceAmenityid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.resourceId = ulk.oldid
where
	c.resourceId = -3 and ulk.tablename = ''Resource''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ResourceAmenity'',
        	''ResourceAmenityId'',
       		ResourceAmenityId,
  			newResourceAmenityId
        From
      	dbo.TempResourceAmenity

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempResourceAmenity''
  ,@ToTable =''ResourceAmenity''
  ,@CompanyId = '+@ToCompany+'

';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ResourceAmenity
    -- (
	-- 	[ResourceAmenityId]
    --        ,[ResourceId]
    --        ,[AmenityName]
    --        ,[AmenityDescription]
    --        ,[Included]
    --        ,[Billable]
    --        ,[Inactive]
    --        ,[DateInactive]
	-- 	   ,ResourceAmenity_cs_companyid
    -- )
    -- Select
	-- 	[NewResourceAmenityId]
    --         ,[ResourceId]
    --        ,[AmenityName]
    --        ,[AmenityDescription]
    --        ,[Included]
    --        ,[Billable]
    --        ,[Inactive]
    --        ,[DateInactive]
	-- 	   ,'+@ToCompany+' as  cs_companyid
    -- From
    --     tempResourceAmenity

    PRINT 'Insert ReservationAmenity';
    SET @sql = '
Select  next value for seq_ReservationAmenity over (order by c.ReservationAmenityId) as NewReservationAmenityId, c.*
into dbo.TempReservationAmenity
from '+@Fromserver+'.'+@FromDB+'.dbo.ReservationAmenity c  inner join TempResourceAmenity tt  on tt.ResourceAmenityId = c.ResourceAmenityId
inner join TempReservation tr on c.ReservationID = tr.ReservationID


update TempReservationAmenity set [ResourceAmenityId] = -3
where [ResourceAmenityId]  is not null or ResourceAmenityId <> 0

update TempReservationAmenity set [ReservationID] = -3
where [ReservationID]  is not null or ReservationID <> 0

update TempReservationAmenity set [ResourceID] = -3
where [ResourceID]  is not null or ResourceID <> 0

update c
set
	c.ResourceAmenityId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationAmenity c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationAmenity Fc on c.ReservationAmenityid = Fc.ReservationAmenityid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ResourceAmenityId = ulk.oldid
where
	c.ResourceAmenityId = -3 and ulk.tablename = ''ResourceAmenity''

	
update c
set
	c.ReservationID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationAmenity c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationAmenity Fc on c.ReservationAmenityid = Fc.ReservationAmenityid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ReservationID = ulk.oldid
where
	c.ReservationID = -3 and ulk.tablename = ''Reservation''

	
update c
set
	c.ResourceID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationAmenity c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationAmenity Fc on c.ReservationAmenityid = Fc.ReservationAmenityid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ResourceID = ulk.oldid
where
	c.ResourceID = -3 and ulk.tablename = ''Resource''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ReservationAmenity'',
        	''ReservationAmenityId'',
       		ReservationAmenityId,
  			newReservationAmenityId
        From
      	dbo.TempReservationAmenity

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempReservationAmenity''
  ,@ToTable =''ReservationAmenity''
  ,@CompanyId = '+@ToCompany+'

';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ReservationAmenity
    -- (
	-- 	[ReservationAmenityId]
    --        ,[ResourceAmenityId]
    --        ,[Selected]
    --        ,[ReservationId]
    --        ,[Included]
    --        ,[Billable]
    --        ,[ResourceId]
	-- 	   ,ReservationAmenity_cs_companyid
    -- )
    -- Select
	-- 	[NewReservationAmenityId]
    --         ,[ResourceAmenityId]
    --        ,[Selected]
    --        ,[ReservationId]
    --        ,[Included]
    --        ,[Billable]
    --        ,[ResourceId]
	-- 	   ,'+@ToCompany+' as  cs_companyid
    -- From
    --     TempReservationAmenity


    PRINT 'Insert ResourceAttachment';
    SET @sql = '
Select  next value for seq_ResourceAttachment over (order by c.ResourceAttachmentId) as NewResourceAttachmentId, c.*
into dbo.TempResourceAttachment
--from '+@Fromserver+'.'+@FromDB+'.dbo.ResourceAttachment c  inner join TempResource tt  on tt.resourceId = c.resourceId
from '+@Fromserver+'.'+@FromDB+'.dbo.view_ResourceAttachment c  inner join TempResource tt  on tt.resourceId = c.resourceId


update tempResourceAttachment set [resourceId] = -3
where [resourceId]  is not null or resourceId <> 0


update tempResourceAttachment set [CreatedEmployeeId] = -3
where [CreatedEmployeeId]  is not null or CreatedEmployeeId <> 0


update tempResourceAttachment set [LastModifiedEmployeeId] = -3
where [LastModifiedEmployeeId]  is not null or LastModifiedEmployeeId <> 0


update vd
set
	vd.CreatedEmployeeId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempResourceAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceAttachment Fvd on vd.ResourceAttachmentId = Fvd.ResourceAttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.CreatedEmployeeId = ulk.oldid
where
	vd.CreatedEmployeeId = -3 and ulk.tablename = ''Commonemployee''

	
update vd
set
	vd.LastModifiedEmployeeId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempResourceAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceAttachment Fvd on vd.ResourceAttachmentId = Fvd.ResourceAttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.LastModifiedEmployeeId = ulk.oldid
where
	vd.LastModifiedEmployeeId = -3 and ulk.tablename = ''Commonemployee''


update c
set
	c.resourceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempResourceAttachment c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceAttachment Fc on c.ResourceAttachmentid = Fc.ResourceAttachmentid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.resourceId = ulk.oldid
where
	c.resourceId = -3 and ulk.tablename = ''Resource''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ResourceAttachment'',
        	''ResourceAttachmentId'',
       		ResourceAttachmentId,
  			newResourceAttachmentId
        From
      	dbo.TempResourceAttachment

---- merge data
--    EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
--   ,@ToSchema =''dbo''
--   ,@FromTable =''tempResourceAttachment''
--   ,@ToTable =''ResourceAttachment''
--   ,@CompanyId = '+@ToCompany+'
select * from tempResourceAttachment where resourceid not in 
(select resourceid from  resource )
    insert '+@ToDB+'.dbo.ResourceAttachment
    (

		[ResourceAttachmentId]
           ,[FileName]
           ,[FileType]
           ,[FileFormat]
           ,[FileSize]
           ,[CreatedOn]
           ,[LastModifiedOn]
           ,[CreatedEmployeeId]
           ,[LastModifiedEmployeeId]
           ,[ResourceId]
           ,[AttachmentGroup]
           ,[Description]
           ,[DisplayOrder]
           ,[FileContent]
		   ,ResourceAttachment_cs_companyid
		   ,Inactive
		   ,DateInactive
		   --,isResized
    )
    Select
		[NewResourceAttachmentId]
            ,[FileName]
           ,[FileType]
           ,[FileFormat]
           ,[FileSize]
           ,[CreatedOn]
           ,[LastModifiedOn]
           ,[CreatedEmployeeId]
           ,[LastModifiedEmployeeId]
           ,[ResourceId]
           ,[AttachmentGroup]
           ,[Description]
           ,[DisplayOrder]
           ,[FileContent]
		   ,'+@ToCompany+' as  cs_companyid
		   ,Inactive
		   ,DateInactive
		   --,isResized
    From
        tempResourceAttachment

';
    EXEC (@sql);


    PRINT 'Insert ReservationDocument';
    SET @sql = '
Select  next value for seq_ReservationDocument over (order by c.ReservationDocumentId) as NewReservationDocumentId, c.*
into dbo.TempReservationDocument
--from '+@Fromserver+'.'+@FromDB+'.dbo.ReservationDocument c  inner join TempResourceAttachment tt  on tt.ResourceAttachmentId = c.ResourceAttachmentId
from '+@Fromserver+'.'+@FromDB+'.dbo.view_ReservationDocument c  inner join TempResourceAttachment tt  on tt.ResourceAttachmentId = c.ResourceAttachmentId
inner join TempReservation tr on c.ReservationID = tr.ReservationID


update TempReservationDocument set [ResourceAttachmentId] = -3
where [ResourceAttachmentId]  is not null or ResourceAttachmentId <> 0

update TempReservationDocument set [ReservationID] = -3
where [ReservationID]  is not null or ReservationID <> 0

update TempReservationDocument set [ResourceID] = -3
where [ResourceID]  is not null or ResourceID <> 0

update c
set
	c.ResourceAttachmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationDocument c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationDocument Fc on c.ReservationDocumentid = Fc.ReservationDocumentid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ResourceAttachmentId = ulk.oldid
where
	c.ResourceAttachmentId = -3 and ulk.tablename = ''ResourceAttachment''

	
update c
set
	c.ReservationID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationDocument c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationDocument Fc on c.ReservationDocumentid = Fc.ReservationDocumentid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ReservationID = ulk.oldid
where
	c.ReservationID = -3 and ulk.tablename = ''Reservation''

	
update c
set
	c.ResourceID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempReservationDocument c with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationDocument Fc on c.ReservationDocumentid = Fc.ReservationDocumentid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fc.ResourceID = ulk.oldid
where
	c.ResourceID = -3 and ulk.tablename = ''Resource''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ReservationDocument'',
        	''ReservationDocumentId'',
       		ReservationDocumentId,
  			newReservationDocumentId
        From
      	dbo.TempReservationDocument

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempReservationDocument''
  ,@ToTable =''ReservationDocument''
  ,@CompanyId = '+@ToCompany+'

';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ReservationDocument
    -- (
	-- 	[ReservationDocumentId]
    --        ,[ResourceAttachmentId]
    --        ,[FileName]
    --        ,[FileType]
    --        ,[FileFormat]
    --        ,[FileSize]
    --        ,[FileContent]
    --        ,[DateCreated]
    --        ,[DateUpdated]
    --        ,[EmployeeIdSubmitted]
    --        ,[ContactIdSubmitted]
    --        ,[ReservationId]
    --        ,[ResourceId]
	-- 	   ,ReservationDocument_cs_companyid
	-- 	   ,isResized
    -- )
    -- Select
	-- 	[NewReservationDocumentId]
    --       ,[ResourceAttachmentId]
    --        ,[FileName]
    --        ,[FileType]
    --        ,[FileFormat]
    --        ,[FileSize]
    --        ,[FileContent]
    --        ,[DateCreated]
    --        ,[DateUpdated]
    --        ,[EmployeeIdSubmitted]
    --        ,[ContactIdSubmitted]
    --        ,[ReservationId]
    --        ,[ResourceId]
	-- 	   ,'+@ToCompany+' as  cs_companyid
	-- 	   ,isResized
    -- From
    --     TempReservationDocument

    PRINT 'Insert ResourceProperty';
    SET @sql = '
Select
next value for seq_ResourceProperty over (order by ResourceProperty.ResourcePropertyId) as NewResourcePropertyId,ResourceProperty.*
into tempResourceProperty
from '+@Fromserver+'.'+@FromDB+'.dbo.ResourceProperty ResourceProperty inner join TempProperty tp  on tp.Propertyid = ResourceProperty.Propertyid
inner join TempResource tr on tr.ResourceID = ResourceProperty.Resourceid

Update TempResourceProperty
set
    resourceID = tempResource.newResourceID
from TempResourceProperty inner join tempresource on TempResourceProperty.ResourceID = TempResource.ResourceID

Update TempResourceProperty
set
    PropertyID = tempProperty.NewPropertyID
from
    TempResourceProperty inner join tempProperty on TempResourceProperty.PropertyID = TempProperty.PropertyID


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempResourceProperty''
  ,@ToTable =''ResourceProperty''
  ,@CompanyId = '+@ToCompany+'
  
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ResourceProperty
    --     (

    --         ResourceId,
    --         PropertyID,
    --         IsResourceLocation,
	-- 		ResourcePropertyId,
	-- 		ResourceProperty_cs_companyid

    --     )
    -- select
    --         ResourceId,
    --         PropertyID,
    --         IsResourceLocation,
	-- 		NewResourcePropertyId
	-- 		,'+@ToCompany+' as  cs_companyid
    -- From
    --     tempResourceProperty


    PRINT 'Insert ResourceAvailability';
    SET @sql = '
Select next value for seq_ResourceAvailability over (order by ResourceAvailability.ResourceAvailabilityId) as  newResourceAvailabilityid, ResourceAvailability.*
into tempResourceAvailability
from '+@Fromserver+'.'+@FromDB+'.dbo.ResourceAvailability ResourceAvailability inner join TempResource tp  on tp.Resourceid = ResourceAvailability.Resourceid
--order by ResourceAvailability.ResourceAvailabilityid



if exists (select * from tempResourceAvailability) Begin


update tempResourceAvailability set  ResourceID = -3


update vd
set
	vd.ResourceID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempResourceAvailability vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceAvailability Fvd on vd.ResourceAvailabilityid = Fvd.ResourceAvailabilityid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ResourceID = ulk.oldid
where
	vd.ResourceID = -3 and ulk.tablename = ''Resource''


	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ResourceAvailability'',
        	''ResourceAvailabilityID'',
        	ResourceAvailabilityID,
        	NewResourceAvailabilityID
        From
           	dbo.tempResourceAvailability

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempResourceAvailability''
  ,@ToTable =''ResourceAvailability''
  ,@CompanyId = '+@ToCompany+'
  
End
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ResourceAvailability
    --     (
    --         ResourceAvailabilityId,
    --         ResourceId,
    --         ResourceAvailabilityType,
    --         DayOfWeekStart,
    --         DayOfWeekEnd,
	-- 		FromTime,
	-- 		ToTime,
	-- 		FromDate,
	-- 		ToDate,
	-- 		ResourceAvailability_cs_companyid


    --     )
    -- select
    --         NewResourceAvailabilityId,
    --         ResourceId,
    --         ResourceAvailabilityType,
    --         DayOfWeekStart,
    --         DayOfWeekEnd,
	-- 		FromTime,
	-- 		ToTime,
	-- 		FromDate,
	-- 		ToDate 
	-- 		,'+@ToCompany+' as  cs_companyid


    -- From
    --     tempResourceAvailability

    PRINT 'Insert ReservationResource';
    SET @sql = '
Select next value for seq_ReservationResource over (order by ReservationResource.ReservationResourceId) as newReservationResourceid, ReservationResource.*
into tempReservationResource
from '+@Fromserver+'.'+@FromDB+'.dbo.ReservationResource ReservationResource inner join TempReservation tp  on tp.Reservationid = ReservationResource.Reservationid
--order by ReservationResource.ReservationResourceid



if exists (select * from tempReservationResource) Begin


update tempReservationResource set  ResourceID = -3, ReservationID = -3

update vd
set
	vd.ReservationID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempReservationResource vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationResource Fvd on vd.ReservationResourceid = Fvd.ReservationResourceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ReservationID = ulk.oldid
where
	vd.ReservationID = -3 and ulk.tablename = ''Reservation''

update vd
set
	vd.ResourceID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempReservationResource vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ReservationResource Fvd on vd.ReservationResourceid = Fvd.ReservationResourceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ResourceID = ulk.oldid
where
	vd.ResourceID = -3 and ulk.tablename = ''Resource''


	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ReservationResource'',
        	''ReservationResourceID'',
        	ReservationResourceID,
        	NewReservationResourceID
        From
           	dbo.tempReservationResource

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempReservationResource''
  ,@ToTable =''ReservationResource''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);

    -- insert '+@ToDB+'.dbo.ReservationResource
    --     (
    --        ReservationId,
    --        ResourceId,
    --        ReservationResourceId,
    --        IsPrimaryResource,
	-- 	   ReservationResource_cs_companyid
    --     )
    -- select
    --        ReservationId,
    --        ResourceId,
    --        NewReservationResourceId,
    --        IsPrimaryResource 
	-- 	   ,'+@ToCompany+' as  ReservationResource_cs_companyid
    -- From
    --     tempReservationResource

    PRINT 'Insert FileAttachment';
    SET @sql = '

Select next value for seq_FileAttachment as newAttachmentId, tF.*
into dbo.TempFileAttachment
--from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment as tF where attachmentId in
from '+@Fromserver+'.'+@FromDB+'.dbo.View_FileAttachment as tF where attachmentId in

(select  A.AttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment A  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.lease L on A.AttachmentId = L.AgreementAttachmentId inner join
temptenant tt  on tt.tenantid = l.tenantid
where l.PropertyID in (Select PropertyId from tempProperty) Or L.buildingid in (select buildingid from tempbuilding)

Union
Select B.AttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment B  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COI C1 on B.AttachmentID = C1.ContractAttachmentId inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COIProperty CP1 on C1.COIId = CP1.COIId inner join
dbo.tempProperty tp1 on tp1.PropertyId = CP1.PropertyID

Union
Select C.AttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment C  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COIAttachment C2 on C.AttachmentID = C2.AttachmentId inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COI C3 on C2.COIID = C3.COIId inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COIProperty CP2 on C3.COIId = CP2.COIId inner join
dbo.tempProperty tp2 on tp2.PropertyId = CP2.PropertyID

Union
Select D.AttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment D  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COI C3 on D.AttachmentID = C3.COIAttachmentID inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COIProperty CP3 on CP3.COIId = C3.COIId inner join
dbo.tempProperty tp3 on tp3.PropertyId = CP3.PropertyID


Union
Select D.AttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment D  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COI C3 on D.AttachmentID = C3.ContractAttachmentId inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COIProperty CP3 on CP3.COIId = C3.COIId inner join
dbo.tempProperty tp3 on tp3.PropertyId = CP3.PropertyID

Union
select E.AttachmentID from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment E  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.vendortype vdt  on E.AttachmentId = vdt.RequirementsAttachmentID inner join
'+@Fromserver+'.'+@FromDB+'.dbo.vendorTypeProperty vp on vdt.vendorTypeid = vp.vendortypeid
where vdt.companyid = '+@FromCompany+' and vp.propertyid in '+@FromProperty+'

Union

select F.AttachmentID from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment F  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.vendorTypeProperty vp on F.Attachmentid = vp.RequirementsAttachmentID inner join
'+@Fromserver+'.'+@FromDB+'.dbo.vendortype vdt  on vdt.vendorTypeid = vp.vendortypeid
where vdt.companyid = '+@FromCompany+' and vp.propertyid in '+@FromProperty+'

union
select F.AttachmentID from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment F  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.VendorCommunication  VendorCommunication on F.AttachmentId = VendorCommunication.RequirementsAttachmentID
inner join TempProperty tp  on tp.Propertyid = VendorCommunication.Propertyid
where VendorCommunication.propertyid in '+@FromProperty+'

Union
Select D.AttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment D  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COIHistory CIH on CIH.COIAttachmentID = D.AttachmentID inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COI C3 on CIH.COIID = C3.COIID inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COIProperty CP3 on CP3.COIId = C3.COIId inner join
dbo.tempProperty tp3 on tp3.PropertyId = CP3.PropertyID


Union
SELECT D.AttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment D  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment ma  on ma.AttachmentID = D.AttachmentID inner join
'+@Fromserver+'.'+@FromDB+'.dbo.message tm  on ma.Messageid = tm.Messageid
inner join tempProperty p on tm.PropertyID = p.PropertyID


Union
SELECT D.RequirementsAttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.vendorTypeProperty D  inner join
tempProperty p on d.PropertyID = p.PropertyID


Union
SELECT D.AttachmentId from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment D  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment ma  on ma.AttachmentID = D.AttachmentID inner join
'+@Fromserver+'.'+@FromDB+'.dbo.message tm  on ma.Messageid = tm.Messageid inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COI on tm.COIId = COI.COIId  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.COIProperty cp on coi.coiid = cp.coiid
inner join tempProperty p on cp.PropertyID = p.PropertyID

Union
SELECT D.[AttachmentId] from '+@Fromserver+'.'+@FromDB+'.dbo.CommunicationTemplate D  inner join
tempProperty p on d.PropertyID = p.PropertyID

Union
SELECT D.[AttachmentId] from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment D  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.workorder w on d.workorderid = w.workorderid  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.building b on w.buildingid = b.buildingid inner join 
tempProperty p on b.PropertyID = p.PropertyID

Union
SELECT D.[AttachmentId] from '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment D  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.request w on d.requestId = w.requestId  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.building b on w.buildingid = b.buildingid inner join 
tempProperty p on b.PropertyID = p.PropertyID
)

-----------------------
EXEC v3_Common.dbo.SetUserContext  ' + @fromcompany + '

update '+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment
set IntegrationIdentifier = Newid()
where AttachmentId in (select AttachmentId from tempFileAttachment with (nolock) where AttachmentId > 0)

exec v3_Common.dbo.SetUserContext  ' + @ToCompany + '
--------------------------
Update tempFileAttachment
set ContactId = -3 where ContactId is not null and ContactID <> 0


Update tempFileAttachment
set EmployeeId = -3 where EmployeeId is not null and EmployeeId <> 0


update vd
set
	vd.employeeid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempFileAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment Fvd on vd.AttachmentId = Fvd.AttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeid = ulk.oldid
where
	vd.employeeid = -3 and ulk.tablename = ''Commonemployee''




update vd
set
	vd.ContactID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempFileAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment Fvd on vd.AttachmentId = Fvd.AttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ContactID = ulk.oldid
where
	vd.ContactID = -3 and ulk.tablename = ''Contact''


Update tempFileAttachment set contactID = 0 where contactid not in (Select ContactID from Contact) and ContactID is not null
Update tempFileAttachment set Employeeid = 0 where Employeeid not in (Select ContactID from Contact) and employeeid is not null

if exists (select * from tempFileAttachment) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''FileAttachment'',
        	''AttachmentId'',
        	AttachmentId,
        	newAttachmentId
        From
           	dbo.TempFileAttachment

---- merge data
--    EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
--   ,@ToSchema =''dbo''
--   ,@FromTable =''tempFileAttachment''
--   ,@ToTable =''FileAttachment''
--   ,@CompanyId = '+@ToCompany+'

    Insert  '+@ToDB+'.dbo.FileAttachment
    (
		[AttachmentId]
		,[FileName]
		,[FileType]
		,[FileLength]
		,[FileData]
		,[DateCreated]
		,[WorkOrderId]
		,[RequestId]
		,[EmployeeId]
		,[ContactId]
		,[tmpAttachmentId]
		,FileAttachment_cs_companyid
		--,isResized
    )
    Select

		[NewAttachmentId]
        ,[FileName]
        ,[FileType]
        ,[FileLength]
        ,[FileData]
        ,[DateCreated]
        ,Null as [WorkOrderId]
        ,Null as [RequestId]
        ,[EmployeeId]
        ,[ContactId]
        ,[tmpAttachmentId]
        ,'+@ToCompany+' as  cs_companyid
		--,isResized
		From
    TempFileAttachment

End

';
    --print (@sql)
    EXEC (@sql);

    ---------------------------------------vendor
    PRINT 'Insert vendorTypeProperty';
    SET @sql = '
Select next value for seq_vendorTypeProperty over (order by r.VendorTypePropertyId) as newvendorTypePropertyId, r.*
into dbo.tempvendorTypeProperty
from
    '+@Fromserver+'.'+@FromDB+'.dbo.vendorTypeProperty r  inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Property p  on p.Propertyid = r.Propertyid
where p.propertyid in '+@FromProperty+' and p.companyid = '+@FromCompany+'


update tempvendorTypeProperty
set
	Propertyid = NewPropertyId
From
	tempvendorTypeProperty inner join
	tempProperty on tempvendorTypeProperty.PropertyId = tempProperty.PropertyId


update tempvendorTypeProperty
set
	VendorTypeId = [NewId]
from
	tempvendorTypeProperty inner join mapping with (nolock)
	on tempvendorTypeProperty.VendorTypeId = mapping.FromId
where
	mapping.tablename = ''VendorType''
and
	mapping.FromCompany = '+@FromCompany+' and mapping.ToCompany = '+@ToCompany+'



update tempvendorTypeProperty
set requirementsAttachmentid = -3
where requirementsAttachmentid is not null

Update vd
set vd.requirementsAttachmentid = ulk.[NewId]
from
	'+@ToDB+'.dbo.tempvendorTypeProperty vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.vendorTypeProperty Fvd on vd.vendorTypePropertyid = Fvd.vendorTypePropertyid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.requirementsAttachmentid = ulk.oldid
where
	vd.requirementsAttachmentid = -3 and ulk.tablename = ''FileAttachment''

--update tempvendorTypeProperty
--set requirementsAttachmentid = null
--where requirementsAttachmentid -3


      Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''vendorTypeProperty'',
        	''vendorTypePropertyId'',
        	vendorTypePropertyId,
        	newvendorTypePropertyId
        From
           	dbo.tempvendorTypeProperty

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempVendorTypeProperty''
  ,@ToTable =''VendorTypeProperty''
  ,@CompanyId = '+@ToCompany+'

';
    EXEC (@sql);
-- Insert '+@ToDB+'.dbo.vendorTypeProperty
--     (
--     VendorTypePropertyId,
--     VendorTypeId,
--     PropertyId,
--     RequirementsAttachmentId
-- 	,vendorTypeProperty_cs_companyid
--     )
-- Select
--     NewVendorTypePropertyId,
--     VendorTypeId,
--     PropertyId,
--     RequirementsAttachmentId
-- 	,'+@ToCompany+' as  vendorTypeProperty_cs_companyid
-- from
--     tempvendorTypeProperty


    PRINT 'Insert Vendor';
    SET @sql = '
Select next value for seq_Vendor over (order by vd.VendorId) as newVendorid, vd.*
into tempvd
from '+@Fromserver+'.'+@FromDB+'.dbo.vendor vd  inner join tempce e  on e.employeeid = vd.employeeid
--order by vd.vendorid

update tempvd
set tempvd.employeeid = tempce.newemployeeid
from
    tempce with (nolock)
where
    tempvd.employeeid = tempce.employeeid


update tempvd
set VendorTypeId = [NewId]
from tempVd
	inner join mapping with (nolock) on tempVd.VendorTypeId = mapping.fromId
where
	mapping.tablename = ''VendorType''
and
	mapping.FromCompany = '+@FromCompany+' and mapping.ToCompany = '+@ToCompany+'


if exists (select * from tempvd) Begin

update Tempvd set employeeid = -3

update TempVd set vendortypeid = -3
where vendorTypeid <> 0


update vd
set
	vd.vendortypeid = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempvd vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.vendor Fvd on vd.Vendorid = Fvd.Vendorid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on  Fvd.VendorTypeId = ulk.oldId
where
	vd.vendortypeid = -3 and ulk.tablename = ''VendorType''

update vd
set
	vd.employeeid = ulk.[NewID]
From
	'+@ToDB+'.dbo.Tempvd vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.vendor Fvd on vd.Vendorid = Fvd.Vendorid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeid = ulk.oldid
where
	vd.employeeid = -3 and ulk.tablename = ''Commonemployee''


If not exists (select * from mapping where tablename =''VendorType'' and toCompany = '+@ToCompany+')
update '+@ToDB+'.dbo.Tempvd set vendorTypeID = 0


 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Vendor'',
        	''VendorID'',
        	VendorID,
        	NewVendorID
        From
           	dbo.Tempvd

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempvd''
  ,@ToTable =''Vendor''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);

    -- insert '+@ToDB+'.dbo.Vendor
    --     (
    --         VendorId           ,
    --         VendorName         ,
    --         EmployeeId         ,
    --         VendorTypeId       ,
    --         IsActiveVendor     ,
    --         IsTrVendor         ,
    --         IsPmVendor         ,
    --         ContractExpires    ,
    --         COIExpires         ,
    --         Address1           ,
	-- 		Address2           ,
    --         City               ,
    --         Province           ,
    --         Country            ,
    --         PostalCode         ,
    --         MainPhone          ,
    --         MainFax            ,
    --         TRName             ,
    --         TRPhone            ,
    --         PMName             ,
    --         PMPhone            ,
    --         AfterName          ,
    --         AfterPhone         ,
    --         AfterDeviceAddress ,
    --         COIContactName     ,
    --         COIContactEmail    ,
    --         COIContactPhone    ,
	-- 		[ExternalVendorCode],
	-- 		vendor_cs_companyid,
    --         ExternalVendorNotes 
    --     )
    -- select
    --         newVendorId ,
    --         VendorName         ,
    --         EmployeeId         ,
    --         VendorTypeId       ,
    --         IsActiveVendor     ,
	-- 		IsTrVendor      ,
    --         IsPmVendor         ,
    --         ContractExpires    ,
    --         COIExpires         ,
    --         Address1           ,
    --         Address2           ,
	-- 		City               ,
    --         Province           ,
    --         Country            ,
    --         PostalCode         ,
    --         MainPhone          ,
    --         MainFax            ,
    --         TRName             ,
    --         TRPhone            ,
    --         PMName             ,
    --         PMPhone            ,
    --         AfterName          ,
    --         AfterPhone         ,
    --         AfterDeviceAddress ,
    --         COIContactName     ,
    --         COIContactEmail    ,
    --         COIContactPhone    ,
	-- 		[ExternalVendorCode]
	-- 		,'+@ToCompany+' as  cs_companyid,
    --         ExternalVendorNotes
    -- From
    --     tempvd
    PRINT 'Insert VendorCommunication';
    SET @sql = '
Select next value for seq_VendorCommunication over (order by VendorCommunication.VendorCommunicationId) as newVendorCommunicationid, VendorCommunication.*
into tempVendorCommunication
from '+@Fromserver+'.'+@FromDB+'.dbo.VendorCommunication  VendorCommunication inner join TempProperty tp  on tp.Propertyid = VendorCommunication.Propertyid
--order by VendorCommunication.VendorCommunicationid



if exists (select * from tempVendorCommunication) Begin


update tempVendorCommunication set employeeid = -3, VendorID = -3, PropertyID = -3
update tempVendorCommunication set RequirementsAttachmentId=-3 where RequirementsAttachmentID is not null

update vd
set
	vd.PropertyID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempVendorCommunication vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.VendorCommunication Fvd on vd.VendorCommunicationid = Fvd.VendorCommunicationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.PropertyID = ulk.oldid
where
	vd.PropertyID = -3 and ulk.tablename = ''Property''

update vd
set
	vd.employeeid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempVendorCommunication vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.VendorCommunication Fvd on vd.VendorCommunicationid = Fvd.VendorCommunicationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeid = ulk.oldid
where
	vd.employeeid = -3 and ulk.tablename = ''Commonemployee''



update vd
set
	vd.VendorID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempVendorCommunication vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.VendorCommunication Fvd on vd.VendorCommunicationid = Fvd.VendorCommunicationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.VendorID = ulk.oldid
where
	vd.VendorID = -3 and ulk.tablename = ''Vendor''

update vd
set
	vd.RequirementsAttachmentId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempVendorCommunication vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.VendorCommunication Fvd on vd.VendorCommunicationid = Fvd.VendorCommunicationid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.RequirementsAttachmentId = ulk.oldid
where
	vd.RequirementsAttachmentId = -3 and ulk.tablename = ''FileAttachment''


	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''VendorCommunication'',
        	''VendorCommunicationID'',
        	VendorCommunicationID,
        	NewVendorCommunicationID
        From
           	dbo.tempVendorCommunication

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempVendorCommunication''
  ,@ToTable =''VendorCommunication''
  ,@CompanyId = '+@ToCompany+'

End
';
    --print (@sql)
    EXEC (@sql);

    -- insert '+@ToDB+'.dbo.VendorCommunication
    --     (
    --         VendorCommunicationId,
    --         VendorId,
    --         EmployeeId,
    --         PropertyId,
	-- 		RequirementsAttachmentId,
    --         CommunicationType,
    --         DateTimeCreated,
    --         Subject,
    --         Notes,
	-- 		vendorCommunication_cs_companyid
    --     )
    -- select
    --         newVendorCommunicationId ,
    --         VendorId,
    --         EmployeeId,
    --         PropertyId,
    --         RequirementsAttachmentId,
    --         CommunicationType,
    --         DateTimeCreated,
    --         Subject,
    --         Notes
	-- 		,'+@ToCompany+' as  cs_companyid
    -- From
    --     tempVendorCommunication

    ----------------
    PRINT 'Insert Lease';
    SET @sql = '

Select next value for seq_Lease over (order by l.LeaseId) as newLeaseId, l.*
into dbo.TempLease
from '+@Fromserver+'.'+@FromDB+'.dbo.lease l  inner join temptenant tt  on tt.tenantid = l.tenantid
where l.PropertyId in (Select PropertyID from tempProperty)
--buildingid in (select buildingid from tempbuilding) or l.buildingid = 0
--order by l.leaseid

update templease
set
    templease.tenantid = temptenant.newtenantid
from
    temptenant with (nolock)
where
    templease.tenantid = temptenant.tenantid

update templease
set
    templease.Buildingid = tempbuilding.newBuildingid
from
    tempbuilding with (nolock)
where
    templease.Buildingid = tempbuilding.Buildingid

Update templease
    set
    AgreementAttachmentId =  TempFileAttachment.newAttachmentID
 From
    tempLease inner join TempFileAttachment with (nolock) on tempLease.AgreementAttachmentId = TempFileAttachment.AttachmentId
Where
    tempLease.AgreementAttachmentId is not null

if exists (select * from templease) Begin

update TempLease set TenantId = -3
where tenantid <> 0

update TempLease set BuildingId = -3
where BuildingId <> 0

update TempLease set PropertyId = -3
where PropertyId <> 0

update l
set
	l.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempLease l with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Lease Fl on l.Leaseid = Fl.Leaseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fl.Tenantid = ulk.oldid
where
	l.TenantId = -3 and ulk.tablename = ''Tenant''

update l
set
	l.BuildingId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempLease l with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Lease Fl on l.Leaseid = Fl.Leaseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fl.BuildingId = ulk.oldid
where
	l.BuildingId = -3 and ulk.tablename = ''Building''


update l
set
	l.PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempLease l with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Lease Fl on l.Leaseid = Fl.Leaseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fl.PropertyId = ulk.oldid
where
	l.PropertyId = -3 and ulk.tablename = ''Property''

	select * from TempLease where buildingid not in (Select buildingid from building)

	Update TempLease
	set buildingid = (select top 1 newbuildingid from tempbuilding where newbuildingid <> 0)
	where buildingid not in (Select buildingid from building)

	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Lease'',
        	''LeaseId'',
        	LeaseId,
        	newLeaseId
        From
           	dbo.TempLease


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempLease''
  ,@ToTable =''Lease''
  ,@CompanyId = '+@ToCompany+'

     --     TempLease
End
';
    EXEC (@sql);
   -- insert '+@ToDB+'.dbo.Lease
    -- (
    --     LeaseId                ,
	-- 	PropertyId			   ,
	-- 	BuildingId             ,
    --     TenantId               ,
    --     AgreementAttachmentID  ,
    --     IsActiveLease          ,
	-- 	DateInactive           ,
    --     ExternalLeaseCode      ,
    --     ExternalAddressCode    ,
    --     ExternalAltAddressCode ,
    --     ExternalUnitCode       ,
    --     BusinessUnit           ,
    --     LeaseType              ,
    --     LeaseTenantName        ,
	-- 	DateStart			   ,
	-- 	DateEnd				   ,
    --     tmpLeaseId
	-- 	,lease_cs_companyid
    -- )
    -- Select
    --     newLeaseId             ,
    --     PropertyId			   ,
	-- 	BuildingId             ,
    --     TenantId               ,
    --     AgreementAttachmentID  ,
    --     IsActiveLease          ,
	-- 	DateInactive           ,
    --     ExternalLeaseCode      ,
    --     ExternalAddressCode    ,
    --     ExternalAltAddressCode ,
    --     ExternalUnitCode       ,
    --     BusinessUnit           ,
    --     LeaseType              ,
    --     LeaseTenantName        ,
	-- 	DateStart			   ,
	-- 	DateEnd				   ,
    --     -1 as tmpLeaseId
	-- 	,'+@ToCompany+' as  cs_companyid
    -- From

    PRINT 'Insert TenantAreaLease';
    SET @sql = '
Select next value for seq_TenantAreaLease over (order by tal.TenantAreaLeaseId) as newTenantAreaLeaseId, tal.*
into dbo.TempTAL
from '+@Fromserver+'.'+@FromDB+'.dbo.TenantAreaLease tal  inner join temptenant tt  on tt.tenantid = tal.tenantid
--order by tal.TenantAreaLeaseId

update TempTAL
set
    TempTAL.tenantid = temptenant.newtenantid
from
    temptenant with (nolock)
where
    TempTAL.tenantid = temptenant.tenantid

update TempTAL
set
    TempTAL.AreaId = temparea.newAreaId
from
    temparea with (nolock)
where
    TempTAL.AreaId = temparea.AreaId

update TempTAL
set
    TempTAL.LeaseId = templease.newLeaseId
from
    templease with (nolock)
where
    TempTAL.LeaseId = templease.LeaseId

if exists (select * from temptal) Begin

update Temptal set TenantId = -3, AreaId = -3, LeaseId = -3
update tal
set tal.tenantid = ulk.[NewId]
From
	'+@ToDB+'.dbo.Temptal tal with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.TenantAreaLease Ftal on tal.TenantAreaLeaseid = Ftal.TenantAreaLeaseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftal.tenantid = ulk.oldid
where
	tal.tenantid = -3 and ulk.tablename = ''Tenant''

update tal
set tal.areaid = ulk.[NewId]
From
	'+@ToDB+'.dbo.Temptal tal with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.TenantAreaLease Ftal on tal.TenantAreaLeaseid = Ftal.TenantAreaLeaseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftal.areaid = ulk.oldid
where
	tal.areaid = -3 and ulk.tablename = ''area''

update tal
set tal.LeaseId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Temptal tal with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.TenantAreaLease Ftal on tal.TenantAreaLeaseid = Ftal.TenantAreaLeaseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftal.LeaseId = ulk.oldid
where
	tal.LeaseId = -3 and ulk.tablename = ''Lease''


	
Select

    tenantAreaLeaseId,
		TenantId                ,
        AreaId  ,
        LeaseId          ,
        IsActiveTenantAreaLease ,
  IsSubLease              ,
        IsBaseAreaLease         ,
        ExternalAreaCode        ,
        ExternalFloorCode
    From
        temptal
where areaid not in (select areaid from area)

    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''TenantAreaLease'',
        	''TenantAreaLeaseId'',
        	TenantAreaLeaseId,
        	newTenantAreaLeaseId
        From
           	dbo.Temptal

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''temptal''
  ,@ToTable =''TenantAreaLease''
  ,@CompanyId = '+@ToCompany+'
  

End
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.TenantAreaLease
    -- (
    --     TenantAreaLeaseId       ,
	-- 	TenantId                ,
    --     AreaId  ,
    --     LeaseId          ,
    --     IsActiveTenantAreaLease ,
	-- 	IsSubLease              ,
    --     IsBaseAreaLease         ,
    --     ExternalAreaCode        ,
    --     ExternalFloorCode  ,
    --     SquareFootage,
    --     Occupancy,
    --     tmpTenantAreaLeaseID     ,
	-- 	ShowInDirectory
	-- 	,tenantAreaLease_cs_companyid
    -- )

    -- Select
    --     newTenantAreaLeaseId       ,
	-- 	TenantId                ,
    --     AreaId  ,
    --     LeaseId          ,
    --     IsActiveTenantAreaLease ,
	-- 	IsSubLease              ,
    --     IsBaseAreaLease         ,
    --     ExternalAreaCode        ,
    --     ExternalFloorCode   ,
    --     SquareFootage,
    --     Occupancy,
	-- 	tmpTenantAreaLeaseID,
	-- 	ShowInDirectory
	-- 	,'+@ToCompany+' as  cs_companyid
    -- From
    --     temptal
    PRINT 'Insert TenantContact';
    SET @sql = '
Select tc.* into tempTC
from
    '+@Fromserver+'.'+@FromDB+'.dbo.TenantContact tc  inner join temptenant tt  on tc.tenantid = tt.tenantid

update temptc
set
    temptc.tenantid = m.[newID]
from
    temptc inner join dbo.'+@lookup+' as m on temptc.TenantID = m.oldid
where
    m.tablename = ''Tenant''

--delete from temptc where contactid not in (select contactid from tempcontact )

update temptc
set
    temptc.contactid = tempcontact.newcontactid
from
    tempcontact 
where
    temptc.contactid = tempcontact.contactid

select * from temptc where contactid not in (select contactid from contact )

delete from temptc where contactid not in (select contactid from contact )

if exists (select * from temptc) Begin
    Insert '+@ToDB+'.dbo.TenantContact
    (
        TenantId  ,
        ContactId ,
	tenantContact_CS_Companyid
    )
    Select
        TenantId  ,
        ContactId ,
	'+@ToCompany+' as  cs_companyid
    From
        Temptc
End
';
    EXEC (@sql);

    PRINT 'Insert ContactAddressBook';
    SET @sql = '
Select next value for seq_ContactAddressBook over (order by cab.ContactAddressBookId) as newContactAddressBookId, cab.*
into dbo.Tempcab
from '+@Fromserver+'.'+@FromDB+'.dbo.ContactAddressBook cab  inner join tempcontact tc  on cab.contactid = tc.contactid
--order by cab.ContactAddressBookId

update tempcab
set tempcab.contactid = tempcontact.newcontactid
from
    tempcontact with (nolock)
where
    tempcab.contactid = tempcontact.contactid
if exists (select * from tempcab) Begin

update Tempcab set ContactId = -3
update cab
set cab.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempcab cab with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ContactAddressBook Fcab on cab.ContactAddressBookid = Fcab.ContactAddressBookid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fcab.ContactId = ulk.oldid
where
	cab.ContactId = -3 and ulk.tablename = ''Contact''


Update tempcab
set
	Company = '+@ToCompany+'


	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ContactAddressBook'',
        	''ContactAddressBookId'',
        	ContactAddressBookId,
        	newContactAddressBookId
        From
           	dbo.Tempcab

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempcab''
  ,@ToTable =''ContactAddressBook''
  ,@CompanyId = '+@ToCompany+'
  
End
';
    EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.ContactAddressBook
    -- (
    --     ContactAddressBookId ,
    --     ContactId            ,
    --     Company      ,
	-- 	[ContactFirstName] ,
	-- 	[ContactLastName] ,
	-- 	--ContactName,
	-- 	EmailAddress,
	-- 	ContactAddressBook_cs_companyid
    -- )
    -- Select
    --     newContactAddressBookId ,
    --     ContactId            ,
    --     Company      ,
	-- 	[ContactFirstName] ,
	-- 	[ContactLastName] ,
	-- 	--ContactName  ,
	-- 	EmailAddress
	-- 	,'+@ToCompany+' as  cs_companyid
    -- From
    --     Tempcab

    PRINT 'Insert Bulletin';
    SET @sql = '
Select next value for seq_Bulletin over (order by b.BulletinId) as newBulletinid, b.*
into dbo.TempBulletin
from '+@Fromserver+'.'+@FromDB+'.dbo.Bulletin b
where b.propertyid in '+@FromProperty+'

Update tempBulletin
set propertyid = -3
where propertyid is not null and propertyid <> 0


Update tempBulletin
set buildingid = -3
where buildingid is not null and buildingid <> 0


update a
set
	a.Propertyid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempBulletin a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Bulletin Fa on a.BulletinID = Fa.BulletinID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.Propertyid = ulk.oldid
where
	a.Propertyid = -3 and ulk.tablename = ''Property''

update a
set
	a.buildingId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempBulletin a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Bulletin Fa on a.BulletinID = Fa.BulletinID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.buildingid = ulk.oldid
where
	a.buildingid = -3 and ulk.tablename = ''building''

if exists (select * from tempBulletin) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Bulletin'',
        	''BulletinID'',
        	BulletinID,
        	NewBulletinID
        From
           	dbo.TempBulletin

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempBulletin''
  ,@ToTable =''Bulletin''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);
--    insert '+@ToDB+'.dbo.Bulletin
--            ([BulletinId]
--            ,[Type]
--            ,[Description]
--            ,[Status]
--            ,[StartDate]
--            ,[ExpectedEndDate]
--            ,[EndDate]
--            ,[PropertyId]
--            ,[BuildingId]
-- 		   ,bulletin_cs_companyid
-- 		   )



--     select
--             newBulletinId
--            ,[Type]
--            ,[Description]
--            ,[Status]
--            ,[StartDate]
--            ,[ExpectedEndDate]
--            ,[EndDate]
--            ,[PropertyId]
--            ,[BuildingId]
-- 		   ,'+@ToCompany+' as  cs_companyid

--     From
--         tempBulletin

    PRINT 'Insert BulletinHistory';
    SET @sql = '
Select next value for seq_BulletinHistory over (order by b.BulletinHistoryId) as newBulletinHistoryid, b.*
into dbo.TempBulletinHistory
from '+@Fromserver+'.'+@FromDB+'.dbo.BulletinHistory b
inner join tempBulletin a on b.BulletinID = a.BulletinID


Update tempBulletinHistory
set BulletinID = -3
where BulletinID is not null and BulletinID <> 0


Update tempBulletinHistory
set EmployeeId  = -3
where EmployeeId is not null and EmployeeId <> 0


Update tempBulletinHistory
set buildingid = -3
where buildingid is not null and buildingid <> 0


update a
set
	a.BulletinID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempBulletinHistory a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.BulletinHistory Fa on a.BulletinHistoryID = Fa.BulletinHistoryID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.BulletinID = ulk.oldid
where
	a.BulletinID = -3 and ulk.tablename = ''Bulletin''

update a
set
	a.buildingId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempBulletinHistory a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.BulletinHistory Fa on a.BulletinHistoryID = Fa.BulletinHistoryID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.buildingid = ulk.oldid
where
	a.buildingid = -3 and ulk.tablename = ''building''



update a
set
	a.Employeeid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempBulletinHistory a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.BulletinHistory Fa on a.BulletinHistoryID = Fa.BulletinHistoryID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.Employeeid = ulk.oldid
where
	a.Employeeid = -3 and ulk.tablename = ''CommonEmployee''


update a
set
	a.Employeeid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempBulletinHistory a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.BulletinHistory Fa on a.BulletinHistoryID = Fa.BulletinHistoryID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.Employeeid = ulk.oldid
where
	a.Employeeid = -3 and ulk.tablename = ''Employee''




if exists (select * from tempBulletinHistory) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''BulletinHistory'',
        	''BulletinHistoryID'',
        	BulletinHistoryID,
        	NewBulletinHistoryID
        From
           	dbo.TempBulletinHistory


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempBulletinHistory''
  ,@ToTable =''BulletinHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);

--    insert '+@ToDB+'.dbo.BulletinHistory
--           ([BulletinHistoryId]
--            ,[BulletinId]
--            ,[EmployeeId]
--            ,[Date]
--            ,[BulletinEvent]
--            ,[Type]
--            ,[Description]
--            ,[ExpectedEndDate]
--            ,[BuildingId]
--            ,[StartDate]
-- 		   ,BulletinHistory_cs_companyid
-- 		   )



--     select
--             newBulletinHistoryId
--            ,[BulletinId]
--            ,[EmployeeId]
--            ,[Date]
--            ,[BulletinEvent]
--            ,[Type]
--            ,[Description]
--            ,[ExpectedEndDate]
--            ,[BuildingId]
--            ,[StartDate]
-- 		   ,'+@ToCompany+' as  cs_companyid
--     From
--         tempBulletinHistory    

	print 'Insert EmployeeBulletin';
    SET @sql = '
Select next value for seq_EmployeeBulletin over (order by b.EmployeeBulletinId) as newEmployeeBulletinid, b.*
into dbo.TempEmployeeBulletin
from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeBulletin b
inner join tempBulletin a on b.BulletinID = a.BulletinID
inner join tempe c on c.employeeid = b.employeeid

Update tempEmployeeBulletin
set BulletinID = -3
where BulletinID is not null and BulletinID <> 0


Update tempEmployeeBulletin
set EmployeeId  = -3
where EmployeeId is not null and EmployeeId <> 0


update a
set
	a.BulletinID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempEmployeeBulletin a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeBulletin Fa on a.EmployeeBulletinID = Fa.EmployeeBulletinID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.BulletinID = ulk.oldid
where
	a.BulletinID = -3 and ulk.tablename = ''Bulletin''

update a
set
	a.Employeeid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempEmployeeBulletin a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeBulletin Fa on a.EmployeeBulletinID = Fa.EmployeeBulletinID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.Employeeid = ulk.oldid
where
	a.Employeeid = -3 and ulk.tablename = ''CommonEmployee''

update a
set
	a.Employeeid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempEmployeeBulletin a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeBulletin Fa on a.EmployeeBulletinID = Fa.EmployeeBulletinID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.Employeeid = ulk.oldid
where
	a.Employeeid = -3 and ulk.tablename = ''Employee''
--------- 
if exists(select * from dbo.tempEmployeeBulletin where Employeeid not in (select Employeeid from Employee))
	update dbo.tempEmployeeBulletin set Employeeid=0 where Employeeid not in (select Employeeid from Employee)
---------------

if exists (select * from tempEmployeeBulletin) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EmployeeBulletin'',
        	''EmployeeBulletinID'',
        	EmployeeBulletinID,
        	NewEmployeeBulletinID
        From
           	dbo.TempEmployeeBulletin

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEmployeeBulletin''
  ,@ToTable =''EmployeeBulletin''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);
  
--    insert '+@ToDB+'.dbo.EmployeeBulletin
--           ([EmployeeBulletinId]
--            ,[EmployeeId]
--            ,[BulletinId]
--            ,[IsRead]
-- 		   ,EmployeeBulletin_cs_companyid
-- 		   )

--     select
--             newEmployeeBulletinId
--            ,[EmployeeId]
--            ,[BulletinId]
--            ,[IsRead]
-- 		   ,'+@ToCompany+' as  cs_companyid

--     From
--         tempEmployeeBulletin

    PRINT 'Insert CommunicationTemplate';
    SET @sql = '
if exists (select * from mapping where tablename = ''CommunicationType'' 
and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+')
Begin
	Select next value for seq_CommunicationTemplate over (order by t.TemplateId) as newCommunicationTemplateId, t.*
	into dbo.TempCommunicationTemplate
	from '+@Fromserver+'.'+@FromDB+'.dbo.CommunicationTemplate t  inner join tempproperty p  on p.propertyid = t.Propertyid
	--order by t.CommunicationTemplateid

	Update tempCommunicationTemplate
		set [Companyid] = ' + @ToCompany + '

	
	update tempCommunicationTemplate
	set [CommunicationTypeId] = mapping.[NewId]
	from
		mapping with (nolock)
	where
		tempCommunicationTemplate.CommunicationTypeId = mapping.fromId
		and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'
	and
		mapping.tablename = ''CommunicationType''

	if exists (select * from tempCommunicationTemplate) Begin
		Insert  dbo.'+@lookup+'
			(
        		TableName,
        		ColumnName,
        		OldId,
        		[NewId]
			)
			Select
        		''CommunicationTemplate'',
        		''CommunicationTemplateID'',
        		TemplateID,
        		NewCommunicationTemplateID
			From
           		dbo.TempCommunicationTemplate

	update TempCommunicationTemplate set PropertyID = -3


	update TempCommunicationTemplate set [AttachmentId] = -3 where [AttachmentId] is not null and [AttachmentId] <> 0 

	update t
	set
		t.PropertyId = ulk.[NewId]
	From
		'+@ToDB+'.dbo.TempCommunicationTemplate t with (nolock) inner join
		'+@Fromserver+'.'+@FromDB+'.dbo.CommunicationTemplate Ft on t.Templateid = Ft.Templateid inner join
		'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ft.PropertyId = ulk.oldid
	where
		t.PropertyId = -3 and ulk.tablename = ''Property''

	
	update t
	set
		t.[AttachmentId] = ulk.[NewId]
	From
		'+@ToDB+'.dbo.TempCommunicationTemplate t with (nolock) inner join
		'+@Fromserver+'.'+@FromDB+'.dbo.CommunicationTemplate Ft on t.Templateid = Ft.Templateid inner join
		'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ft.AttachmentId = ulk.oldid
	where
		t.[AttachmentId] = -3 and ulk.tablename = ''FileAttachment''

	---- merge data
	   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
	  ,@ToSchema =''dbo''
	  ,@FromTable =''tempCommunicationTemplate''
	  ,@ToTable =''CommunicationTemplate''
	  ,@CompanyId = '+@ToCompany+'

	End
End
';

    --PRINT(@sql)
    EXEC (@sql);
		--INSERT INTO '+@ToDB+'.[dbo].[CommunicationTemplate]
		--	   ([TemplateId]
		--	   ,[CommunicationTypeId]
		--	   ,[PropertyId]
		--	   ,[CompanyId]
		--	   ,[TemplateName]
		--	   ,[Subject]
		--	   ,[Message]
		--	   ,[IsSms]
		--	   ,[IsEmail]
		--	   ,[IsVoice]
		--	   ,[SenderName]
		--	   ,[SenderEmail]
		--	   ,[SenderPhone]
		--	   ,[AttachmentId]
		--	   ,[CommunicationTemplate_CS_CompanyId]
		--		  )

		--Select
		--		NewCommunicationTemplateId
		--		,[CommunicationTypeId]
		--	   ,[PropertyId]
		--	   ,'+@ToCompany+' as [CompanyId]
		--	   ,[TemplateName]
		--	   ,[Subject]
		--	   ,[Message]
		--	   ,[IsSms]
		--	   ,[IsEmail]
		--	   ,[IsVoice]
		--	   ,[SenderName]
		--	   ,[SenderEmail]
		--	   ,[SenderPhone]
		--	   ,[AttachmentId]
		--	   ,'+@ToCompany+' as [CommunicationTemplate_CS_CompanyId]
		  
          
		--From
		--		TempCommunicationTemplate

------------------------------
--Start Inspection Module (PI) Without WOs
if @DoPI=1 and @DoTR=0
begin
        --1. InspectionTemplate
        PRINT 'Insert InspectionTemplate';
        SET @sql = '
		if exists (select Insptemp.*
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Insptemp   
inner join  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate a
on Insptemp.InspectionTemplateId = a.InspectionTemplateid
where 
a.PropertyId in '+@FromProperty+'
and Insptemp.companyid = '+ @FromCompany + '
)
Select next value for seq_InspectionTemplate over (order by Insptemp.InspectionTemplateID) as newInspectionTemplateID, Insptemp.*
into dbo.tempInspectionTemplate
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Insptemp   inner join  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate a
on Insptemp.InspectionTemplateId = a.InspectionTemplateid
where a.PropertyId in '+@FromProperty+'
and Insptemp.companyid = '+ @FromCompany + '

if not exists (select Insptemp.*
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Insptemp   inner join  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate a
on Insptemp.InspectionTemplateId = a.InspectionTemplateid
where 
a.PropertyId in '+@FromProperty+'
and Insptemp.companyid = '+ @FromCompany + '
)
Select next value for seq_InspectionTemplate as newInspectionTemplateID, Insptemp.*
into dbo.tempInspectionTemplate
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Insptemp   inner join  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate a
on Insptemp.InspectionTemplateId = a.InspectionTemplateid
where  Insptemp.companyid = '+ @FromCompany + '

DELETE t FROM tempInspectionTemplate t INNER JOIN (
SELECT InspectionTemplateID, MAX(newInspectionTemplateID)  AS  newInspectionTemplateID FROM tempInspectionTemplate
GROUP BY InspectionTemplateID
HAVING COUNT(*)  > 1
) a ON t.InspectionTemplateID = a.InspectionTemplateID
AND t.newInspectionTemplateID <> a.newInspectionTemplateID


Update tempInspectionTemplate
set EmployeeId_CreatedBy = -3
where EmployeeId_CreatedBy >0

Update tempInspectionTemplate
set Companyid =  '+ @ToCompany + '

update tempInspectionTemplate
set EmployeeId_CreatedBy = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTemplate vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Fvd on vd.InspectionTemplateId = Fvd.InspectionTemplateId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_CreatedBy = ulk.oldid
where
	vd.EmployeeId_CreatedBy = -3 and ulk.tablename = ''Commonemployee''

select * from tempInspectionTemplate where EmployeeId_CreatedBy not in (select employeeid from employee)
and EmployeeId_CreatedBy is not null

Update tempInspectionTemplate 
set EmployeeId_CreatedBy = 0 
where EmployeeId_CreatedBy not in (select employeeid from employee)
and EmployeeId_CreatedBy is not null

--select * from tempInspectionTemplate
if exists (select * from tempInspectionTemplate) Begin

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTemplate'',
        	''InspectionTemplateID'',
        	InspectionTemplateID,
        	newInspectionTemplateID
        From
           	dbo.tempInspectionTemplate


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTemplate''
  ,@ToTable =''InspectionTemplate''
  ,@CompanyId = '+@ToCompany+'
  

End

';
        --PRINT (@sql)
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionTemplate]
    --        ([InspectionTemplateId]
    --        ,[Name]
    --        ,[DateInactive]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[EmployeeId_CreatedBy]
	-- 	   ,[CompanyId]
	-- 		,[IsCorporate]
	-- 		,[AppliesToAllProperties]
	-- 		,InspectionTemplate_cs_companyid
	-- 	   )
    -- select [NewInspectionTemplateId]
    --        ,[Name]
    --        ,[DateInactive]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[EmployeeId_CreatedBy]
	-- 	    ,[CompanyId]
	-- 		,[IsCorporate]
	-- 		,[AppliesToAllProperties]
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
	-- 	tempInspectionTemplate

        PRINT 'Insert InspectionPropertyTemplate';
        SET @sql = '
Select next value for seq_InspectionPropertyTemplate over (order by Insptemp.InspectionPropertyTemplateId) as newInspectionPropertyTemplateID, Insptemp.*
into dbo.tempInspectionPropertyTemplate
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate Insptemp   
where Insptemp.PropertyId in '+@FromProperty+'



Update tempInspectionPropertyTemplate
set EmployeeId_UpdatedBy = -3
where EmployeeId_UpdatedBy >0

Update tempInspectionPropertyTemplate
set Propertyid = -3


Update tempInspectionPropertyTemplate
set InspectionTemplateid = -3
WHERE InspectionTemplateid > 0 AND InspectionTemplateid IS NOT null


update tempInspectionPropertyTemplate
set EmployeeId_UpdatedBy = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionPropertyTemplate vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate Fvd on vd.InspectionPropertyTemplateID = Fvd.InspectionPropertyTemplateID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_UpdatedBy = ulk.oldid
where
	vd.EmployeeId_UpdatedBy = -3 and ulk.tablename = ''Commonemployee''

update tempInspectionPropertyTemplate
set PropertyID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionPropertyTemplate vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate Fvd on vd.InspectionPropertyTemplateID = Fvd.InspectionPropertyTemplateID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.PropertyID = ulk.oldid
where
	vd.PropertyID = -3 and ulk.tablename = ''Property''



update tempInspectionPropertyTemplate
set InspectionTemplateid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionPropertyTemplate vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate Fvd on vd.InspectionPropertyTemplateID = Fvd.InspectionPropertyTemplateID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateid = ulk.oldid
where
	vd.InspectionTemplateid = -3 and ulk.tablename = ''InspectionTemplate''


--select * from InspectionTemplate

Update tempInspectionPropertyTemplate 
set EmployeeId_UpdatedBy = 0 
where EmployeeId_UpdatedBy not in (select employeeid from employee)
and EmployeeId_UpdatedBy is not null

if exists (select * from tempInspectionPropertyTemplate) Begin

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionPropertyTemplate'',
        	''InspectionPropertyTemplateID'',
        	InspectionPropertyTemplateID,
        	newInspectionPropertyTemplateID
        From
           	dbo.tempInspectionPropertyTemplate

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionPropertyTemplate''
  ,@ToTable =''InspectionPropertyTemplate''
  ,@CompanyId = '+@ToCompany+'

End

';
        --PRINT (@sql)
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionPropertyTemplate]
    --        (
	-- 	   [InspectionPropertyTemplateId]
    --        ,[InspectionTemplateId]
    --        ,[PropertyId]
    --        ,[DateInactive]
    --        ,[EmployeeId_UpdatedBy]
	-- 	   ,InspectionPropertyTemplate_cs_companyid
	-- 	   )
    -- select [NewInspectionPropertyTemplateId]
    --        ,[InspectionTemplateId]
    --        ,[PropertyId]
    --        ,[DateInactive]
    --        ,[EmployeeId_UpdatedBy]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From
	-- 	tempInspectionPropertyTemplate

        --2.InspectionScaleDefinition
        PRINT 'Insert InspectionScaleDefinition';
        SET @sql = '
Select next value for seq_InspectionScaleDefinition over (order by a.InspectionScaleDefinitionID) as newInspectionScaleDefinitionID, a.*
into dbo.tempInspectionScaleDefinition
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionScaleDefinition a   inner join  tempInspectionTemplate b
on a.InspectionTemplateId = b.InspectionTemplateid

Update tempInspectionScaleDefinition
set InspectionTemplateId = -3
where InspectionTemplateId > 0


update tempInspectionScaleDefinition
set InspectionTemplateId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionScaleDefinition vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionScaleDefinition Fvd on vd.InspectionScaleDefinitionId = Fvd.InspectionScaleDefinitionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateId = ulk.oldid
where
	vd.InspectionTemplateId = -3 and ulk.tablename = ''InspectionTemplate''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionScaleDefinition'',
        	''InspectionScaleDefinitionId'',
        	InspectionScaleDefinitionId,
        	NewInspectionScaleDefinitionId
        From
           	dbo.TempInspectionScaleDefinition


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionScaleDefinition''
  ,@ToTable =''InspectionScaleDefinition''
  ,@CompanyId = '+@ToCompany+'
  
';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionScaleDefinition]
    --        ([InspectionScaleDefinitionId]
    --        ,[InspectionTemplateId]
    --        ,[Text]
    --        ,[Value]
    --        ,[IsFailure]
	-- 	   ,InspectionScaleDefinition_cs_companyid
	-- 	   )
    -- select [NewInspectionScaleDefinitionId]
    --        ,[InspectionTemplateId]
    --        ,[Text]
    --        ,[Value]
    --        ,[IsFailure]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionScaleDefinition

        --2.InspectionTemplateSection
        PRINT 'Insert InspectionTemplateSection';
        SET @sql = '
Select next value for seq_InspectionTemplateSection over (order by a.InspectionTemplateSectionID) as newInspectionTemplateSectionID, a.*
into dbo.tempInspectionTemplateSection
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplateSection a   inner join  tempInspectionTemplate b
on a.InspectionTemplateId = b.InspectionTemplateid

Update tempInspectionTemplateSection
set InspectionTemplateId = -3
where InspectionTemplateId >0

Update tempInspectionTemplateSection
set InspectionTemplateId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTemplateSection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplateSection Fvd on vd.InspectionTemplateSectionId = Fvd.InspectionTemplateSectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateId = ulk.oldid
where
	vd.InspectionTemplateId = -3 and ulk.tablename = ''InspectionTemplate''

	select * from tempInspectionTemplateSection
	where InspectionTemplateId not in (Select InspectionTemplateId from InspectionTemplate)

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTemplateSection'',
        	''InspectionTemplateSectionId'',
        	InspectionTemplateSectionId,
        	NewInspectionTemplateSectionId
        From
           	dbo.TempInspectionTemplateSection


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTemplateSection''
  ,@ToTable =''InspectionTemplateSection''
  ,@CompanyId = '+@ToCompany+'
  
';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionTemplateSection]
    --        ([InspectionTemplateSectionId]
    --        ,[InspectionTemplateId]
    --        ,[Title]
    --        ,[Sequence]
    --        ,[DateInactive]
	-- 	   ,InspectionTemplateSection_cs_companyid
	-- 	   )
    -- select [NewInspectionTemplateSectionId]
    --        ,[InspectionTemplateId]
    --        ,[Title]
    --        ,[Sequence]
    --        ,[DateInactive]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionTemplateSection

        --2.InspectionTemplateSectionTask
        PRINT 'Insert InspectionTemplateSectionTask';
        SET @sql = '
Select next value for seq_InspectionTemplateSectionTask over (order by a.InspectionTemplateSectionTaskID) as newInspectionTemplateSectionTaskID, a.*
into dbo.tempInspectionTemplateSectionTask
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplateSectionTask a   inner join  tempInspectionTemplateSection b
on a.InspectionTemplateSectionId = b.InspectionTemplateSectionId

Update tempInspectionTemplateSectionTask
set InspectionTemplateSectionId = -3
where InspectionTemplateSectionId >0

Update tempInspectionTemplateSectionTask
set InspectionTemplateSectionId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTemplateSectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplateSectionTask Fvd on vd.InspectionTemplateSectionTaskId = Fvd.InspectionTemplateSectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateSectionId = ulk.oldid
where
	vd.InspectionTemplateSectionId = -3 and ulk.tablename = ''InspectionTemplateSection''

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTemplateSectionTask'',
        	''InspectionTemplateSectionTaskId'',
        	InspectionTemplateSectionTaskId,
        	NewInspectionTemplateSectionTaskId
        From
           	dbo.TempInspectionTemplateSectionTask


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTemplateSectionTask''
  ,@ToTable =''InspectionTemplateSectionTask''
  ,@CompanyId = '+@ToCompany+'
  
';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionTemplateSectionTask]
    --        ([InspectionTemplateSectionTaskId]
    --        ,[InspectionTemplateSectionId]
    --        ,[Description]
    --        ,[Sequence]
    --        ,[DateInactive]
    --        ,[DateCreated]
    --        ,[Weight]
	-- 	   ,InspectionTemplateSectionTask_cs_companyid
	-- 	   )
    -- select [NewInspectionTemplateSectionTaskId]
    --        ,[InspectionTemplateSectionId]
    --        ,[Description]
    --        ,[Sequence]
    --        ,[DateInactive]
    --        ,[DateCreated]
    --        ,[Weight]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionTemplateSectionTask

        ------------------
        -- InspectionSchedule
        PRINT 'Insert InspectionSchedule';
        SET @sql = '
Select next value for seq_InspectionSchedule over (order by a.InspectionScheduleID) as newInspectionScheduleID, a.*
into dbo.tempInspectionSchedule
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule a
where a.Propertyid in '+@FromProperty+'

Update tempInspectionSchedule
set buildingid = -3 where buildingid > 0

Update tempInspectionSchedule
set Propertyid = -3 where Propertyid > 0

Update tempInspectionSchedule
set EmployeeId_AssignedToSchedule = -3 where EmployeeId_AssignedToSchedule > 0

Update tempInspectionSchedule
set EmployeeId_AssignedToNextInspection = -3 where EmployeeId_AssignedToNextInspection > 0


Update tempInspectionSchedule
set InspectionTemplateId = -3 where InspectionTemplateId > 0



update tempInspectionSchedule
set EmployeeId_AssignedToSchedule = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_AssignedToSchedule = ulk.oldid
where
	vd.EmployeeId_AssignedToSchedule = -3 and ulk.tablename = ''Commonemployee''


update tempInspectionSchedule
set EmployeeId_AssignedToNextInspection = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_AssignedToNextInspection = ulk.oldid
where
	vd.EmployeeId_AssignedToNextInspection = -3 and ulk.tablename = ''Commonemployee''



update tempInspectionSchedule
set Propertyid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Propertyid = ulk.oldid
where
	vd.Propertyid = -3 and ulk.tablename = ''Property''



update tempInspectionSchedule
set Buildingid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Buildingid = ulk.oldid
where
	vd.Buildingid = -3 and ulk.tablename = ''Building''



update tempInspectionSchedule
set InspectionTemplateId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateId = ulk.oldid
where
	vd.InspectionTemplateId = -3 and ulk.tablename = ''InspectionTemplate''


	delete from tempInspectionSchedule where InspectionTemplateId not in (Select InspectionTemplateId from InspectionTemplate)

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionSchedule'',
        	''InspectionScheduleId'',
        	InspectionScheduleId,
        	NewInspectionScheduleId
        From
           	dbo.TempInspectionSchedule

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionSchedule''
  ,@ToTable =''InspectionSchedule''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionSchedule]
    --        (
	-- 	   [InspectionScheduleId]
    --        ,[InspectionTemplateId]
    --        ,[BuildingId]
    --        ,[EmployeeId_AssignedToSchedule]
    --        ,[Frequency]
    --        ,[EstimatedCompletionTimeInMinutes]
    --        ,[LocationDetails]
    --        ,[CancellationNotes]
    --        ,[DateInactive]
    --        ,[NextScheduleDate]
    --        ,[DateCreated]
    --        ,[GeneralInspectionNote]
    --        ,[DaysToComplete]
    --        ,[ExpectedCompletionDate]
    --        ,[PropertyId]
    --        ,[StartDate]
    --        ,[NextIssueDate]
    --        ,[EmployeeId_AssignedToNextInspection]
	-- 	   ,[IssueOnWeekends]
	-- 	   ,InspectionSchedule_cs_companyid
	-- 	   )
    -- select [NewInspectionScheduleId]
    --        ,[InspectionTemplateId]
    --        ,[BuildingId]
    --        ,[EmployeeId_AssignedToSchedule]
    --        ,[Frequency]
    --        ,[EstimatedCompletionTimeInMinutes]
    --        ,[LocationDetails]
    --        ,[CancellationNotes]
    --        ,[DateInactive]
    --        ,[NextScheduleDate]
    --        ,[DateCreated]
    --        ,[GeneralInspectionNote]
    --        ,[DaysToComplete]
    --        ,[ExpectedCompletionDate]
    --        ,[PropertyId]
    --        ,[StartDate]
    --        ,[NextIssueDate]
    --        ,[EmployeeId_AssignedToNextInspection]
	-- 	   ,[IssueOnWeekends]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionSchedule

        -- InspectionScheduleArea

        PRINT 'Insert InspectionScheduleArea';
        SET @sql = '
Select next value for seq_InspectionScheduleArea over (order by a.InspectionScheduleAreaID) as newInspectionScheduleAreaID, a.*
into dbo.tempInspectionScheduleArea
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionScheduleArea a inner join tempInspectionSchedule b
on a.InspectionScheduleId = b.InspectionScheduleId

Update tempInspectionScheduleArea
set PropertyId = -3
where PropertyId > 0

update tempInspectionScheduleArea
set AreaID = -3
where AreaID >0



update tempInspectionScheduleArea
set InspectionScheduleId = -3
where InspectionScheduleId >0


update tempInspectionScheduleArea
set Propertyid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionScheduleArea vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionScheduleArea Fvd on vd.InspectionScheduleAreaId = Fvd.InspectionScheduleAreaId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Propertyid = ulk.oldid
where
	vd.Propertyid = -3 and ulk.tablename = ''Property''



update tempInspectionScheduleArea
set Areaid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionScheduleArea vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionScheduleArea Fvd on vd.InspectionScheduleAreaId = Fvd.InspectionScheduleAreaId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Areaid = ulk.oldid
where
	vd.Areaid = -3 and ulk.tablename = ''Area''



update tempInspectionScheduleArea
set InspectionScheduleId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionScheduleArea vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionScheduleArea Fvd on vd.InspectionScheduleAreaId = Fvd.InspectionScheduleAreaId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionScheduleId = ulk.oldid
where
	vd.InspectionScheduleId = -3 and ulk.tablename = ''InspectionSchedule''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionScheduleArea'',
        	''InspectionScheduleAreaId'',
        	InspectionScheduleAreaId,
        	NewInspectionScheduleAreaId
        From
           	dbo.TempInspectionScheduleArea


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionScheduleArea''
  ,@ToTable =''InspectionScheduleArea''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);

    -- insert '+@ToDB+'.[dbo].[InspectionScheduleArea]
    --        (
	-- 	   [InspectionScheduleAreaId]
    --        ,[InspectionScheduleId]
    --        ,[AreaId]
    --        ,[DateInactive]
    --        ,[DateCreated]
    --        ,[PropertyId]
	-- 	   ,InspectionScheduleArea_cs_Companyid
	-- 	   )
    -- select [NewInspectionScheduleAreaId]
    --        ,[InspectionScheduleId]
    --        ,[AreaId]
    --        ,[DateInactive]
    --        ,[DateCreated]
    --        ,[PropertyId]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionScheduleArea

        -- Inspection

        PRINT 'Insert Inspection';
        SET @sql = '
Select next value for seq_Inspection over (order by a.InspectionID) as newInspectionID, a.*
into dbo.tempInspection
from '+@Fromserver+'.'+@FromDB+'.dbo.Inspection a inner join tempInspectionSchedule b
on a.InspectionScheduleId = b.InspectionScheduleId

Update tempInspection
set InspectionScheduleId = -3
where InspectionScheduleId >0

Update tempInspection
set EmployeeId_Assigned = -3
where EmployeeId_Assigned >0


Update tempInspection
set EmployeeId_CompletedBy = -3
where EmployeeId_CompletedBy >0


update tempInspection
set InspectionScheduleId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Inspection Fvd on vd.InspectionId = Fvd.InspectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionScheduleId = ulk.oldid
where
	vd.InspectionScheduleId = -3 and ulk.tablename = ''InspectionSchedule''



update tempInspection
set EmployeeId_Assigned = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Inspection Fvd on vd.InspectionId = Fvd.InspectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_Assigned = ulk.oldid
where
	vd.EmployeeId_Assigned = -3 and ulk.tablename = ''Commonemployee''



update tempInspection
set EmployeeId_CompletedBy = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Inspection Fvd on vd.InspectionId = Fvd.InspectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_CompletedBy = ulk.oldid
where
	vd.EmployeeId_CompletedBy = -3 and ulk.tablename = ''Commonemployee''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Inspection'',
        	''InspectionId'',
        	InspectionId,
        	NewInspectionId
        From
           	dbo.TempInspection

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspection''
  ,@ToTable =''Inspection''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);

    -- insert '+@ToDB+'.[dbo].[Inspection]
    --        (
	-- 	   [InspectionId]
    --        ,[InspectionScheduleId]
    --        ,[EmployeeId_Assigned]
    --        ,[ExpectedCompletionDate]
    --        ,[DateCreated]
    --        ,[Status]
    --        ,[IsManual]
    --        ,[DateCompleted]
    --        ,[EmployeeId_CompletedBy]
    --        ,[DateUpdated]
    --        ,[WorkStartedDate]
	-- 	   ,inspection_cs_companyid
	-- 	   )
    -- select [NewInspectionId]
    --        ,[InspectionScheduleId]
    --        ,[EmployeeId_Assigned]
    --        ,[ExpectedCompletionDate]
    --        ,[DateCreated]
    --        ,[Status]
    --        ,[IsManual]
    --        ,[DateCompleted]
    --        ,[EmployeeId_CompletedBy]
    --        ,[DateUpdated]
    --        ,[WorkStartedDate]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspection

        -- InspectionHistory

        PRINT 'Insert InspectionHistory';
        SET @sql = '
Select next value for seq_InspectionHistory over (order by a.InspectionHistoryID) as newInspectionHistoryID, a.*
into dbo.tempInspectionHistory
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory a inner join tempInspection b
on a.InspectionId = b.InspectionID

Update tempInspectionHistory
set InspectionId = -3
where InspectionId >0

Update tempInspectionHistory
set EmployeeId_History = -3
where EmployeeId_History >0


Update tempInspectionHistory
set EmployeeId_Updated = -3
where EmployeeId_Updated >0


update tempInspectionHistory
set InspectionId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory Fvd on vd.InspectionHistoryId = Fvd.InspectionHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionId = ulk.oldid
where
	vd.InspectionId = -3 and ulk.tablename = ''Inspection''



update tempInspectionHistory
set EmployeeId_History = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory Fvd on vd.InspectionHistoryId = Fvd.InspectionHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_History = ulk.oldid
where
	vd.EmployeeId_History = -3 and ulk.tablename = ''Commonemployee''



update tempInspectionHistory
set EmployeeId_Updated = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory Fvd on vd.InspectionHistoryId = Fvd.InspectionHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_Updated = ulk.oldid
where
	vd.EmployeeId_Updated = -3 and ulk.tablename = ''Commonemployee''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionHistory'',
        	''InspectionHistoryId'',
        	InspectionHistoryId,
        	NewInspectionHistoryId
        From
           	dbo.TempInspectionHistory


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionHistory''
  ,@ToTable =''InspectionHistory''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);

    -- insert '+@ToDB+'.[dbo].[InspectionHistory]
    --        (
	-- 	   [InspectionHistoryId]
    --        ,[InspectionId]
    --        ,[EmployeeId_History]
    --        ,[Event]
    --        ,[DurationInMinutes]
    --        ,[Notes]
    --        ,[DateCreated]
    --        ,[EmployeeId_Updated]
	-- 	   ,InspectionHistory_cs_companyid
	-- 	   )
    -- select [NewInspectionHistoryId]
    --        ,[InspectionId]
    --        ,[EmployeeId_History]
    --        ,[Event]
    --        ,[DurationInMinutes]
    --        ,[Notes]
    --        ,[DateCreated]
    --        ,[EmployeeId_Updated]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionHistory

        -- InspectionTask

        PRINT 'Insert InspectionTask';
        SET @sql = '
Select next value for seq_InspectionTask over (order by a.InspectionTaskID) as newInspectionTaskID, a.*
into dbo.tempInspectionTask
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask a inner join tempInspection b
on a.InspectionId = b.InspectionID

Update tempInspectionTask
set InspectionId = -3
where InspectionId >0

Update tempInspectionTask
set InspectionScheduleAreaId = -3
where InspectionScheduleAreaId >0



Update tempInspectionTask
set InspectionTemplateSectionTaskId = -3
where InspectionTemplateSectionTaskId >0 and InspectionTemplateSectionTaskId is not null

Update tempInspectionTask
set WorkOrderId = -3
where WorkOrderId >0


update tempInspectionTask
set InspectionId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionId = ulk.oldid
where
	vd.InspectionId = -3 and ulk.tablename = ''Inspection''



update tempInspectionTask
set InspectionScheduleAreaId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionScheduleAreaId = ulk.oldid
where
	vd.InspectionScheduleAreaId = -3 and ulk.tablename = ''InspectionScheduleArea''



update tempInspectionTask
set WorkOrderId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.WorkOrderId = ulk.oldid
where
	vd.WorkOrderId = -3 and ulk.tablename = ''WorkOrder''

Update tempInspectionTask
set InspectionScaleDefinitionId = -3
where InspectionScaleDefinitionId >0


update tempInspectionTask
set InspectionScaleDefinitionId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionScaleDefinitionId = ulk.oldid
where
	vd.InspectionScaleDefinitionId = -3 and ulk.tablename = ''InspectionScaleDefinition''



update tempInspectionTask
set InspectionTemplateSectionTaskId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateSectionTaskId = ulk.oldid
where
	vd.InspectionTemplateSectionTaskId = -3 and ulk.tablename = ''InspectionTemplateSectionTask''




Update tempInspectionTask
set InspectionScaleDefinitionId = null
where InspectionScaleDefinitionId not in (select InspectionScaleDefinitionId from InspectionScaleDefinition)


delete from tempInspectionTask where InspectionTemplateSectionTaskId not in (Select newInspectionTemplateSectionTaskId from tempInspectionTemplateSectionTask)

select * from tempInspectionTask where InspectionTemplateSectionTaskId not in (Select InspectionTemplateSectionTaskId from InspectionTemplateSectionTask)

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTask'',
        	''InspectionTaskId'',
        	InspectionTaskId,
        	NewInspectionTaskId
        From
           	dbo.TempInspectionTask


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTask''
  ,@ToTable =''InspectionTask''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);

    -- insert '+@ToDB+'.[dbo].[InspectionTask]
    --        (
	-- 	   [InspectionTaskId]
    --        ,[InspectionId]
    --        ,[InspectionTemplateSectionTaskId]
    --        ,[InspectionScaleDefinitionId]
    --        ,[InspectionScheduleAreaId]
    --        ,[WorkOrderId]
    --        ,[Notes]
    --        ,[RequiresCorrection]
    --        ,[DateUpdated]
	-- 	   ,InspectionTask_cs_companyid
	-- 	   )
    -- select [NewInspectionTaskId]
    --        ,[InspectionId]
    --        ,[InspectionTemplateSectionTaskId]
    --        ,[InspectionScaleDefinitionId]
    --        ,[InspectionScheduleAreaId]
    --        ,[WorkOrderId]
    --        ,[Notes]
    --        ,[RequiresCorrection]
    --        ,[DateUpdated]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionTask

        -- InspectionTaskAttachment

        PRINT 'Insert InspectionTaskAttachment';
        SET @sql = '
Select next value for seq_InspectionTaskAttachment over (order by a.InspectionTaskAttachmentID) as newInspectionTaskAttachmentID, a.*
into dbo.tempInspectionTaskAttachment
--from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTaskAttachment a inner join tempInspectionTask b
from '+@Fromserver+'.'+@FromDB+'.dbo.view_InspectionTaskAttachment a inner join tempInspectionTask b
on a.InspectionTaskId = b.InspectionTaskID

Update tempInspectionTaskAttachment
set InspectionTaskId = -3
where InspectionTaskId >0



update tempInspectionTaskAttachment
set InspectionTaskId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTaskAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTaskAttachment Fvd on vd.InspectionTaskAttachmentId = Fvd.InspectionTaskAttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTaskId = ulk.oldid
where
	vd.InspectionTaskId = -3 and ulk.tablename = ''InspectionTask''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTaskAttachment'',
        	''InspectionTaskAttachmentId'',
        	InspectionTaskAttachmentId,
        	NewInspectionTaskAttachmentId
        From
           	dbo.TempInspectionTaskAttachment


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTaskAttachment''
  ,@ToTable =''InspectionTaskAttachment''
  ,@CompanyId = '+@ToCompany+'

';
        exec (@sql);

    -- insert '+@ToDB+'.[dbo].[InspectionTaskAttachment]
    --        (
	-- 	   [InspectionTaskAttachmentId]
    --        ,[InspectionTaskId]
    --        ,[FileName]
    --        ,[FileSize]
    --        ,[Content]
    --        ,[DateCreated]
	-- 	   ,InspectionTaskAttachment_cs_companyid
	-- 	   ,isResized
	-- 	   )
    -- select [NewInspectionTaskAttachmentId]
    --        ,[InspectionTaskId]
    --        ,[FileName]
    --        ,[FileSize]
    --        ,[Content]
    --        ,[DateCreated]
	-- 	   ,'+@ToCompany+' as cs_companyid
	-- 	   ,isResized
    -- From   tempInspectionTaskAttachment

end --PI if DoTR=0
--End of Inspection
---------------------

    -- Usually we need Tenant and Contact
    IF @DoTR = 1
             BEGIN
        PRINT 'Insert Request';

        /*SELECT @maxid = MAX(ids) + 10
            FROM   (
                   SELECT MAX(requestid) AS IDs
                   FROM   dbo.request
                   UNION
                   SELECT MAX(WorkOrderid) AS IDs
                   FROM   dbo.Workorder
                   UNION
                   SELECT MAX(ReservationID) AS IDs
                   FROM   dbo.reservation
                   ) z */

        SET @sql = '
Select next value for seq_Document over (order by a.RequestId) as newRequestId , a.*
into dbo.TempRequest
from
(select r.* from  '+@Fromserver+'.'+@FromDB+'.dbo.request r  inner join   '+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on r.RequestId = wo.RequestId
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b  on b.buildingid = wo.buildingid
where b.propertyid in '+@FromProperty+' and wo.wotype = ''TR''

union
select r1.* from '+@Fromserver+'.'+@FromDB+'.dbo.request r1  inner join temparea a  on r1.areaid = a.areaid
) as a


update tr
set
    tr.Requesttypeid = b.[newid]
from
    temprequest tr with (nolock) inner join mapping b with (nolock)
on
    tr.Requesttypeid = b.fromid
where
    b.tablename = ''RT''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update tr
set
    tr.tradeid = b.[newid]
from
    temprequest tr with (nolock) inner join mapping b with (nolock)
on
    tr.tradeid = b.fromid
where
    b.tablename = ''Trade''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

';
        EXEC (@sql);
      
       -- SET @sql = '
     SET @c1 = '
update TempRequest set BuildingId = -3, TenantId = -3, ContactId = -3,  AreaId = -3, RequestTypeId = -3,TradeId = -3, EmployeeIdOwner = -3, EmployeeIdRequested = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3
update tempRequest
set BulletinId  = -3
where BulletinId  is not null and BulletinId  <> 0

Update tempRequest set ContactIdAuthorizer = -3 where ContactIdAuthorizer <> 0

update r
set r.buildingId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.buildingid = ulk.oldid
where
	r.buildingid = -3 and ulk.tablename = ''Building''
update r
set r.buildingId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.buildingid = ulk.oldid
where
	r.buildingid = -3 and ulk.tablename = ''Building''
update r
set r.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.TenantId = ulk.oldid
where
	r.TenantId = -3 and ulk.tablename = ''Tenant''
update r
set r.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.TenantId = ulk.oldid
where
	r.TenantId = -3 and ulk.tablename = ''Tenant''

update r
set r.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.ContactId = ulk.oldid
where
	r.ContactId = -3 and ulk.tablename = ''Contact''
update r
set r.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.ContactId = ulk.oldid
where
	r.ContactId = -3 and ulk.tablename = ''Contact''
update r
set r.ContactIdAuthorizer = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.ContactId = ulk.oldid
where
	r.ContactIdAuthorizer = -3 and ulk.tablename = ''Contact''
update r
set r.ContactIdAuthorizer = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.ContactId = ulk.oldid
where
	r.ContactIdAuthorizer = -3 and ulk.tablename = ''Contact''
update r
set r.AreaId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.AreaId = ulk.oldid
where
	r.AreaId = -3 and ulk.tablename = ''Area''
update r
set r.AreaId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.AreaId = ulk.oldid
where
	r.AreaId = -3 and ulk.tablename = ''Area''

update r
set r.RequestTypeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.RequestTypeId = ulk.oldid
where
	r.RequestTypeId = -3 and ulk.tablename = ''RequestType''
update r
set r.RequestTypeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.RequestTypeId = ulk.oldid
where
	r.RequestTypeId = -3 and ulk.tablename = ''RequestType''
'
--print @C1 
SET @c2 = '
update r
set r.TradeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.TradeId = ulk.oldid
where
	r.TradeId = -3 and ulk.tablename = ''Trade''
update r
set r.TradeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.TradeId = ulk.oldid
where
	r.TradeId = -3 and ulk.tablename = ''Trade''
update r
set r.EmployeeIdOwner = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.EmployeeIdOwner = ulk.oldid
where
	r.EmployeeIdOwner = -3 and ulk.tablename = ''Employee''
update r
set r.EmployeeIdOwner = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.EmployeeIdOwner = ulk.oldid
where
	r.EmployeeIdOwner = -3 and ulk.tablename = ''Employee''
update r
set r.EmployeeIdRequested = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.EmployeeIdRequested = ulk.oldid
where
	r.EmployeeIdRequested = -3 and ulk.tablename = ''Employee''
update r
set r.EmployeeIdRequested = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fr.EmployeeIdRequested = ulk.oldid
where
	r.EmployeeIdRequested = -3 and ulk.tablename = ''Employee''
update r
set r.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.EmployeeIdCreated = ulk.oldid
where
	r.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''
update r
set r.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.EmployeeIdCreated = ulk.oldid
where
	r.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''
';
--print @C2
--        EXEC (@sql);
        EXEC (@c1+@c2);

        SET @sql = '

update r
set r.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on Fr.RequestID = wo.RequestID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on wo.EmployeeIdUpdated = ulk.oldid
where
	r.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''


update r
set r.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fr on r.requestid = Fr.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.EmployeeIdUpdated = ulk.oldid
where
	r.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''


update a
set
	a.BulletinID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempRequest a with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Request Fa on a.requestid = Fa.requestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fa.BulletinID = ulk.oldid
where
	a.BulletinID = -3 and ulk.tablename = ''Bulletin''
';
        EXEC (@sql);

        -- Update tenant and contact across property
        SET @sql = '
Select
    tr.requestid,
    fb.propertyid,
    fr.tenantid,
    ft.tenantname,
    fr.contactid,
    fc.contactname,
    tr.areaid,
    tr.buildingid,
    tr.tenantid as newtid,
    tr.contactid as newcid
into tempRTC
from
    '+@Fromserver+'.'+@FromDB+'.dbo.building fb
    inner join '+@Fromserver+'.'+@FromDB+'.dbo.Request fr on fb.buildingid = fr.buildingid
    inner join temprequest tr on fr.requestid = tr.requestid
    inner join '+@Fromserver+'.'+@FromDB+'.dbo.contact fc on fr.contactid = fc.contactid
    inner join '+@Fromserver+'.'+@FromDB+'.dbo.tenant ft on ft.tenantid = fr.tenantid
where
    tr.tenantid = -3 or tr.contactid = -3

update tempRTC
set tempRTC.propertyid = a.[newid]
from
    dbo.'+@lookup+' a
where
    tempRTC.propertyid = a.oldid
and
    a.tablename = ''property''

update tempRTC
set tempRTC.newtid = temptenant.newtenantid
from
    temptenant
where
    tempRTC.tenantname = temptenant.tenantname
and
    tempRTC.newtid = -3

update tempRTC
set tempRTC.newcid = tempcontact.newcontactid
from
    tempcontact
where
    tempRTC.contactname = tempcontact.contactname
and
    tempRTC.tenantid = tempcontact.basetenantid
and
    tempRTC.newcid = -3
';
        EXEC (@sql);

        SET @sql = '


Update tempRTC
set PropertyId = (select top 1 newpropertyid from tempProperty)
where newtid = -3

Declare @pid int
Declare @count int
Declare @tid int
Declare @tname varchar(100)
Declare @maxid int
Declare @cid int
Declare @cname varchar(100)
Declare @newtid int
Declare @areaid int

Declare everybodyhatesthistenant Cursor local for
Select distinct propertyid, tenantid, tenantname from tempRTC where newtid = -3 order by propertyid,tenantid
open everybodyhatesthistenant
fetch next from everybodyhatesthistenant into @pid, @tid, @tname
While @@Fetch_Status = 0 Begin

Select @maxid = next value for seq_Tenant

    insert '+@ToDB+'.dbo.Tenant (
        TenantId,
        BasePropertyId,
        TenantName,
		Tenant_cs_companyid
    )Output
         ''Tenant'' as TableName ,
        ''TenantID'' as columnname,
        @tid as oldId,
        INSERTED.TenantID     as [NewId]
		Into dbo.'+@lookup+'
			(
    			TableName,
        		ColumnName,
        		OldId,
        		[NewId]
			)
    Select
        @maxid,
        @pid,
        Convert(varchar(50), @tname + ''Dummy''+ convert(varchar, @maxid))
		,'+@ToCompany+' as  cs_companyid

    update tempRTC set newtid = m.[NewID]
    from tempRTC inner join  dbo.'+@lookup+' as m on tempRTC.TenantID = m.oldid
where
     tenantid = @tid and m.tableName = ''Tenant''
fetch next from everybodyhatesthistenant into @pid, @tid, @tname
End
Close everybodyhatesthistenant
Deallocate everybodyhatesthistenant

Declare everybodyhatesthiscontact Cursor local for
Select distinct contactid, contactname from tempRTC where newcid = -3 order by contactid
open everybodyhatesthiscontact
fetch next from everybodyhatesthiscontact into @cid, @cname
while @@Fetch_status = 0 Begin

    Select @newtid = newtid, @areaid = areaid from tempRTC  where
        contactid = @cid

    Select @maxid =  next value for seq_Contact
    Insert '+@ToDB+'.dbo.Contact (
        Contactid,
        BaseTenantid,
        BaseAreaid,
        ContactFirstName,
		Encryptedpassword
		,contact_cs_companyid
    )
    Select
        @maxid,
        @newtid,
        @areaid,
        convert(varchar(50), convert(varchar, @maxid) + @cname + ''Dummy'' ),
	dbo.fnEncrypt('''') as EncryptedPassword
	,'+@ToCompany+' as  cs_companyid

     update tempRTC set newcid = @maxid where contactid = @cid
fetch next from everybodyhatesthiscontact into @cid, @cname
End

Close everybodyhatesthiscontact
Deallocate everybodyhatesthiscontact

update temprequest
set
    temprequest.tenantid = tempRTC.newtid,
    temprequest.Contactid = tempRTC.newcid
From
    tempRTC
where
    temprequest.requestid = tempRTC.requestid
';
        EXEC (@sql);
        SET @sql = '
if exists (select * from temprequest) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Request'',
        	''RequestID'',
        	RequestID,
        	newRequestID
        From
           	dbo.TempRequest

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempRequest''
  ,@ToTable =''Request''
  ,@CompanyId = '+@ToCompany+'
 		
End
';
        EXEC (@sql);

    --  insert '+@ToDB+'.dbo.Request
    -- (
    --    RequestId,
    --     DisplayId,
	-- 	SortId,
    --     BuildingId,
    --     TenantId,
    --     ContactId,
    --     ContactIdAuthorizer,
    --     AreaId,
    --     RequestTypeId,
    --     TradeId,
    --     EmployeeIdOwner,
    --     EmployeeIdRequested,
    --     RequestStatus,
    --     --RequestStatusDescription,
    --     RequestSource,
    --     --RequestSourceDescription,
    --     CustomerReferenceNumber,
    --     RequestDetail,
    --     DateReceived,
    --     DateOpened,
    --     DateResponded,
    --     DateCompleted,
    --     DateCancelled,
    --     DateRequired,
    --     DateAuthorized,
    --     DateToEscalate1,
    --     DateToEscalate2,
    --     DateToEscalate3,
    --     DateEscalated1,
    --     DateEscalated2,
    --     DateEscalated3,
    --     Priority,
    --     --IsRfq,
    --     --IsRfqWaiting,
    --     IsWithMessages,
    --     IsWorkOrder,
    --     IsAuthorizationRequired,
    --     IsEstimate,
    --     IsEstimateRequired,
	-- 	IsNewRequestNotRoutedNotificationSent,
    --     EstimateStatus,
    --     TimeResponse,
    --     TimeCompletion,
    --     TimeOverdue,
    --     RequestCustom1,
    --     RequestCustom2,
    --     RequestCustom3,
    --     RequestCustom4,
    --     RequestCustom5,
    --     SecondaryContactName,
    --     SecondaryContactInfo,
    --     LocationNotes,
    --     LocationType,
    --     CostAsset,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated,
    --     tmpEmployeeId,
    --     tmpRequestId,
	-- 	BulletinId
	-- 	,Request_cs_companyid


    -- )
    -- Select
    --     newRequestId                ,
    --     '''' as DisplayId,
	-- 	'''' as SortId,
    --     BuildingId,
    --     TenantId,
    --     ContactId,
    --     ContactIdAuthorizer,
    --     AreaId,
    --     RequestTypeId,
    --     TradeId,
    --     EmployeeIdOwner,
    --     EmployeeIdRequested,
    --     RequestStatus,
    --     RequestSource,
    --     CustomerReferenceNumber,
    --     RequestDetail,
    --     DateReceived,
    --     DateOpened,
    --     DateResponded,
    --     DateCompleted,
    --     DateCancelled,
    --     DateRequired,
    --     DateAuthorized,
    --     DateToEscalate1,
    --     DateToEscalate2,
    --     DateToEscalate3,
    --     DateEscalated1,
    --     DateEscalated2,
    --     DateEscalated3,
    --     Priority,
    --     IsWithMessages,
    --     IsWorkOrder,
    --     IsAuthorizationRequired,
    --     IsEstimate,
    --     IsEstimateRequired,
	-- 	IsNewRequestNotRoutedNotificationSent,
    --     EstimateStatus,
	-- 	TimeResponse,
    --     TimeCompletion,
    --     TimeOverdue,
    --     RequestCustom1,
    --     RequestCustom2,
    --     RequestCustom3,
    --     RequestCustom4,
    --     RequestCustom5,
    --     SecondaryContactName,
    --     SecondaryContactInfo,
    --     LocationNotes,
    --     LocationType,
    --     CostAsset,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated,
    --     -1,
    --     -1,
	-- 	BulletinId
	-- 	,'+@ToCompany+' as  cs_companyid

    --     From
    --     temprequest
        PRINT 'Insert ReqHistory';
        SET @sql = '
Select next value for seq_ReqHistory over (order by rh.ReqHistoryId) as newReqHistoryId, rh.*
into dbo.Temprh
from '+@Fromserver+'.'+@FromDB+'.dbo.reqhistory rh  inner join temprequest r  on rh.requestid = r.requestid
--order by rh.reqhistoryid

update temprh
set
    temprh.requestid = r.newrequestid
from
    temprequest r with (nolock)
where
    temprh.requestid = r.requestid

update temprh
set
    temprh.EmployeeIdCreated = r.newEmployeeId
from
    tempce r with (nolock)
where
    temprh.EmployeeIdCreated = r.EmployeeId

update temprh
set
    temprh.EmployeeIdUpdated = r.newEmployeeId
from
    tempce r with (nolock)
where
    temprh.EmployeeIdUpdated = r.EmployeeId

update temprh set RequestId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3
update rh
set rh.RequestId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temprh rh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reqhistory Frh on rh.ReqHistoryId = Frh.ReqHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Frh.RequestId = ulk.oldid
where
	rh.RequestId = -3 and ulk.tablename = ''Request''

update rh
set rh.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temprh rh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reqhistory Frh on rh.ReqHistoryId = Frh.ReqHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Frh.EmployeeIdCreated = ulk.oldid
where
	rh.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update rh
set rh.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temprh rh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Reqhistory Frh on rh.ReqHistoryId = Frh.ReqHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Frh.EmployeeIdUpdated = ulk.oldid
where
	rh.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''';
        EXEC (@sql);
        SET @sql = '
if exists (select * from temprh) Begin
 Insert  dbo.'+@lookup+'
        (
    	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ReqHistory'',
        	''ReqHistoryID'',
        	ReqHistoryID,
        	newReqHistoryID
        From
           	dbo.temprh

        select * from temprh where requestid not in (select requestid from dbo.Request)
        delete from temprh where requestid not in (select requestid from dbo.Request)

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''temprh''
  ,@ToTable =''ReqHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Reqhistory
    -- (
    --     ReqHistoryId                ,
    --     RequestId                   ,
    --     ReqHistoryDate              ,
    --     ReqHistoryEvent             ,
    --     ReqHistoryStatus            ,
    --     ReqHistoryDetail            ,
    --     EmployeeIdCreated           ,
    --     DateCreated                 ,
    --     EmployeeIdUpdated           ,
    --     DateUpdated                 ,
    --     tmpRequestHistorySequence
	-- 	,Reqhistory_cs_companyid
    -- )
    -- Select
    --     newReqHistoryId                ,
    --     RequestId,
    --     ReqHistoryDate      ,
    --     ReqHistoryEvent             ,
    --     ReqHistoryStatus            ,
    --     ReqHistoryDetail            ,
    --     EmployeeIdCreated,
    --     DateCreated                 ,
    --     EmployeeIdUpdated,
    --     DateUpdated                 ,
    --     -1
	-- 	,'+@ToCompany+' as  cs_companyid
    -- From
    --     dbo.Temprh

        PRINT 'Insert Estimate';
        SET @sql = '
Select next value for seq_Estimate over (order by EST.EstimateId) as newEstimateid, EST.*
into dbo.TempEstimate
from '+@Fromserver+'.'+@FromDB+'.dbo.Estimate EST  inner join  '+@Fromserver+'.'+@FromDB+'.dbo.Workorder wo on EST.EstimateId = wo.EstimateId
Inner join   '+@Fromserver+'.'+@FromDB+'.dbo.Area ta on wo.Areaid = ta.Areaid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b  on b.buildingid = ta.buildingid
where b.propertyid in '+@FromProperty+' and wo.wotype = ''TR''
and Est.RequestID IN (Select RequestId from tempRequest)
--order by EST.EstimateId



update TempEstimate
set RequestId = -3,
EmployeeIdCreated = -3,
EmployeeIdUpdated = -3


update trwo
set trwo.RequestId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimate trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Estimate Ftrwo on trwo.EstimateId = Ftrwo.EstimateId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.RequestId = ulk.oldid
where
	trwo.RequestId = -3 and ulk.tablename = ''Request''

update trwo
set trwo.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimate trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Estimate Ftrwo on trwo.EstimateId = Ftrwo.EstimateId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdCreated = ulk.oldid
where
	trwo.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update trwo
set trwo.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimate trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Estimate Ftrwo on trwo.EstimateId = Ftrwo.EstimateId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdUpdated = ulk.oldid
where
	trwo.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''


if exists (select * from TempEstimate) Begin

Insert  dbo.'+@lookup+'
        (
    	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Estimate'',
        	''EstimateID'',
        	EstimateID,
        	newEstimateID
        From
           	dbo.TempEstimate

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEstimate''
  ,@ToTable =''Estimate''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.Estimate
    -- (
	-- 	EstimateId,
    --     RequestId,
    --     EstimateStatus,
    --     EstimateDetail,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated ,
	-- 	tmpEstimateID
	-- 	,Estimate_cs_companyid
    -- )
    -- Select
	-- 	NewEstimateId,
    --     RequestId,
    --     EstimateStatus,
    --     EstimateDetail,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated,
	-- 	tmpEstimateID
	-- 	,'+@ToCompany+' as  cs_companyid
    -- From
        -- dbo.TempEstimate

        PRINT 'Insert EstimateHistory';
        SET @sql = '
Select next value for seq_EstimateHistory over (order by ESTH.EstimateHistoryId) as newEstimateHistoryid, ESTH.*
into dbo.TempEstimateHistory
from '+@Fromserver+'.'+@FromDB+'.dbo.EstimateHistory ESTH   inner join tempEstimate r  on ESTH.Estimateid = r.Estimateid
--order by ESTH.EstimateHistoryId

update TempEstimateHistory
set EstimateId = -3,
EmployeeIdCreated = -3,
EmployeeIdUpdated = -3,
EmployeeId = -3,
ContactID = -3



update trwo
set trwo.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateHistory trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateHistory Ftrwo on trwo.EstimateHistoryId = Ftrwo.EstimateHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdCreated = ulk.oldid
where
	trwo.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update trwo
set trwo.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateHistory trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateHistory Ftrwo on trwo.EstimateHistoryId = Ftrwo.EstimateHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdUpdated = ulk.oldid
where
	trwo.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''



update trwo
set trwo.EmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateHistory trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateHistory Ftrwo on trwo.EstimateHistoryId = Ftrwo.EstimateHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeId = ulk.oldid
where
	trwo.EmployeeId = -3 and ulk.tablename = ''Employee''


update trwo
set trwo.EstimateId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateHistory trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateHistory Ftrwo on trwo.EstimateHistoryId = Ftrwo.EstimateHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EstimateId = ulk.oldid
where
	trwo.EstimateId = -3 and ulk.tablename = ''Estimate''


update trwo
set trwo.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateHistory trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateHistory Ftrwo on trwo.EstimateHistoryId = Ftrwo.EstimateHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ContactId = ulk.oldid
where
	trwo.ContactId = -3 and ulk.tablename = ''Contact''
	----???
	update TempEstimateHistory
	set ContactId = (select top 1 newContactId from tempcontact where newContactId <>0)
	where contactid not in (Select contactid from contact)

if exists (select * from TempEstimateHistory) Begin


Insert  dbo.'+@lookup+'
        (
    	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EstimateHistory'',
        	''EstimateHistoryID'',
        	EstimateHistoryID,
        	newEstimateHistoryID
        From
           	dbo.TempEstimateHistory

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEstimateHistory''
  ,@ToTable =''EstimateHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.EstimateHistory
    -- (
    --     EstimateHistoryId,
    --     EstimateId,
    --     EstimateHistoryEvent,
    --     EstimateHistoryDate,
    --     EstimateHistoryDetail,
    --     ContactId,
    --     EmployeeId,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated,
    --     tmpEstimateHistoryID
	-- 	,EstimateHistory_cs_companyid
    -- )

    -- Select
    --     newEstimateHistoryId                ,
    --     EstimateId,
    --     EstimateHistoryEvent,
    --     EstimateHistoryDate,
    --     EstimateHistoryDetail,
    --     ContactId,
    --     EmployeeId,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated   ,
    --     tmpEstimateHistoryID
	-- 	,'+@ToCompany+' as  cs_companyid
    -- From
    --     dbo.TempEstimateHistory

        PRINT 'Insert Schedule TR';
        SET @sql = '
Select next value for seq_Schedule over (order by sc.ScheduleId) as newscheduleid, sc.*
into dbo.TempScheduleTR
From
    dbo.TempRequest teR  inner join '+@Fromserver+'.'+@FromDB+'.dbo.Schedule sc  on teR.Requestid = sc.Requestid
where sc.requestid is not null
--order by sc.scheduleid


update dbo.TempScheduleTR
set dbo.TempScheduleTR.EmployeeIdAssigned = tempce.newemployeeid
from
    dbo.TempScheduleTR with (nolock) inner join tempce with (nolock) on dbo.TempScheduleTR.EmployeeIdAssigned = tempce.employeeid


if exists (select * from dbo.TempScheduleTR) Begin

Update TempScheduleTR set EquipmentId = 0, EmployeeIdAssigned = -3, requestid = -3

update sc
set  sc.EmployeeIdAssigned = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempScheduleTR sc with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Schedule Fsc on sc.Scheduleid = Fsc.Scheduleid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fsc.EmployeeIdAssigned = ulk.oldid
where
	sc.EmployeeIdAssigned = -3 and ulk.tablename = ''Employee''

update sc
set  sc.RequestId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempScheduleTR sc with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Schedule Fsc on sc.Scheduleid = Fsc.Scheduleid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fsc.RequestId = ulk.oldid
where
	sc.RequestId = -3 and ulk.tablename = ''Request''


	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Schedule'',
        	''ScheduleID'',
        	Scheduleid,
        	NewScheduleID
        From
           	dbo.TempScheduleTR

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  --,@FromTable =''tempTRScheduleTR''
  ,@FromTable =''tempScheduleTR''
  ,@ToTable =''Schedule''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.Schedule
    --     (
    --         ScheduleId,
    --         EquipmentId,
    --         EmployeeIdAssigned,
    --         RequestId,
    --         Priority,
    --         Period,
    --         PeriodType,
    --         ScheduleType,
    --         TimeOfDay,
    --         DateStart,
    --         DateEnd,
    --         CheckMissingValues,
    --         IsActiveSchedule,
    --         IsMonthlyByDay,
    --         DayOfMonth,
    --         DispatchTimeOfDay,
    --         WeekOfMonth,
    --         DayOfWeek,
    --         SeasonStart,
    --         SeasonEnd,
    --         ScheduleDescription,
    --         WoDescription,
    --         ScheduleDetail,
    --         DispatchDays,
    --         DispatchHours,
    --         tmpScheduleId
	-- 		,schedule_cs_companyid

    --     )
    -- SELECT
    --         NEWScheduleId          ,
    --         EquipmentId         ,
    --         EmployeeIdAssigned  ,
    --         RequestID,
    --         Priority,
    --         Period,
    --         PeriodType,
    --         ScheduleType,
    --         TimeOfDay,
    --         DateStart,
    --         DateEnd,
    --         CheckMissingValues,
    --         IsActiveSchedule,
    --         IsMonthlyByDay,
    --         DayOfMonth,
    --         DispatchTimeOfDay,
    --         WeekOfMonth,
    --         DayOfWeek,
    --         SeasonStart,
    --         SeasonEnd,
    --         ScheduleDescription,
    --         WoDescription,
    --         ScheduleDetail,
    --         DispatchDays,
    --         DispatchHours,
    --         -1
	-- 		,'+@ToCompany+' as  cs_companyid
    -- From
    --     dbo.TempScheduleTR

        PRINT 'Insert Workorder TR';
        SET @sql = '
Select next value for seq_Document over (order by wo.WorkorderId) as newworkorderid, wo.*
into dbo.TempTRWO
from '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo  inner join temprequest r  on wo.requestid = r.requestid
where wo.wotype = ''TR''


update trwo
set
    trwo.buildingid = k.newbuildingid
from
    temptrwo trwo with (nolock) inner join tempbuilding k with (nolock)
on
    trwo.buildingid = k.buildingid

update trwo
set
    trwo.AreaId = k.newAreaId
from
    temptrwo trwo with (nolock) inner join temparea k with (nolock)
on
    trwo.AreaId = k.AreaId

update trwo
set
    trwo.Tradeid = k.[newId]
from
    temptrwo trwo with (nolock) inner join Mapping k with (nolock)
on
    trwo.Tradeid = k.Fromid
where
    k.tablename = ''Trade''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update trwo
set
    trwo.RequestTypeId = k.[newId]
from
    temptrwo trwo with (nolock) inner join Mapping k with (nolock)
on
    trwo.RequestTypeId = k.Fromid
where
    k.tablename = ''RT''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update trwo
set
    trwo.RequestId = k.newRequestId
from
    temptrwo trwo with (nolock) inner join temprequest k with (nolock)
on
    trwo.RequestId = k.RequestId

update trwo
set
    trwo.TenantId = k.newTenantId
from
    temptrwo trwo with (nolock) inner join tempTenant k with (nolock)
on
    trwo.TenantId = k.TenantId

update trwo
set
    trwo.ContactId = k.newContactId
from
    temptrwo trwo with (nolock) inner join tempContact k with (nolock)
on
    trwo.ContactId = k.ContactId

update trwo
set
    trwo.LeaseId = k.newLeaseId
from
    temptrwo trwo with (nolock) inner join tempLease k with (nolock)
on
    trwo.LeaseId = k.LeaseId

update trwo
set
    trwo.AddressId = k.newAddressId
from
    temptrwo trwo with (nolock) inner join tempAddress k with (nolock)
on
    trwo.AddressId = k.AddressId

update trwo
set
    trwo.EmployeeIdAssigned = k.newEmployeeId
from
    temptrwo trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdAssigned = k.EmployeeId

update trwo
set
    trwo.EmployeeIdOwner = k.newEmployeeId
from
    temptrwo trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdOwner = k.EmployeeId

update trwo
set
    trwo.EmployeeIdRequested = k.newEmployeeId
from
    temptrwo trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdRequested = k.EmployeeId

update trwo
set
    trwo.EmployeeIdCreated = k.newEmployeeId
from
    temptrwo trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdCreated = k.EmployeeId

update trwo
set
    trwo.EmployeeIdUpdated = k.newEmployeeId
from
    temptrwo trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdUpdated = k.EmployeeId

update trwo
set
    trwo.ReservationId = k.newReservationId
from
    temptrwo trwo with (nolock) inner join tempReservation k with (nolock)
on
    trwo.ReservationId = k.ReservationId

update trwo
set
    trwo.ResourceId = k.newResourceId
from
    temptrwo trwo with (nolock) inner join tempResource k with (nolock)
on
    trwo.ResourceId = k.ResourceId
';
        EXEC (@sql);
 SET @sql = '
update TempTRWO set BuildingId = -3,  AreaId = -3, TradeId = -3, RequestTypeId = -3, RequestId = -3, TenantId = -3, ContactId = -3, LeaseId = -3, EmployeeIdAssigned = -3, EmployeeIdOwner = -3, EmployeeIdRequested = -3, ReservationId = case when ReservationId is null then ReservationId else -3 end, ResourceId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3, ScheduleID = Case when ScheduleID is null then ScheduleID else -3 end, EstimateID = case when EstimateID is null then EstimateID else -3 end,EmployeeIdDispatched = -3


Update TempTRWO
set ReservationAmenityId = -3
where ReservationAmenityId is not null and ReservationAmenityId <> 0 

update TempTRWO
set BulletinId  = -3
where BulletinId  is not null and BulletinId  <> 0


update trwo
set trwo.ReservationAmenityId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ReservationAmenityId = ulk.oldid
where
	trwo.ReservationAmenityId = -3 and ulk.tablename = ''ReservationAmenity'' and trwo.wotype = ''TR''

update trwo
set trwo.Scheduleid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.Scheduleid = ulk.oldid
where
	trwo.Scheduleid = -3 and ulk.tablename = ''Schedule'' and trwo.wotype = ''TR''


update trwo
set trwo.buildingid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.buildingid = ulk.oldid
where
	trwo.buildingid = -3 and ulk.tablename = ''building'' and trwo.wotype = ''TR''

update trwo
set trwo.AreaId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.AreaId = ulk.oldid
where
	trwo.AreaId = -3 and ulk.tablename = ''Area'' and trwo.wotype = ''TR''

update trwo
set trwo.TradeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.TradeId = ulk.oldid
where
	trwo.TradeId = -3 and ulk.tablename = ''Trade'' and trwo.wotype = ''TR''

update trwo
set trwo.RequestTypeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.RequestTypeId = ulk.oldid
where
	trwo.RequestTypeId = -3 and ulk.tablename = ''RequestType'' and trwo.wotype = ''TR''

update trwo
set trwo.RequestId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.RequestId = ulk.oldid
where
	trwo.RequestId = -3 and ulk.tablename = ''Request'' and trwo.wotype = ''TR''

update trwo
set trwo.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.TenantId = ulk.oldid
where
	trwo.TenantId = -3 and ulk.tablename = ''Tenant'' and trwo.wotype = ''TR''

update trwo
set trwo.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ContactId = ulk.oldid
where
	trwo.ContactId = -3 and ulk.tablename = ''Contact'' and trwo.wotype = ''TR''

update trwo
set trwo.LeaseId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.LeaseId = ulk.oldid
where
	trwo.LeaseId = -3 and ulk.tablename = ''Lease'' and trwo.wotype = ''TR''



update trwo
set trwo.BulletinID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.BulletinID = ulk.oldid
where
	trwo.BulletinID = -3 and ulk.tablename = ''Bulletin'' and trwo.wotype = ''TR''
';
        EXEC (@sql);

        SET @sql = '
    update trwo
    set trwo.tenantid = temprequest.tenantid,
        trwo.contactid = temprequest.contactid
    from
   '+@ToDB+'.dbo.TempTRWO trwo
        inner join temprequest
    on
        trwo.requestid = temprequest.newrequestid
    where
        trwo.tenantid = -3 or trwo.contactid = -3
';
        EXEC (@sql);

        set @sql = '


update trwo
set trwo.EmployeeIdDispatched = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdDispatched = ulk.oldid
where
	trwo.EmployeeIdDispatched = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''

UPDATE 	tempTRWO SET employeeiddispatched = 0 WHERE employeeiddispatched = -3

update trwo
set trwo.EmployeeIdAssigned = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdAssigned = ulk.oldid
where
	trwo.EmployeeIdAssigned = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''


UPDATE 	tempTRWO SET EmployeeIdAssigned = 0 WHERE EmployeeIdAssigned = -3

update trwo
set trwo.EmployeeIdOwner = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdOwner = ulk.oldid
where
	trwo.EmployeeIdOwner = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''

UPDATE 	tempTRWO SET EmployeeIdOwner = 0 WHERE EmployeeIdOwner = -3

update trwo
set trwo.EmployeeIdRequested = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdRequested = ulk.oldid
where
	trwo.EmployeeIdRequested = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''

UPDATE 	tempTRWO SET EmployeeIdRequested = 0 WHERE EmployeeIdRequested = -3

update trwo
set trwo.ReservationId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ReservationId = ulk.oldid
where
	trwo.ReservationId = -3 and ulk.tablename = ''Reservation'' and trwo.wotype = ''TR''

update trwo
set trwo.ResourceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ResourceId = ulk.oldid
where
	trwo.ResourceId = -3 and ulk.tablename = ''Resource'' -- and trwo.wotype = ''TR''

update trwo
set trwo.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdCreated = ulk.oldid
where
	trwo.EmployeeIdCreated = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''
UPDATE 	tempTRWO SET EmployeeIdCreated = 0 WHERE EmployeeIdCreated = -3

update trwo
set trwo.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdUpdated = ulk.oldid
where
	trwo.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''
UPDATE 	tempTRWO SET EmployeeIdUpdated = 0 WHERE EmployeeIdUpdated = -3

update trwo
set trwo.EstimateID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWO trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EstimateID = ulk.oldid
where
	trwo.EstimateID = -3 and ulk.tablename = ''Estimate'' and trwo.wotype = ''TR''
';
        EXEC (@sql);

		-- Need to change June, 10, 2022 & July,21,2022
		If @DoPM = 0 
		begin
			--SET @sql = 'Delete from '+@ToDB+'.dbo.TempTRWO where Equipmentid > 0' 
			SET @sql = 'Update '+@ToDB+'.dbo.TempTRWO 
			Set EquipmentID=0, EquipmentDescription='''', EquipmentMake='''', EquipmentModel='''', 
			EquipmentSN='''', EquipmentAssetCode='''', EquipmentDetail='''', DateWarrantyExpires=''''
			where Equipmentid > 0' 
			exec (@sql) 
		end
		-- If @DoPM = 1	
		--The issue is we do not have Equipmentid at this moment, so update TRWOs will happened after Insert Equipment in @DoPM


        SET @sql = '
		
if exists(select * from temptrwo where TenantId not in (select TenantId from Tenant))
	Update temptrwo set TenantId=0 where TenantId not in (select TenantId from Tenant)

if exists(select * from temptrwo where Contactid not in (select contactid from Contact))  
	Update temptrwo set contactid=0 where Contactid not in (select contactid from Contact)
-----------------------------------------

if exists (select * from temptrwo) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Workorder'',
        	''WorkorderId'',
        	WorkorderId,
        	newWorkorderId
        From
           	dbo.TempTRWO

INSERT INTO dbo.ArsWorkOrder (
		WorkOrderKey
		, workOrderId
		, db
		, dateUpdatedArs
		,ArsWorkOrder_cs_companyid
	)
	SELECT
		next value for seq_ARSWorkorder
		,newWorkorderId
		, db = DB_NAME()
		, GETDATE()
		,'+@ToCompany+' as cs_companyid
	FROM  dbo.TempTRWO

Update TempTRWO
set areaid = (Select top 1 newAreaid from tempArea)
 where areaid not in (select areaid from area) and areaid is not null
 
Update TempTRWO
set buildingid = (Select top 1 newBuildingId from tempBuilding)
 where buildingid not in (select buildingid from Building) and buildingid is not null

--- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempTRWO''
  ,@ToTable =''Workorder''
  ,@CompanyId = '+@ToCompany+'
 
End
';
        EXEC (@sql);
--Select
--        newWorkOrderId, workorderid, EstimateId
--    From
--        dbo.TempTRWO where EstimateId not in (select EstimateId from estimate) and Estimateid is not null

--Select
--        newWorkOrderId, workorderid, leaseid
--    From
--        dbo.TempTRWO where Leaseid not in (select leaseid from Lease) and LeaseID is not null

--Select
--        newWorkOrderId, workorderid, buildingid
--    From
--        dbo.TempTRWO where buildingid not in (select buildingid from building) and buildingid is not null


--Select
--        newWorkOrderId, workorderid, areaid
--    From
--        dbo.TempTRWO where areaid not in (select areaid from area) and areaid is not null

 
   -- insert '+@ToDB+'.dbo.Workorder
   --  (
   --      WorkOrderId	,
   --      DisplayId,
   --      SortId,
   --      DateWarrantyExpires,
   --      --EquipmentClassDescription_fr,

   --      BuildingId,
   --      WoType,
   --      WoStatus,
   --      AreaId,
   --      RequestId,
   --      ReservationId,
   --      EquipmentId,
   --      ScheduleId,
   --      TenantId,
   --      ContactId,
   --      LeaseId,
   --      EmployeeIdAssigned,
   --      EmployeeIdOwner,
   --      EmployeeIdRequested,
   --      RequestTypeId,
   --      TradeId,
   --      ResourceId,
   --      EstimateId,
   --      AddressId,
   --      DispatchHours,
   --      WoSequence,
   --      Priority,
   --      Todo,
   --      WoHistoryEvent,
   --      TimeResponse,
   --      TimeCompletion,
   --      TimeOverdue,
   --      EstimateStatus,
   --      InactiveLease,
   --      MissingLease,
   --      SnoozeLength,
   --      SnoozeUnit,
   --      --WoStatusDescription,
   --      WoDescription,
   --      DateScheduled,
   --      DateExpiry,
   --      DateReceived,
   --      DateOpened,
   --      DateAssigned,
   --      DateToDispatch,
   --      DateDispatched,
   --      DateDeliveryConfirmed,
   --      DateResponded,
   --      DateAccepted,
   --      DateWorkStarted,
   --      DateWorkCompleted,
   --      DateClosed,
   --      DateCancelled,
   --      DateVerified,
   --      DateReversed,
   --      DateToEscalate1,
   --      DateToEscalate2,
   --      DateToEscalate3,
   --      DateEscalated1,
   --      DateEscalated2,
   --      DateEscalated3,
   --      DateSnoozeUntil,
   --      IsWithMessages,
   --      IsCallAttention,
   --      IsAutoCancelled,
   --      IsMissingValues,
   --      IsRequestWithMessages,
   --      IsEscalated,
   --      IsPendingInvoice,
   --      IsProcessed,
   --      IsReviewRequired,
   --      IsEstimateRequired,
   --      ExternalAddressCode,
   --      ExternalAltAddressCode,
   --      --EquipmentClassDescription,
   --      EquipmentDescription,
   --      EquipmentMake,
   --      EquipmentModel,
   --      EquipmentSN,
   --      EquipmentAssetCode,
   --      EquipmentDetail,
   --      CustomerReferenceNumber,
   --      SecondaryContactName,
   --      SecondaryContactInfo,
   --      LocationNotes,
   --      LocationType,
   --      WorkOrderCustom1,
   --      WorkOrderCustom2,
   --      WorkOrderCustom3,
   --      WorkOrderCustom4,
   --      WorkOrderCustom5,
   --      CostAsset,
   --      WoDetail,
   --      EmployeeIdCreated,
   --      DateCreated,
   --      EmployeeIdUpdated,
   --      DateUpdated,
   --      tmpWorkOrderId,
   --      EmployeeIdDispatched,
   --      UnableToDispatch,
   --      TimeAcceptance  ,
   --      RequestSource ,
	  --  CompleteVersion ,
	  --  [IsImpairment]  ,
	  --  [Reason]  ,
	  --  [Tag]   ,
	  --  [ConfirmImpairmentOnline]   ,
	  --  QRSRating,
	 	--QRSComment,
	 	--BulletinID,
	 	--RatingSource,
	 	--workorder_cs_companyid,
	 	--ReservationAmenityId,
	 	--DateScheduledKey

   --  )
   --  Select
   --      newWorkOrderId,
   --      DisplayId,
   --      SortId,
   --      DateWarrantyExpires,
   --      --EquipmentClassDescription_fr,

   --      BuildingId,
   --      WoType,
   --      WoStatus,
   --      AreaId,
   --      RequestId,
   --      ReservationId,
   --      0 as EquipmentId, -- need to backfill equipmentid after equipment info is processed
   --      ScheduleId,
   --      TenantId,
   --      ContactId,
   --      LeaseId,
   --      EmployeeIdAssigned,
   --      EmployeeIdOwner,
   --      EmployeeIdRequested,
   --      RequestTypeId,
   --      TradeId,
   --      ResourceId,
   --      EstimateId,
   --      AddressId,
   --      DispatchHours,
   --      WoSequence,
   --      Priority,
   --      Todo,
   --      WoHistoryEvent,
   --      TimeResponse,
   --      TimeCompletion,
   --      TimeOverdue,
   --      EstimateStatus,
   --      InactiveLease,
   --      MissingLease,
   --      SnoozeLength,
   --      SnoozeUnit,
   --      --WoStatusDescription,
   --      WoDescription,
   --      DateScheduled,
   --      DateExpiry,
   --      DateReceived,
   --      DateOpened,
   --      DateAssigned,
   --      DateToDispatch,
   --      DateDispatched,
   --      DateDeliveryConfirmed,
   --      DateResponded,
   --      DateAccepted,
   --      DateWorkStarted,
   --      DateWorkCompleted,
   --      DateClosed,
   --      DateCancelled,
   --      DateVerified,
   --      DateReversed,
   --      DateToEscalate1,
   --      DateToEscalate2,
   --      DateToEscalate3,
   --      DateEscalated1,
   --      DateEscalated2,
   --      DateEscalated3,
   --      DateSnoozeUntil,
   --      IsWithMessages,
   --      IsCallAttention,
   --      IsAutoCancelled,
   --      IsMissingValues,
   --      IsRequestWithMessages,
   --      IsEscalated,
   --      IsPendingInvoice,
   --      IsProcessed,
   --      IsReviewRequired,
   --      IsEstimateRequired,
   --      ExternalAddressCode,
   --      ExternalAltAddressCode,
   --      --EquipmentClassDescription,
   --      EquipmentDescription,
   --      EquipmentMake,
   --      EquipmentModel,
   --      EquipmentSN,
   --      EquipmentAssetCode,
   --      EquipmentDetail,
   --      CustomerReferenceNumber,
   --      SecondaryContactName,
   --      SecondaryContactInfo,
   --      LocationNotes,
   --      LocationType,
   --      WorkOrderCustom1,
   --      WorkOrderCustom2,
   --      WorkOrderCustom3,
   --      WorkOrderCustom4,
   --      WorkOrderCustom5,
   --      CostAsset,
   --      WoDetail,
   --      EmployeeIdCreated,
   --      DateCreated,
   --      EmployeeIdUpdated,
   --      DateUpdated,
   --      -1 ,
   --      EmployeeIdDispatched,
   --      UnableToDispatch,
   --      TimeAcceptance  ,
   --      RequestSource ,
	  --  CompleteVersion,
	  --  [IsImpairment]  ,
	  --  [Reason]  ,
	  --  [Tag]   ,
	  --  [ConfirmImpairmentOnline]   ,
	  --  QRSRating,
	 	--QRSComment,
	 	--BulletinID,
	 	--RatingSource,
	 	--'+@ToCompany+' as cs_companyid,
	 	--ReservationAmenityId,
	 	--DateScheduledKey
   --  From
   --      dbo.TempTRWO


        PRINT 'Insert Reservation Workorder ';
        SET @sql = '
Select next value for seq_Document over (order by wo.WorkorderId) as newworkorderid, wo.*
into dbo.TempTRWORes
from '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo  inner join tempReservation r  on wo.Reservationid = r.Reservationid
where wo.wotype = ''TR''
--order by wo.workorderId

update trwo
set
    trwo.buildingid = k.newbuildingid
from
    TempTRWORes trwo with (nolock) inner join tempbuilding k with (nolock)
on
    trwo.buildingid = k.buildingid

update trwo
set
    trwo.AreaId = k.newAreaId
from
    TempTRWORes trwo with (nolock) inner join temparea k with (nolock)
on
    trwo.AreaId = k.AreaId

update trwo
set
    trwo.Tradeid = k.[newId]
from
    TempTRWORes trwo with (nolock) inner join Mapping k with (nolock)
on
    trwo.Tradeid = k.Fromid
where
    k.tablename = ''Trade''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update trwo
set
    trwo.RequestTypeId = k.[newId]
from
    TempTRWORes trwo with (nolock) inner join Mapping k with (nolock)
on
    trwo.RequestTypeId = k.Fromid
where
    k.tablename = ''RT''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'



update trwo
set
    trwo.TenantId = k.newTenantId
from
    TempTRWORes trwo with (nolock) inner join tempTenant k with (nolock)
on
    trwo.TenantId = k.TenantId

update trwo
set
    trwo.ContactId = k.newContactId
from
    TempTRWORes trwo with (nolock) inner join tempContact k with (nolock)
on
    trwo.ContactId = k.ContactId

update trwo
set
    trwo.LeaseId = k.newLeaseId
from
    TempTRWORes trwo with (nolock) inner join tempLease k with (nolock)
on
    trwo.LeaseId = k.LeaseId

update trwo
set
    trwo.AddressId = k.newAddressId
from
    TempTRWORes trwo with (nolock) inner join tempAddress k with (nolock)
on
    trwo.AddressId = k.AddressId

update trwo
set
    trwo.EmployeeIdAssigned = k.newEmployeeId
from
    TempTRWORes trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdAssigned = k.EmployeeId

update trwo
set
    trwo.EmployeeIdOwner = k.newEmployeeId
from
    TempTRWORes trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdOwner = k.EmployeeId

update trwo
set
    trwo.EmployeeIdRequested = k.newEmployeeId
from
    TempTRWORes trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdRequested = k.EmployeeId

update trwo
set
    trwo.EmployeeIdCreated = k.newEmployeeId
from
    TempTRWORes trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdCreated = k.EmployeeId

update trwo
set
    trwo.EmployeeIdUpdated = k.newEmployeeId
from
    TempTRWORes trwo with (nolock) inner join tempce k with (nolock)
on
    trwo.EmployeeIdUpdated = k.EmployeeId

update trwo
set
    trwo.ReservationId = k.newReservationId
from
    TempTRWORes trwo with (nolock) inner join tempReservation k with (nolock)
on
    trwo.ReservationId = k.ReservationId

update trwo
set
    trwo.ResourceId = k.newResourceId
from
    TempTRWORes trwo with (nolock) inner join tempResource k with (nolock)
on
    trwo.ResourceId = k.ResourceId
';
        EXEC (@sql);
        SET @sql = '
update TempTRWORes set BuildingId = -3, AreaId = -3, TradeId = -3, RequestTypeId = -3, TenantId = -3, ContactId = -3, LeaseId = -3, EmployeeIdAssigned = -3, EmployeeIdOwner = -3, EmployeeIdRequested = -3, ReservationId = case when ReservationId is null then ReservationId else -3 end, ResourceId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3
update trwo
set trwo.buildingid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.buildingid = ulk.oldid
where
	trwo.buildingid = -3 and ulk.tablename = ''building'' and trwo.wotype = ''TR''

update trwo
set trwo.AreaId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.AreaId = ulk.oldid
where
	trwo.AreaId = -3 and ulk.tablename = ''Area'' and trwo.wotype = ''TR''

update trwo
set trwo.TradeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.TradeId = ulk.oldid
where
	trwo.TradeId = -3 and ulk.tablename = ''Trade'' and trwo.wotype = ''TR''

update trwo
set trwo.RequestTypeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.RequestTypeId = ulk.oldid
where
	trwo.RequestTypeId = -3 and ulk.tablename = ''RequestType'' and trwo.wotype = ''TR''


update trwo
set trwo.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.TenantId = ulk.oldid
where
	trwo.TenantId = -3 and ulk.tablename = ''Tenant'' and trwo.wotype = ''TR''

update trwo
set trwo.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ContactId = ulk.oldid
where
	trwo.ContactId = -3 and ulk.tablename = ''Contact'' and trwo.wotype = ''TR''

update trwo
set trwo.LeaseId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.LeaseId = ulk.oldid
where
	trwo.LeaseId = -3 and ulk.tablename = ''Lease'' and trwo.wotype = ''TR''
';
        EXEC (@sql);
        SET @sql = '
    update trwo
    set trwo.tenantid = temprequest.tenantid,
        trwo.contactid = temprequest.contactid
    from
   '+@ToDB+'.dbo.TempTRWORes trwo
        inner join temprequest
    on
        trwo.requestid = temprequest.newrequestid
    where
        trwo.tenantid = -3 or trwo.contactid = -3
';
        EXEC (@sql);
        SET @sql = '
update trwo
set trwo.EmployeeIdAssigned = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdAssigned = ulk.oldid
where
	trwo.EmployeeIdAssigned = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''

update trwo
set trwo.EmployeeIdOwner = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdOwner = ulk.oldid
where
	trwo.EmployeeIdOwner = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''

update trwo
set trwo.EmployeeIdRequested = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdRequested = ulk.oldid
where
	trwo.EmployeeIdRequested = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''

update trwo
set trwo.ReservationId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ReservationId = ulk.oldid
where
	trwo.ReservationId = -3 and ulk.tablename = ''Reservation'' and trwo.wotype = ''TR''

update trwo
set trwo.ResourceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ResourceId = ulk.oldid
where
	trwo.ResourceId = -3 and ulk.tablename = ''Resource'' -- and trwo.wotype = ''TR''

update trwo
set trwo.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdCreated = ulk.oldid
where
	trwo.EmployeeIdCreated = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''

update trwo
set trwo.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempTRWORes trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Ftrwo on trwo.WorkorderId = Ftrwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdUpdated = ulk.oldid
where
	trwo.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee'' and trwo.wotype = ''TR''
';
        EXEC (@sql);

        SET @sql = '
if exists (select * from TempTRWORes) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Workorder'',
        	''WorkorderId'',
        	WorkorderId,
        	newWorkorderId
        From
           	dbo.TempTRWORes


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempTRWORes''
  ,@ToTable =''Workorder''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Workorder
    -- (
    --     WorkOrderId	,
    --     BuildingId	,
    --     WoType	,
    --     WoStatus	,
    --     AreaId	,
    --     RequestTypeId	,
    --     EquipmentId	,
    --     ScheduleId	,
    --     RequestId	,
    --     ReservationId	,
    --     ResourceId	,
    --     TenantId	,
    --     ContactId	,
    --     TradeId	,
    --     LeaseId	,
    --     AddressId	,
    --     EmployeeIdAssigned	,
    --     EmployeeIdOwner	,
    --     EmployeeIdRequested	,
    --     WoSequence	,
    --     DispatchHours	,
    --     Priority	,
    --     Todo	,
    --     --WoStatusDescription	,
    --     WoDescription	,
    --     WoHistoryEvent	,
    --     WoDetail	,
    --     ExternalAddressCode	,
    --     ExternalAltAddressCode	,
    --     DateScheduled	,
    --     DateExpiry	,
    --     DateReceived	,
    --     DateOpened	,
    --     DateAssigned	,
    --     DateToDispatch	,
    --     DateDispatched	,
    --     DateDeliveryConfirmed	,
    --     DateResponded	,
    --     DateAccepted	,
    --     DateWorkStarted	,
    --     DateWorkCompleted	,
    --     dateclosed, --DateCompleted	,
    --     DateCancelled	,
    --     DateVerified	,
    --     DateReversed	,
    --     DateToEscalate1	,
    --     DateToEscalate2	,
    --     DateToEscalate3	,
    --     DateEscalated1	,
    --     DateEscalated2	,
    --     DateEscalated3	,
    --     TimeResponse	,
    --     TimeCompletion	,
    --     TimeOverdue	,
    --     IsWithMessages	,
    --     IsCallAttention	,
    --     IsAutoCancelled	,
    --     IsMissingValues	,
    --     IsRequestWithMessages	,
    --     IsEscalated	,
    --     IsPendingInvoice	,
    --     IsProcessed	,
    --     IsReviewRequired	,
    --     --EquipmentClassDescription	,
    --     EquipmentDescription	,
    --     EquipmentMake	,
    --     EquipmentModel	,
    --     EquipmentSN	,
    --     EquipmentAssetCode	,
    --     EquipmentDetail	,
    --     CustomerReferenceNumber	,
    --     SecondaryContactName	,
    --     SecondaryContactInfo	,
    --     LocationNotes	,
    --     LocationType	,
    --     WorkOrderCustom1	,
    --     WorkOrderCustom2	,
    --     WorkOrderCustom3	,
    --     WorkOrderCustom4	,
    --     WorkOrderCustom5	,
    --     CostAsset	,
    --     EmployeeIdCreated	,
    --     DateCreated	,
    --     EmployeeIdUpdated	,
    --     DateUpdated	,
    --     tmpWorkOrderId
	-- 	,workorder_cs_companyid

    -- )
    -- Select
    --     NewWorkOrderId	,
    --     BuildingId	,
    --     WoType	,
    --     WoStatus	,
    --     AreaId	,
    --     RequestTypeId	,
    --     EquipmentId	,
    --     ScheduleId	,
    --     RequestId	,
    --     ReservationId	,
    --     ResourceId	,
    --     TenantId	,
    --     ContactId	,
    --     TradeId	,
    --     LeaseId	,
    --     AddressId	,
    --     EmployeeIdAssigned	,
    --     EmployeeIdOwner	,
    --     EmployeeIdRequested	,
    --     WoSequence	,
    --     DispatchHours	,
    --     Priority	,
    --     Todo	,
    --     --WoStatusDescription	,
    --     WoDescription	,
    --     WoHistoryEvent	,
    --     WoDetail	,
    --     ExternalAddressCode	,
    --     ExternalAltAddressCode	,
    --     DateScheduled	,
    --     DateExpiry	,
    --     DateReceived	,
    --     DateOpened	,
    --     DateAssigned	,
    --     DateToDispatch	,
    --     DateDispatched	,
    --     DateDeliveryConfirmed	,
    --     DateResponded	,
    --     DateAccepted	,
    --     DateWorkStarted	,
    --     DateWorkCompleted	,
    --     dateclosed, --DateCompleted	,
    --     DateCancelled	,
    --     DateVerified	,
    --     DateReversed	,
    --     DateToEscalate1	,
    --     DateToEscalate2	,
    --     DateToEscalate3	,
    --     DateEscalated1	,
    --     DateEscalated2	,
    --     DateEscalated3	,
    --     TimeResponse	,
    --     TimeCompletion	,
    --     TimeOverdue	,
    --     IsWithMessages	,
    --     IsCallAttention	,
    --     IsAutoCancelled	,
    --     IsMissingValues	,
    --     IsRequestWithMessages	,
    --     IsEscalated	,
    --     IsPendingInvoice	,
    --     IsProcessed	,
    --     IsReviewRequired	,
    --     --EquipmentClassDescription	,
    --     EquipmentDescription	,
    --     EquipmentMake	,
    --     EquipmentModel	,
    --     EquipmentSN	,
    --     EquipmentAssetCode	,
    --     EquipmentDetail	,
    --     CustomerReferenceNumber	,
    --     SecondaryContactName	,
    --     SecondaryContactInfo	,
    --     LocationNotes	,
    --     LocationType	,
    --     WorkOrderCustom1	,
    --     WorkOrderCustom2	,
    --     WorkOrderCustom3	,
    --     WorkOrderCustom4	,
    --     WorkOrderCustom5	,
    --     CostAsset	,
    --     EmployeeIdCreated	,
    --     DateCreated	,
    --     EmployeeIdUpdated	,
    --     DateUpdated	,
    --     -1
	-- 	,'+@ToCompany+' as cs_companyid

    -- From
    --     dbo.TempTRWORes

        PRINT 'Insert WoHistory TR';
        SET @sql = '
Select next value for seq_WoHistory over (order by woh.WoHistoryId) as newwohistoryId, woh.*
into dbo.temptrwoh
from
    '+@Fromserver+'.'+@FromDB+'.dbo.wohistory woh  inner join temptrwo  on woh.workorderid = temptrwo.workorderid
--order by woh.WoHistoryId

update temptrwoh
set
    temptrwoh.workorderid = temptrwo.newworkorderid
from
    temptrwo with (nolock)
where
    temptrwoh.workorderid = temptrwo.workorderid

update temptrwoh
set
    temptrwoh.EmployeeId = tempce.newEmployeeId
from
    tempce with (nolock)
where
    temptrwoh.EmployeeId = tempce.EmployeeId

update temptrwoh
set
    temptrwoh.EmployeeIdCreated = tempce.newEmployeeId
from
    tempce with (nolock)
where
    temptrwoh.EmployeeIdCreated = tempce.EmployeeId

update temptrwoh
set
    temptrwoh.EmployeeIdUpdated = tempce.newEmployeeId
from
    tempce with (nolock)
where
    temptrwoh.EmployeeIdUpdated = tempce.EmployeeId


update temptrwoh set WorkOrderId = -3, EmployeeId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3, WoTaskId = case when WoTaskId is null then WoTaskId else -3 end
update woh
set  woh.WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.WorkOrderId = ulk.oldid
where
	woh.WorkOrderId = -3 and ulk.tablename = ''WorkOrder''

update woh
set  woh.EmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeId = ulk.oldid
where
	woh.EmployeeId = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdCreated = ulk.oldid
where
	woh.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdUpdated = ulk.oldid
where
	woh.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

update woh
set  woh.WoTaskId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.WoTaskId = ulk.oldid
where
	woh.WoTaskId = -3 and ulk.tablename = ''WoTask''


Update temptrwoh
set EmployeeIdCreated = 0
where EmployeeIdCreated not in (select employeeid from employee)


Update temptrwoh
set EmployeeIdUpdated = 0
where EmployeeIdUpdated not in (select employeeid from employee)


Update temptrwoh
set EmployeeId = 0
where EmployeeId not in (select employeeid from employee)



	If exists (select * from temptrwoh) Begin


	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''WoHistory'',
        	''WoHistoryId'',
        	WoHistoryId,
        	newWoHistoryId
        From
           	dbo.temptrwoh

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''temptrwoh''
  ,@ToTable =''WoHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.WoHistory
    -- (
    --  [WoHistoryId]
    -- ,[WorkOrderId]
    -- ,[WoTaskId]
    -- ,[EmployeeId]
    -- ,[MinutesWorked]
    -- ,[WoHistoryDate]
    -- ,[WoHistoryEvent]
    -- ,[WoHistoryStatus]
    -- ,[WoHistoryDetail]
    -- ,[EmployeeIdCreated]
    -- ,[DateCreated]
    -- ,[EmployeeIdUpdated]
    -- ,[DateUpdated]
    -- ,[tmpWoHistoryID]
    -- ,[DateUpdatedUtc]
    -- ,[DateCreatedUtc]
    -- ,[ApprovalLevel]
    -- ,[BillableTotal]
    -- ,[NonBillableTotal]
	-- ,WoHistory_cs_companyid
    -- )

    -- Select
    --  [NewWoHistoryId]
    -- ,[WorkOrderId]
    -- ,[WoTaskId]
    -- ,[EmployeeId]
    -- ,[MinutesWorked]
    -- ,[WoHistoryDate]
    -- ,[WoHistoryEvent]
    -- ,[WoHistoryStatus]
    -- ,[WoHistoryDetail]
    -- ,[EmployeeIdCreated]
    -- ,[DateCreated]
    -- ,[EmployeeIdUpdated]
    -- ,[DateUpdated]
    -- ,[tmpWoHistoryID]
    -- ,[DateUpdatedUtc]
    -- ,[DateCreatedUtc]
    -- ,[ApprovalLevel]
    -- ,[BillableTotal]
    -- ,[NonBillableTotal]
	-- ,'+@ToCompany+' as cs_companyid
    -- From
    --     dbo.temptrwoh

        PRINT 'Insert WoHistoryDetail TR';
        SET @sql = '
Select next value for seq_WoHistoryDetail over (order by wohdetail.WoHistoryDetailId) as newWoHistoryDetailId, wohdetail.*
into dbo.temptrwohDetail
from
    '+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail wohdetail  inner join temptrwoh  on wohdetail.woHistoryID = temptrwoh.woHistoryID
--order by wohdetail.WoHistoryDetailId

update temptrwohDetail set woHistoryID = -3, WoHistoryDetailEmployeeId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3

update woh
set  woh.woHistoryID = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohDetail woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail Fwoh on woh.WoHistoryDetailId = Fwoh.WoHistoryDetailId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.woHistoryID = ulk.oldid
where
	woh.woHistoryID = -3 and ulk.tablename = ''WoHistory''

update woh
set  woh.WoHistoryDetailEmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohDetail woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail Fwoh on woh.WoHistoryDetailId = Fwoh.WoHistoryDetailId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.WoHistoryDetailEmployeeId = ulk.oldid
where
	woh.WoHistoryDetailEmployeeId = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohDetail woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail Fwoh on woh.WoHistoryDetailId = Fwoh.WoHistoryDetailId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdCreated = ulk.oldid
where
	woh.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohDetail woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail Fwoh on woh.WoHistoryDetailId = Fwoh.WoHistoryDetailId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdUpdated = ulk.oldid
where
	woh.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''
-------?????
select * from temptrwohDetail where WoHistoryDetailEmployeeId=-3 or EmployeeIdCreated=-3 or EmployeeIdUpdated=-3
Update temptrwohDetail set WoHistoryDetailEmployeeId=0 where WoHistoryDetailEmployeeId=-3
Update temptrwohDetail set EmployeeIdCreated=0 where EmployeeIdCreated=-3
Update temptrwohDetail set EmployeeIdUpdated=0 where EmployeeIdUpdated=-3
------------
	If exists (select * from temptrwohDetail) Begin
	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''WoHistoryDetail'',
        	''WoHistoryDetailId'',
        	WoHistoryDetailId,
        	newWoHistoryDetailId
        From
           	dbo.temptrwohDetail

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''temptrwohDetail''
  ,@ToTable =''WoHistoryDetail''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.WoHistoryDetail
    -- (

    --     [WoHistoryDetailId]
    --     ,[WoHistoryId]
    --     ,[WoHistoryDetailEvent]
    --     ,[WoHistoryDetailDate]
    --     ,[DateCreated]
    --     ,[DateUpdated]
    --     ,[WoHistoryDetailEmployeeId]
    --     ,[EmployeeIdCreated]
    --     ,[EmployeeIdUpdated]
    --     ,[Comments]
    --     ,[tmpWoHistoryDetailID]
	-- 	,WoHistoryDetail_cs_companyid
    -- )

    -- Select
    --     NewWoHistoryDetailId
    --     ,[WoHistoryId]
    --     ,[WoHistoryDetailEvent]
    --     ,[WoHistoryDetailDate]
    --     ,[DateCreated]
    --     ,[DateUpdated]
    --     ,[WoHistoryDetailEmployeeId]
    --     ,[EmployeeIdCreated]
    --     ,[EmployeeIdUpdated]
    --     ,[Comments]
    --     ,[tmpWoHistoryDetailID]
	-- 	,'+@ToCompany+' as cs_companyid
    -- From
    --     dbo.temptrwohDetail

        PRINT 'Insert WoHistory Reservation';
        SET @sql = '
Select next value for seq_WoHistory over (order by woh.WoHistoryId) as newwohistoryId, woh.*
into dbo.temptrwohres
from
    '+@Fromserver+'.'+@FromDB+'.dbo.wohistory woh  inner join  TempTRWORes on woh.workorderid = TempTRWORes.workorderid
--order by woh.WoHistoryId

update temptrwohres
set
    temptrwohres.workorderid = TempTRWORes.newworkorderid
from
    TempTRWORes with (nolock)
where
    temptrwohres.workorderid = TempTRWORes.workorderid

update temptrwohres
set
    temptrwohres.EmployeeId = tempce.newEmployeeId
from
    tempce with (nolock)
where
    temptrwohres.EmployeeId = tempce.EmployeeId

update temptrwohres
set
    temptrwohres.EmployeeIdCreated = tempce.newEmployeeId
from
    tempce with (nolock)
where
    temptrwohres.EmployeeIdCreated = tempce.EmployeeId

update temptrwohres
set
    temptrwohres.EmployeeIdUpdated = tempce.newEmployeeId
from
    tempce with (nolock)
where
    temptrwohres.EmployeeIdUpdated = tempce.EmployeeId


update temptrwohres set WorkOrderId = -3, EmployeeId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3, WoTaskId = case when WoTaskId is null then WoTaskId else -3 end
update woh
set  woh.WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohres woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.WorkOrderId = ulk.oldid
where
	woh.WorkOrderId = -3 and ulk.tablename = ''WorkOrder''

update woh
set  woh.EmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohres woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeId = ulk.oldid
where
	woh.EmployeeId = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohres woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdCreated = ulk.oldid
where
	woh.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohres woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdUpdated = ulk.oldid
where
	woh.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

update woh
set  woh.WoTaskId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrwohres woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.WoTaskId = ulk.oldid
where
	woh.WoTaskId = -3 and ulk.tablename = ''WoTask''


If exists (select * from temptrwohres) Begin


	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''WoHistory'',
        	''WoHistoryId'',
        	WoHistoryId,
        	newWoHistoryId
        From
           	dbo.temptrwohres

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''temptrwohres''
  ,@ToTable =''WoHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.WoHistory
    -- (
	-- [WoHistoryId]
    -- ,[WorkOrderId]
    -- ,[WoTaskId]
    -- ,[EmployeeId]
    -- ,[MinutesWorked]
    -- ,[WoHistoryDate]
    -- ,[WoHistoryEvent]
    -- ,[WoHistoryStatus]
    -- ,[WoHistoryDetail]
    -- ,[EmployeeIdCreated]
    -- ,[DateCreated]
    -- ,[EmployeeIdUpdated]
    -- ,[DateUpdated]
    -- ,[tmpWoHistoryID]
    -- ,[DateUpdatedUtc]
    -- ,[DateCreatedUtc]
    -- ,[ApprovalLevel]
    -- ,[BillableTotal]
    -- ,[NonBillableTotal]
	-- ,WoHistory_cs_companyid
    -- )

    -- Select
    --     [NewWoHistoryId]
    --     ,[WorkOrderId]
    --     ,[WoTaskId]
    --     ,[EmployeeId]
    --     ,[MinutesWorked]
    --     ,[WoHistoryDate]
    --     ,[WoHistoryEvent]
    --     ,[WoHistoryStatus]
    --     ,[WoHistoryDetail]
    --     ,[EmployeeIdCreated]
    --     ,[DateCreated]
    --     ,[EmployeeIdUpdated]
    --     ,[DateUpdated]
    --     ,[tmpWoHistoryID]
    --     ,[DateUpdatedUtc]
    --     ,[DateCreatedUtc]
    --     ,[ApprovalLevel]
    --     ,[BillableTotal]
    --     ,[NonBillableTotal]
	-- 	,'+@ToCompany+' as cs_companyid
    -- From
    --     dbo.temptrwohres

        PRINT 'Insert Message TR';
        SET @c1 = '
Select  NEXT VALUE for seq_Message over (order by a.MessageId) as newMessageId, a.*
into dbo.temptrmessage
from
(Select mg1.* from '+@Fromserver+'.'+@FromDB+'.dbo.message mg1  inner join temptrwo  on temptrwo.workorderid = mg1.workorderid
inner join tempproperty tp on mg1.propertyid = tp.PropertyID union

 Select mg2.* from '+@Fromserver+'.'+@FromDB+'.dbo.message mg2  inner join TempRequest  on tempRequest.Requestid = mg2.Requestid
inner join tempproperty tp2 on mg2.propertyid = tp2.PropertyID
) a

update temptrmessage
set
   -- temptrmessage.companyid = '+@ToCompany+',
    temptrmessage.Propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    temptrmessage.Propertyid = tempproperty.propertyid

update tm
set
    tm.requestid = r.newrequestid
from
    temptrmessage tm with (nolock) inner join temprequest r with (nolock)
on
    tm.requestid = r.requestid

update tm
set
    tm.WorkOrderId = r.newWorkOrderId
from
    temptrmessage tm with (nolock) inner join temptrwo r with (nolock)
on
    tm.WorkOrderId = r.WorkOrderId

update tm
set
    tm.TenantId = r.newTenantId
from
    temptrmessage tm with (nolock) inner join tempTenant r with (nolock)
on
    tm.TenantId = r.TenantId

update tm
set
    tm.ContactId = r.newContactId
from
    temptrmessage tm with (nolock) inner join tempContact r with (nolock)
on
    tm.ContactId = r.ContactId

--update tm
--set
--    tm.MessageIdParent = r.newMessageId
--from
--    temptrmessage tm with (nolock) inner join temptrMessage r with (nolock)
--on
--    tm.MessageIdParent = r.MessageId

update tm
set
    tm.EmployeeIdFrom = r.newEmployeeId
from
    temptrmessage tm with (nolock) inner join tempce r with (nolock)
on
    tm.EmployeeIdFrom = r.EmployeeId

update tm
set
    tm.EmployeeIdTo = r.newEmployeeId
from
    temptrmessage tm with (nolock) inner join tempce r with (nolock)
on
    tm.EmployeeIdTo = r.EmployeeId

if exists (select * from temptrmessage) Begin

--update temptrmessage set RequestId = case when RequestId is null then RequestId else -3 end,
--WorkOrderId = case when workOrderID is null then WorkOrderID else -3 end,
--TenantId = case when Tenantid is null then Tenantid else -3 end,
--ContactId = -3, EmployeeIdFrom = -3, EmployeeIdTo = -3

update temptrmessage set RequestId = case when RequestId is null then RequestId else -3 end,
WorkOrderId = case when workOrderID is null then WorkOrderID else -3 end,
TenantId = case when tenantid is null then tenantid else  -3 end,
ContactId = case when contactid is null then contactid else  -3 end,
EmployeeIDFrom = case when EmployeeIdFrom is null then EmployeeIDFrom else -3 end,
EmployeeIDTo = case when EmployeeIDTo is null then EmployeeIdTo Else -3 end,
EmployeeIdUpdated = case when EmployeeIdUpdated is null then EmployeeIdUpdated Else -3 end,
EmployeeIdCreated =  case when EmployeeIdCreated is null then EmployeeIdCreated Else -3 end

update temptrmessage set COIID =-3 where COIID is not null

update trm
set trm.PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.PropertyId = ulk.oldid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder fwo on ftrm.workorderid = fwo.workorderid
where
	trm.PropertyId = -3 and ulk.tablename = ''Property'' and fwo.wotype = ''TR''

';
        SET @c2 = '
update trm
set trm.RequestId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.RequestId = ulk.oldid

where
	trm.RequestId = -3 and ulk.tablename = ''Request''

update trm
set trm.WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.WorkOrderId = ulk.oldid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder fwo on ftrm.workorderid = fwo.workorderid
where
	trm.WorkOrderId = -3 and ulk.tablename = ''WorkOrder'' and fwo.wotype = ''TR''

update trm
set trm.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.TenantId = ulk.oldid

where
	trm.TenantId = -3 and ulk.tablename = ''Tenant''

update trm
set trm.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.ContactId = ulk.oldid

where
	trm.ContactId = -3 and ulk.tablename = ''Contact''

update trm
set trm.EmployeeIdFrom = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdFrom = ulk.oldid

where
	trm.EmployeeIdFrom = -3 and ulk.tablename = ''Employee''

update trm
set trm.EmployeeIdTo = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdTo = ulk.oldid

where
	trm.EmployeeIdTo = -3 and ulk.tablename = ''Employee''


update trm
set trm.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdUpdated = ulk.oldid
where
	trm.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

update trm
set trm.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptrmessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdCreated = ulk.oldid
where
	trm.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

     --Select * From  dbo.temptrmessage  where contactid not in (select newcontactid from tempcontact)  and contactid <>0
     --Select * From  dbo.temptrmessage  where contactid not in (select contactid from contact)  and contactid <> 0

	Update	dbo.temptrmessage
	set Tenantid = null
	where tenantid not in (Select tenantid from tenant)

	Update	dbo.temptrmessage
	set contactid = null
	where contactid not in (select newcontactid from tempcontact)  and contactid <>0



	Update	dbo.temptrmessage
	set [EmployeeIdFrom] = null
	where [EmployeeIdFrom] not in (select employeeid from employee)  AND
	[EmployeeIdFrom] <>0


	Update	dbo.temptrmessage
	set [EmployeeIdTo] = null
	where [EmployeeIdTo] not in (select employeeid from employee)  AND
	 [EmployeeIdTo] <>0


	Update	dbo.temptrmessage
	set [EmployeeIdCreated] = null
	where [EmployeeIdCreated] not in (select employeeid from employee)  AND
	 [EmployeeIdCreated] <>0


	 Update	dbo.temptrmessage
	set [EmployeeIdUpdated] = 0
	where [EmployeeIdUpdated] not in (select employeeid from employee)  AND
	 [EmployeeIdUpdated] <>0

-- If we copy COI, there is an update for COIID
update temptrmessage
set
	COIID = null

	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Message'',
        	''MessageId'',
        	MessageId,
        	newMessageId
        From
           	dbo.temptrmessage

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''temptrmessage''
  ,@ToTable =''Message''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@c1+@c2);

--    insert '+@ToDB+'.dbo.Message
--     (
--       [MessageId]
--     ,[DiscriminatorType]
--     ,[CoiId]
--     ,[PropertyId]
--     ,[RequestId]
--     ,[WorkOrderId]
--     ,[TenantId]
--     ,[ContactId]
--     ,[EmployeeIdFrom]
--     ,[EmployeeIdTo]
--     ,[IsMessageRead]
--     ,[MessageIdParent]
--     ,[DateSent]
--     ,[DateReceived]
--     ,[FromAddress]
--     ,[ToAddress]
--     ,[CcAddress]
--     ,[Subject]
--     ,[Body]
--     ,[tmpInboxid]
--     ,[MessageType]
--     ,[IsMessageDeleted]
--     ,[EmployeeIdCreated]
--     ,[DateCreated]
--     ,[tmpMessageID]
--    -- ,[DateCreatedUtc]
--     ,[Category]
-- 	,[ManuallyClassified]
-- 	,[EmployeeIdUpdated]
-- 	,[DateUpdated]
-- 	,Message_cs_companyid


--     )
--     Select
-- 	 [NewMessageId]
--     ,[DiscriminatorType]
--     ,[CoiId]
--     ,[PropertyId]
--     ,[RequestId]
--     ,[WorkOrderId]
--     ,[TenantId]
--     ,[ContactId]
--     ,[EmployeeIdFrom]
--     ,[EmployeeIdTo]
--     ,[IsMessageRead]
--     ,Null as [MessageIdParent]
--     ,[DateSent]
--     ,[DateReceived]
--     ,[FromAddress]
--     ,[ToAddress]
--     ,[CcAddress]
--     ,[Subject]
--     ,[Body]
--     ,[tmpInboxid]
--     ,[MessageType]
--     ,[IsMessageDeleted]
--     ,[EmployeeIdCreated]
--     ,[DateCreated]
--     ,MessageID as [tmpMessageID]
--    -- ,[DateCreatedUtc]
--     ,[Category]
-- 	,[ManuallyClassified]
-- 	,[EmployeeIdUpdated]
-- 	,[DateUpdated]
-- 	,'+@ToCompany+' as cs_companyid
--     From
--         dbo.temptrmessage

-- update Message
--set
--    MessageIdParent = temptrMessage.MessageIdParent
--from
--    Message inner join temptrMessage with (nolock)
--on
--    Message.MessageId = temptrMessage.NewMessageId
--where
--	temptrMessage.MessageIDParent is not null

--print @@rowcount

        PRINT 'Insert MessageAttachement TR';
        SET @sql = 'SELECT NULL AS newMessageid, NULL AS newAttachmentid, ma.* into dbo.tempMessageAttachmentTR from
               '+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment ma  inner join tempTRmessage tm  on ma.Messageid = tm.Messageid

SELECT * FROM tempMessageAttachmentTR

Update ma
set
	NewMessageid = ulk.[NewID]
From
    '+@ToDB+'.dbo.tempMessageAttachmentTR ma with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment Fma on ma.MessageID = fma.MessageID
	and Fma.AttachmentID = ma.AttachmentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fma.MessageId = ulk.oldid
where
   ulk.tablename = ''Message''

Update ma
set
	NewAttachmentID = ulk.[NewID]
From
    '+@ToDB+'.dbo.tempMessageAttachmentTR ma with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment Fma on ma.MessageID = fma.MessageID
	and Fma.AttachmentID = ma.AttachmentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fma.AttachmentID = ulk.oldid
where
	 ulk.tablename = ''FileAttachment''

select * from tempMessageAttachmentTR where Newattachmentid not in
(Select attachmentid from fileattachment)



	insert '+@ToDB+'.dbo.[MessageAttachment]
           (
           [MessageId]
           ,[AttachmentId]
           ,[tmpMessageAttachmentID]
		   ,MessageAttachment_cs_companyid
           )

       select  [NewMessageId]
           ,[NewAttachmentId]
           ,[tmpMessageAttachmentID]
		   ,'+@ToCompany+' as cs_companyid
        From tempMessageAttachmentTR
    ';
        EXEC (@sql);

        PRINT 'Insert Service';
        SET @sql = '
Select next value for seq_Service over (order by s.ServiceId) as newServiceId, s.*
into dbo.TempService
from '+@Fromserver+'.'+@FromDB+'.dbo.service s  inner join tempproperty p  on s.propertyid = p.propertyid
--order by s.serviceid

update ts
set
    ts.ServiceIdParent = s.newServiceId
from
    TempService ts with (nolock) inner join TempService s with (nolock)
on
    ts.ServiceIdParent = s.ServiceId

update ts
set
    ts.RequestTypeId = s.[newid]
from
    TempService ts with (nolock) inner join mapping s with (nolock)
on
    ts.RequestTypeId = s.fromid
where
    s.tablename = ''RT''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update ts
set
    ts.PropertyId = s.newPropertyId
from
    TempService ts with (nolock) inner join TempProperty s with (nolock)
on
    ts.PropertyId = s.PropertyId

update ts
set
    ts.TenantId = s.newTenantId
from
    TempService ts with (nolock) inner join TempTenant s with (nolock)
on
    ts.TenantId = s.TenantId

If exists (select * from TempService) Begin

update TempService set RequestTypeId = -3, PropertyId = -3, TenantId = -3

update TempService set EmployeeIdCreated = -3
where EmployeeIdCreated <>0

update TempService set EmployeeIdUpdated = -3
where EmployeeIdUpdated <>0

update s
set  s.RequestTypeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempService s with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Service Fs on s.ServiceId = Fs.ServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fs.RequestTypeId = ulk.oldid
where
	s.RequestTypeId = -3 and ulk.tablename = ''RequestType''

update s
set  s.PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempService s with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Service Fs on s.ServiceId = Fs.ServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fs.PropertyId = ulk.oldid
where
	s.PropertyId = -3 and ulk.tablename = ''Property''

update s
set  s.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempService s with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Service Fs on s.ServiceId = Fs.ServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fs.TenantId = ulk.oldid
where
	s.TenantId = -3 and ulk.tablename = ''Tenant''


update s
set  s.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempService s with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Service Fs on s.ServiceId = Fs.ServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fs.EmployeeIdCreated = ulk.oldid
where
	s.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''


update s
set  s.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempService s with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Service Fs on s.ServiceId = Fs.ServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fs.EmployeeIdUpdated = ulk.oldid
where
	s.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''
-- Reset all AccountID
update TempService set
	[AccountIdRevenueLabour] = 0
      ,[AccountIdRevenueMaterial] =0
      ,[AccountIdRevenueMarkup] =0
      ,[AccountIdRevenueAdmin] =0
      ,[AccountIdCostLabour]=0
      ,[AccountIdCostMaterial]=0


update TempService set EmployeeIdCreated = 0
where EmployeeIdCreated = -3

update TempService set EmployeeIdUpdated = 0
where EmployeeIdUpdated = -3

select

	[RequestTypeId] ,
	[PropertyId] ,
	[TenantId] ,
	[ServiceDescription]
from TempService
group by

	[RequestTypeId] ,
	[PropertyId] ,
	[TenantId] ,
	[ServiceDescription]
having count(*) > 1


While exists (

select

	[RequestTypeId] ,
	[PropertyId] ,
	[TenantId] ,
	[ServiceDescription]
from TempService
group by

	[RequestTypeId] ,
	[PropertyId] ,
	[TenantId] ,
	[ServiceDescription]
having count(*) > 1
)
Begin

update TempService
set
	--ServiceDescription = a.ServiceDescription + convert(varchar(10),a.serviceID)
	ServiceDescription = Left(LEFT(a.ServiceDescription,40) + left(convert(varchar(10),a.serviceID),10)  ,50)
From TempService a
inner join
(

select

	min(newServiceId) as newserviceid
from TempService
group by

	[RequestTypeId] ,
	[PropertyId] ,
	[TenantId] ,
	[ServiceDescription]
having count(*) > 1
) as b
on a.newServiceId = b.newServiceId

End

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Service'',
        	''ServiceId'',
        	ServiceId,
        	newServiceId
        From
           	dbo.TempService

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempService''
  ,@ToTable =''Service''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.Service
    -- (
    --     ServiceId,
    --     ServiceIdParent,
    --     RequestTypeId,
    --     PropertyId,
    --     TenantId,
    --     IsActiveService,
    --     IsBillable,
    --     LabourAmount,
    --     MaterialAmount,
    --     MarkupAmount,
    --     AdminAmount,
    --     LabourTaxRate,
    --     MaterialTaxRate,
    --     MarkupTaxRate,
    --     AdminTaxRate,
    --     MarkupFixed,
    --     AdminFixed,
    --     AccountIdRevenueLabour,
    --     AccountIdRevenueMaterial,
    --     AccountIdRevenueMarkup,
    --     AccountIdRevenueAdmin,
    --     AccountIdCostLabour,
    --     AccountIdCostMaterial,
    --     ServiceDescription,
	-- 	DateCreated,
	-- 	EmployeeIdCreated,
	-- 	DateUpdated,
	-- 	EmployeeIdUpdated,
    --     tmpSpId,
    --     tmpTenantGenerated,
    --     tmpBuildingId,
    --     IsThirdPartyVendor
	-- 	,service_cs_companyid
    -- )
    -- Select
    --     newServiceId                ,
    --     ServiceIdParent,
    --     RequestTypeId,
    --     PropertyId,
    --     TenantId,
    --     IsActiveService,
    --     IsBillable,
    --     LabourAmount,
    --     MaterialAmount,
    --     MarkupAmount,
    --     AdminAmount,
    --     LabourTaxRate,
    --     MaterialTaxRate,
    --     MarkupTaxRate,
    --     AdminTaxRate,
    --     MarkupFixed,
    --     AdminFixed,
    --     AccountIdRevenueLabour,
    --     AccountIdRevenueMaterial,
    --     AccountIdRevenueMarkup,
    --     AccountIdRevenueAdmin,
    --     AccountIdCostLabour,
    --     AccountIdCostMaterial,
    --     ServiceDescription,
	-- 	DateCreated,
	-- 	EmployeeIdCreated,
	-- 	DateUpdated,
	-- 	EmployeeIdUpdated,
    --     -1,
    --     -1,
    --     -1,
    --     IsThirdPartyVendor
	-- 	 ,'+@ToCompany+' as cs_companyid
    -- From
    --     dbo.TempService

        PRINT 'Insert Woservice';
        SET @sql = '
Select next value for seq_WoService over (order by wos3.WoServiceid) as newWoServiceId, wos3.*
into dbo.Tempwos
from
(
select wos.* from '+@Fromserver+'.'+@FromDB+'.dbo.woservice wos  inner join temptrwo trwo  on trwo.workorderid = wos.workorderid
union
select wos1.* from '+@Fromserver+'.'+@FromDB+'.dbo.woservice wos1  inner join TempTRWORes trwo1  on trwo1.workorderid = wos1.workorderid
) as wos3
--order by wos3.WoServiceid

update twos
set
    twos.workorderid = trwo.newworkorderid
from
    Tempwos twos with (nolock) inner join temptrwo trwo with (nolock)
on
    twos.workorderid = trwo.workorderid

update twos
set
    twos.ServiceId = trwo.newServiceId
from
    Tempwos twos with (nolock) inner join tempService trwo with (nolock)
on
    twos.ServiceId = trwo.ServiceId

update twos
set
    twos.EmployeeIdCreated = trwo.newEmployeeId
from
    Tempwos twos with (nolock) inner join tempce trwo with (nolock)
on
    twos.EmployeeIdCreated = trwo.EmployeeId

update twos
set
    twos.EmployeeIdUpdated = trwo.newEmployeeId
from
    Tempwos twos with (nolock) inner join tempce trwo with (nolock)
on
    twos.EmployeeIdUpdated = trwo.EmployeeId

if exists (select * from Tempwos) Begin

update Tempwos set WorkOrderId = -3, ServiceId = -3

update Tempwos set EmployeeIdCreated = -3
where EmployeeIdCreated is not null and EmployeeIdCreated <> 0 

update Tempwos set EmployeeIdUpdated = -3
where EmployeeIdUpdated is not null and EmployeeIdUpdated <> 0 


update ws
set  ws.WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempwos ws with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoService Fws on ws.WoServiceId = Fws.WoServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fws.WorkOrderId = ulk.oldid
where
	ws.WorkOrderId = -3 and ulk.tablename = ''WorkOrder''

update ws
set  ws.ServiceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempwos ws with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoService Fws on ws.WoServiceId = Fws.WoServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fws.ServiceId = ulk.oldid
where
	ws.ServiceId = -3 and ulk.tablename = ''Service''

update ws
set  ws.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempwos ws with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoService Fws on ws.WoServiceId = Fws.WoServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fws.EmployeeIdCreated = ulk.oldid
where
	ws.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

	update ws
set  ws.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempwos ws with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoService Fws on ws.WoServiceId = Fws.WoServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fws.EmployeeIdUpdated = ulk.oldid
where
	ws.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

--Select
--        newWoServiceId             ,
--		woserviceID,
--        WorkOrderId,
--        ServiceId,
--        WoServiceStatus,
--        IsBillable,
--        IsExternalResource,
--        DifferentCharge,
--        DifferentBillable,
--        BillableNoCharge,
--        BillableNonBillableRT,
--        NonBillableCharge,
--        Quantity,
--        LabourAmount,
--        MaterialAmount,
--        MarkupAmount,
--        AdminAmount,
--        LabourTaxAmount,
--        MaterialTaxAmount,
--        MarkupTaxAmount,
--        AdminTaxAmount,
--        EmployeeIdCreated,
--        DateCreated,
--        EmployeeIdUpdated,
--        DateUpdated,
--        -1              ,
--        -1,
--        -1
--    From
--        Tempwos where ServiceId not in (select serviceid from '+@ToDB+'.dbo.Service)



Update Tempwos
set
	serviceID = 0
where
	ServiceId not in (select serviceid from '+@ToDB+'.dbo.Service)



Update Tempwos
set
	EmployeeIdUpdated = 0
where
	EmployeeIdUpdated not in (select newEmployeeId from tempe)


Update Tempwos
set
	EmployeeIdCreated = 0
where
	EmployeeIdCreated not in (select newEmployeeId from tempe)


	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''WoService'',
        	''WoServiceId'',
        	WoServiceId,
        	NewWoServiceId
        From
           	dbo.Tempwos

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''Tempwos''
  ,@ToTable =''WoService''
  ,@CompanyId = '+@ToCompany+'


End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.WoService
    -- (
    --     WoServiceId,
    --     WorkOrderId,
    --     ServiceId,
    --     WoServiceStatus,
    --     IsBillable,
    --     IsExternalResource,
    --     DifferentCharge,
    --     DifferentBillable,
    --     BillableNoCharge,
    --     BillableNonBillableRT,
    --     NonBillableCharge,
    --     Quantity,
    --     LabourAmount,
    --     MaterialAmount,
    --     MarkupAmount,
    --     AdminAmount,
    --     LabourTaxAmount,
    --     MaterialTaxAmount,
    --     MarkupTaxAmount,
    --     AdminTaxAmount,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated,
    --     tmpRequestid,
    --     tmpRequestHistorySequence,
    --     tmpBillableItemSequence ,
	-- 	[Comment]
	-- 	,woservice_cs_companyid


    -- )
    -- Select
    --     newWoServiceId             ,
    --     WorkOrderId,
    --     ServiceId,
    --     WoServiceStatus,
    --     IsBillable,
    --     IsExternalResource,
    --     DifferentCharge,
    --     DifferentBillable,
    --     BillableNoCharge,
    --     BillableNonBillableRT,
    --     NonBillableCharge,
    --     Quantity,
    --     LabourAmount,
    --     MaterialAmount,
    --     MarkupAmount,
    --     AdminAmount,
    --     LabourTaxAmount,
    --     MaterialTaxAmount,
    --     MarkupTaxAmount,
    --     AdminTaxAmount,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated,
    --     -1         ,
    --     -1,
    --     -1,
	-- 	[Comment]
	-- 	,'+@ToCompany+' as cs_companyid
    -- From
    --     Tempwos

        PRINT 'Insert EstimateService';
        SET @sql = '
Select next value for seq_EstimateService over (order by ESTS.EstimateServiceId) as newEstimateServiceid, ESTS.*
into dbo.TempEstimateService
from '+@Fromserver+'.'+@FromDB+'.dbo.EstimateService ESTS   inner join tempEstimate r  on ESTS.Estimateid = r.Estimateid
--order by ESTS.EstimateServiceId

update TempEstimateService
set EstimateId = -3,
ServiceID = -3,
EmployeeIdCreated = -3,
EmployeeIdUpdated = -3



update trwo
set trwo.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateService trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateService Ftrwo on trwo.EstimateServiceId = Ftrwo.EstimateServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdCreated = ulk.oldid
where
	trwo.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update trwo
set trwo.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateService trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateService Ftrwo on trwo.EstimateServiceId = Ftrwo.EstimateServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdUpdated = ulk.oldid
where
	trwo.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''


update trwo
set trwo.EstimateId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateService trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateService Ftrwo on trwo.EstimateServiceId = Ftrwo.EstimateServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EstimateId = ulk.oldid
where
	trwo.EstimateId = -3 and ulk.tablename = ''Estimate''


update trwo
set trwo.ServiceID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEstimateService trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EstimateService Ftrwo on trwo.EstimateServiceId = Ftrwo.EstimateServiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ServiceID = ulk.oldid
where
	trwo.ServiceID = -3 and ulk.tablename = ''Service''


if exists (select * from TempEstimateService) Begin
 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EstimateService'',
        	''EstimateServiceID'',
        	EstimateServiceID,
        	newEstimateServiceID
        From
           	dbo.TempEstimateService

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEstimateService''
  ,@ToTable =''EstimateService''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.EstimateService
    -- (
    --     EstimateServiceId,
    --     EstimateId,
    --     ServiceId,
    --     IsBillable,
    --     IsExternalResource,
    --     Quantity,
    --     LabourAmount,
    --     MaterialAmount,
    --     MarkupAmount,
    --     AdminAmount,
    --     LabourTaxAmount,
    --     MaterialTaxAmount,
    --     MarkupTaxAmount,
    --     AdminTaxAmount,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated
	-- 	,EstimateService_cs_companyid
    -- )
    -- Select
    --     newEstimateServiceId                ,
    --     EstimateId,
    --     ServiceId,
    --     IsBillable,
    --     IsExternalResource,
    --     Quantity,
    --     LabourAmount,
    --     MaterialAmount,
    --     MarkupAmount,
    --     AdminAmount,
    --     LabourTaxAmount,
    --     MaterialTaxAmount,
    --     MarkupTaxAmount,
    --     AdminTaxAmount,
    --     EmployeeIdCreated,
    --     DateCreated,
    --     EmployeeIdUpdated,
    --     DateUpdated
	-- 	,'+@ToCompany+' as cs_companyid
    -- From
    --     dbo.TempEstimateService

        PRINT 'Insert EmployeeSubscription';
        SET @sql = '
Select next value for seq_EmployeeSubscription over (order by ESTS.EmployeeSubscriptionId) as newEmployeeSubscriptionid, ESTS.*
into dbo.TempEmployeeSubscription
from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscription ESTS   inner join tempe r  on ESTS.Employeeid = r.Employeeid
inner join '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty Ep on ESTS.Employeeid = EP.Employeeid
where (EP.Propertyid  = 0 or EP.PropertyID in '+@FromProperty+' )


update TempEmployeeSubscription
set Employeeid = -3 where employeeid <> 0

update TempEmployeeSubscription
set EmployeeIdCreated = -3 where EmployeeIdCreated <> 0

update TempEmployeeSubscription
set EmployeeIdUpdated = -3 where EmployeeIdUpdated <> 0


update trwo
set trwo.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEmployeeSubscription trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscription Ftrwo on trwo.EmployeeSubscriptionId = Ftrwo.EmployeeSubscriptionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdCreated = ulk.oldid
where
	trwo.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update trwo
set trwo.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEmployeeSubscription trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscription Ftrwo on trwo.EmployeeSubscriptionId = Ftrwo.EmployeeSubscriptionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdUpdated = ulk.oldid
where
	trwo.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

update trwo
set trwo.EmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEmployeeSubscription trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscription Ftrwo on trwo.EmployeeSubscriptionId = Ftrwo.EmployeeSubscriptionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeId = ulk.oldid
where
	trwo.EmployeeId = -3 and ulk.tablename = ''Employee''


If exists(
select * from TempEmployeeSubscription where MessageTemplateTypeID not in
(Select MessageTemplateTypeID from MessageTemplateType)
)
	delete from tempEmployeeSubscription where MessageTemplateTypeID not in
	(Select MessageTemplateTypeID from MessageTemplateType)

if exists (select * from TempEmployeeSubscription) Begin
 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EmployeeSubscription'',
        	''EmployeeSubscriptionID'',
        	EmployeeSubscriptionID,
        	newEmployeeSubscriptionID
        From
           	dbo.TempEmployeeSubscription

if exists(
select * from tempEmployeeSubscription where EmployeeIdCreated not in
(Select employeeid from employee)
)
	UPDATE  tempEmployeeSubscription
	SET EmployeeIdCreated = 0
	WHERE EmployeeIdCreated not in
	(Select employeeid from employee)

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEmployeeSubscription''
  ,@ToTable =''EmployeeSubscription''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.EmployeeSubscription
    -- (
    --     EmployeeSubscriptionId,
    --     MessageTemplateTypeID,
    --     EmployeeID,
    --     EmployeeIdCreated,
	-- 	EmployeeIdUpdated,
	-- 	DateCreated,
    --     DateUpdated
	-- 	,employeesubscription_cs_companyid
    -- )
    -- Select
    --     newEmployeeSubscriptionId                ,
    --     MessageTemplateTypeID,
    --     EmployeeID,
    --      EmployeeIdCreated,
	-- 	EmployeeIdUpdated,
	-- 	DateCreated,
    --     DateUpdated
	-- 	,'+@ToCompany+' as cs_companyid

    -- From
    --     dbo.TempEmployeeSubscription

        print 'Insert EmployeeSubscriptionCriteria'
        SET @sql = '
Select next value for seq_EmployeeSubscriptionCriteria over (order by ESTSC.EmployeeSubscriptionCriteriaId) as newEmployeeSubscriptionCriteriaid, ESTSC.*
into dbo.TempEmployeeSubscriptionCriteria
from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria ESTSC   inner join TempEmployeeSubscription r  on ESTSC.EmployeeSubscriptionId = r.EmployeeSubscriptionId


update TempEmployeeSubscriptionCriteria
set EmployeeSubscriptionId = -3
where EmployeeSubscriptionId <> 0 and EmployeeSubscriptionId is not null


update trwo
set trwo.EmployeeSubscriptionId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeSubscriptionId = ulk.oldid
where
	trwo.EmployeeSubscriptionId = -3 and ulk.tablename = ''EmployeeSubscription''


	update TempEmployeeSubscriptionCriteria
		set ExternalID = -3

		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.externalId = ulk.oldid
		  where
				trwo.externalId = -3 and ulk.tablename = ''Property''
				and trwo.CriteriaType = 1


		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.externalId = ulk.oldid
		  where
				trwo.externalId = -3 and ulk.tablename = ''Building''
				and trwo.CriteriaType = 2


		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.externalId = ulk.oldid
		  where
				trwo.externalId = -3 and ulk.tablename = ''Tenantid''
				and trwo.CriteriaType = 3


		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.externalId = ulk.oldid
		  where
				trwo.externalId = -3 and ulk.tablename = ''RequestType''
				and trwo.CriteriaType = 4


if exists(
select * from TempEmployeeSubscriptionCriteria where EmployeeSubscriptionId
 not in (Select EmployeeSubscriptionId from EmployeeSubscription)
)
	delete from  TempEmployeeSubscriptionCriteria where EmployeeSubscriptionId
	not in (Select EmployeeSubscriptionId from EmployeeSubscription)

if exists (select * from TempEmployeeSubscriptionCriteria) Begin
 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EmployeeSubscriptionCriteria'',
        	''EmployeeSubscriptionCriteriaID'',
        	EmployeeSubscriptionCriteriaID,
        	NewEmployeeSubscriptionCriteriaID
        From
           	dbo.TempEmployeeSubscriptionCriteria

	--Select
 --      NewEmployeeSubscriptionCriteriaId,
 --      [EmployeeSubscriptionId]   ,
	--	[CriteriaType] ,
	--	[ExternalId]

 --   From
 --       dbo.TempEmployeeSubscriptionCriteria
	--	where EmployeeSubscriptionId not in (Select EmployeeSubscriptionId from EmployeeSubscription)

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEmployeeSubscriptionCriteria''
  ,@ToTable =''EmployeeSubscriptionCriteria''
  ,@CompanyId = '+@ToCompany+'

End
'
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.EmployeeSubscriptionCriteria
    -- (
    --     EmployeeSubscriptionCriteriaId,
    --    [EmployeeSubscriptionId]   ,
	-- 	[CriteriaType] ,
	-- 	[ExternalId]
	-- 	,EmployeeSubscriptionCriteria_cs_companyid
    -- )
    -- Select
    --    NewEmployeeSubscriptionCriteriaId,
    --    [EmployeeSubscriptionId]   ,
	-- 	[CriteriaType] ,
	-- 	[ExternalId]
	-- 	,'+@ToCompany+' as cs_companyid

    -- From
    --     dbo.TempEmployeeSubscriptionCriteria

        IF EXISTS
                 (
                     SELECT *
        FROM mapping
        WHERE tablename = 'CommunicationType'
                 )
                     BEGIN
            PRINT 'Insert CommunicationSubscription';
            SET @sql = '
Select next value for seq_CommunicationSubscription over (order by CSub.CommunicationSubscriptionID) as newCommunicationSubscriptionID, CSub.*
into dbo.TempCommunicationSubscription
from '+@Fromserver+'.'+@FromDB+'.dbo.CommunicationSubscription CSub   inner join tempContact tc  on CSub.ContactId = tc.ContactID
--order by CSub.CommunicationSubscriptionID


Update TempCommunicationSubscription
set ContactID =  -3
where ContactID <> 0 and ContactID is not null

Update TempCommunicationSubscription
set Employeeid =  -3
where Employeeid <> 0 and Employeeid is not null

Update TempCommunicationSubscription
set [EmployeeIdEnteredBy] =  -3
where [EmployeeIdEnteredBy] <> 0 and [EmployeeIdEnteredBy] is not null



update trwo
set trwo.ContactID = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCommunicationSubscription trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.CommunicationSubscription Ftrwo on trwo.CommunicationSubscriptionID = Ftrwo.CommunicationSubscriptionID	 inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.ContactID = ulk.oldid
where
	trwo.ContactID = -3 and ulk.tablename = ''Contact''


update trwo
set trwo.Employeeid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCommunicationSubscription trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.CommunicationSubscription Ftrwo on trwo.CommunicationSubscriptionID = Ftrwo.CommunicationSubscriptionID	 inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.Employeeid = ulk.oldid
where
	trwo.Employeeid = -3 and ulk.tablename = ''Employee''



update trwo
set trwo.EmployeeIdEnteredBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCommunicationSubscription trwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.CommunicationSubscription Ftrwo on trwo.CommunicationSubscriptionID = Ftrwo.CommunicationSubscriptionID	 inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdEnteredBy = ulk.oldid
where
	trwo.EmployeeIdEnteredBy = -3 and ulk.tablename = ''Employee''

Update TempCommunicationSubscription
set CommunicationTypeID = [NewId]
from mapping with (nolock)
where tablename = ''CommunicationType'' and CommunicationTypeID = fromid
and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'


Update TempCommunicationSubscription
set EmployeeId = 0 
where EmployeeId not in (Select EmployeeId from employee)


Update TempCommunicationSubscription
set EmployeeIdEnteredBy = 0 
where EmployeeIdEnteredBy not in (Select EmployeeId from employee)


if exists (select * from TempCommunicationSubscription) Begin

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''CommunicationSubscription'',
        	''CommunicationSubscriptionID'',
        	CommunicationSubscriptionID,
        	newCommunicationSubscriptionID
        From
           	dbo.TempCommunicationSubscription


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempCommunicationSubscription''
  ,@ToTable =''CommunicationSubscription''
  ,@CompanyId = '+@ToCompany+'


End
';
            exec (@sql);
    -- insert '+@ToDB+'.[dbo].[CommunicationSubscription]
    --        ([CommunicationSubscriptionId]
    --        ,[CommunicationTypeId]
    --        ,[ContactId]
    --        ,[EmployeeId]
    --        ,[EmployeeIdEnteredBy]
	-- 	   ,CommunicationSubscription_cs_companyid
	-- 	   )
    -- select [NewCommunicationSubscriptionId]
    --        ,[CommunicationTypeId]
    --        ,[ContactId]
    --        ,[EmployeeId]
    --        ,[EmployeeIdEnteredBy]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From
	-- 	TempCommunicationSubscription

        end;

--Start Inspection Module (PI)
if @DoPI=1
begin
        --1. InspectionTemplate
        PRINT 'Insert InspectionTemplate';
        SET @sql = '
		if exists (select Insptemp.*
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Insptemp   inner join  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate a
on Insptemp.InspectionTemplateId = a.InspectionTemplateid
where 
a.PropertyId in '+@FromProperty+'
and Insptemp.companyid = '+ @FromCompany + '
)
Select next value for seq_InspectionTemplate over (order by Insptemp.InspectionTemplateID) as newInspectionTemplateID, Insptemp.*
into dbo.tempInspectionTemplate
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Insptemp   inner join  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate a
on Insptemp.InspectionTemplateId = a.InspectionTemplateid
where a.PropertyId in '+@FromProperty+'
and Insptemp.companyid = '+ @FromCompany + '

if not exists (select Insptemp.*
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Insptemp   inner join  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate a
on Insptemp.InspectionTemplateId = a.InspectionTemplateid
where 
a.PropertyId in '+@FromProperty+'
and Insptemp.companyid = '+ @FromCompany + '
)
Select next value for seq_InspectionTemplate over (order by Insptemp.InspectionTemplateID) as newInspectionTemplateID, Insptemp.*
into dbo.tempInspectionTemplate
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Insptemp   inner join  '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate a
on Insptemp.InspectionTemplateId = a.InspectionTemplateid
where  Insptemp.companyid = '+ @FromCompany + '

DELETE t FROM tempInspectionTemplate t INNER JOIN (
SELECT InspectionTemplateID, MAX(newInspectionTemplateID)  AS  newInspectionTemplateID FROM tempInspectionTemplate
GROUP BY InspectionTemplateID
HAVING COUNT(*)  > 1
) a ON t.InspectionTemplateID = a.InspectionTemplateID
AND t.newInspectionTemplateID <> a.newInspectionTemplateID


Update tempInspectionTemplate
set EmployeeId_CreatedBy = -3
where EmployeeId_CreatedBy >0

Update tempInspectionTemplate
set Companyid =  '+ @ToCompany + '

update tempInspectionTemplate
set EmployeeId_CreatedBy = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTemplate vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplate Fvd on vd.InspectionTemplateId = Fvd.InspectionTemplateId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_CreatedBy = ulk.oldid
where
	vd.EmployeeId_CreatedBy = -3 and ulk.tablename = ''Commonemployee''



select * from tempInspectionTemplate where EmployeeId_CreatedBy not in (select employeeid from employee)
and EmployeeId_CreatedBy is not null


--select * from InspectionTemplate

Update tempInspectionTemplate 
set EmployeeId_CreatedBy = 0 
where EmployeeId_CreatedBy not in (select employeeid from employee)
and EmployeeId_CreatedBy is not null


select * from tempInspectionTemplate
if exists (select * from tempInspectionTemplate) Begin

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTemplate'',
        	''InspectionTemplateID'',
        	InspectionTemplateID,
        	newInspectionTemplateID
        From
           	dbo.tempInspectionTemplate


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTemplate''
  ,@ToTable =''InspectionTemplate''
  ,@CompanyId = '+@ToCompany+'

End

';
        --PRINT (@sql)
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionTemplate]
    --        ([InspectionTemplateId]
    --        ,[Name]
    --        ,[DateInactive]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[EmployeeId_CreatedBy]
	-- 	   ,[CompanyId]
	-- 		,[IsCorporate]
	-- 		,[AppliesToAllProperties]
	-- 		,InspectionTemplate_cs_companyid
	-- 	   )
    -- select [NewInspectionTemplateId]
    --        ,[Name]
    --        ,[DateInactive]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[EmployeeId_CreatedBy]
	-- 	    ,[CompanyId]
	-- 		,[IsCorporate]
	-- 		,[AppliesToAllProperties]
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
	-- 	tempInspectionTemplate




        PRINT 'Insert InspectionPropertyTemplate';
        SET @sql = '
Select next value for seq_InspectionPropertyTemplate over (order by Insptemp.InspectionPropertyTemplateID) as newInspectionPropertyTemplateID, Insptemp.*
into dbo.tempInspectionPropertyTemplate
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate Insptemp   
where Insptemp.PropertyId in '+@FromProperty+'



Update tempInspectionPropertyTemplate
set EmployeeId_UpdatedBy = -3
where EmployeeId_UpdatedBy >0

Update tempInspectionPropertyTemplate
set Propertyid = -3


Update tempInspectionPropertyTemplate
set InspectionTemplateid = -3
WHERE InspectionTemplateid > 0 AND InspectionTemplateid IS NOT null


update tempInspectionPropertyTemplate
set EmployeeId_UpdatedBy = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionPropertyTemplate vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate Fvd on vd.InspectionPropertyTemplateID = Fvd.InspectionPropertyTemplateID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_UpdatedBy = ulk.oldid
where
	vd.EmployeeId_UpdatedBy = -3 and ulk.tablename = ''Commonemployee''

update tempInspectionPropertyTemplate
set PropertyID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionPropertyTemplate vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate Fvd on vd.InspectionPropertyTemplateID = Fvd.InspectionPropertyTemplateID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.PropertyID = ulk.oldid
where
	vd.PropertyID = -3 and ulk.tablename = ''Property''



update tempInspectionPropertyTemplate
set InspectionTemplateid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionPropertyTemplate vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionPropertyTemplate Fvd on vd.InspectionPropertyTemplateID = Fvd.InspectionPropertyTemplateID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateid = ulk.oldid
where
	vd.InspectionTemplateid = -3 and ulk.tablename = ''InspectionTemplate''


--select * from InspectionTemplate

Update tempInspectionPropertyTemplate 
set EmployeeId_UpdatedBy = 0 
where EmployeeId_UpdatedBy not in (select employeeid from employee)
and EmployeeId_UpdatedBy is not null

if exists (select * from tempInspectionPropertyTemplate) Begin

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionPropertyTemplate'',
        	''InspectionPropertyTemplateID'',
        	InspectionPropertyTemplateID,
        	newInspectionPropertyTemplateID
        From
           	dbo.tempInspectionPropertyTemplate


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionPropertyTemplate''
  ,@ToTable =''InspectionPropertyTemplate''
  ,@CompanyId = '+@ToCompany+'

End

';
        --PRINT (@sql)
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionPropertyTemplate]
    --        (
	-- 	   [InspectionPropertyTemplateId]
    --        ,[InspectionTemplateId]
    --        ,[PropertyId]
    --        ,[DateInactive]
    --        ,[EmployeeId_UpdatedBy]
	-- 	   ,InspectionPropertyTemplate_cs_companyid
	-- 	   )
    -- select [NewInspectionPropertyTemplateId]
    --        ,[InspectionTemplateId]
    --        ,[PropertyId]
    --        ,[DateInactive]
    --        ,[EmployeeId_UpdatedBy]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From
	-- 	tempInspectionPropertyTemplate



        --2.InspectionScaleDefinition
        PRINT 'Insert InspectionScaleDefinition';
        SET @sql = '
Select next value for seq_InspectionScaleDefinition over (order by a.InspectionScaleDefinitionID) as newInspectionScaleDefinitionID, a.*
into dbo.tempInspectionScaleDefinition
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionScaleDefinition a   inner join  tempInspectionTemplate b
on a.InspectionTemplateId = b.InspectionTemplateid

Update tempInspectionScaleDefinition
set InspectionTemplateId = -3
where InspectionTemplateId > 0


update tempInspectionScaleDefinition
set InspectionTemplateId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionScaleDefinition vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionScaleDefinition Fvd on vd.InspectionScaleDefinitionId = Fvd.InspectionScaleDefinitionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateId = ulk.oldid
where
	vd.InspectionTemplateId = -3 and ulk.tablename = ''InspectionTemplate''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionScaleDefinition'',
        	''InspectionScaleDefinitionId'',
        	InspectionScaleDefinitionId,
        	NewInspectionScaleDefinitionId
        From
           	dbo.TempInspectionScaleDefinition


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionScaleDefinition''
  ,@ToTable =''InspectionScaleDefinition''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionScaleDefinition]
    --        ([InspectionScaleDefinitionId]
    --        ,[InspectionTemplateId]
    --        ,[Text]
    --        ,[Value]
    --        ,[IsFailure]
	-- 	   ,InspectionScaleDefinition_cs_companyid
	-- 	   )
    -- select [NewInspectionScaleDefinitionId]
    --        ,[InspectionTemplateId]
    --        ,[Text]
    --        ,[Value]
    --        ,[IsFailure]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionScaleDefinition




        --2.InspectionTemplateSection
        PRINT 'Insert InspectionTemplateSection';
        SET @sql = '
Select next value for seq_InspectionTemplateSection over (order by a.InspectionTemplateSectionID) as newInspectionTemplateSectionID, a.*
into dbo.tempInspectionTemplateSection
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplateSection a   inner join  tempInspectionTemplate b
on a.InspectionTemplateId = b.InspectionTemplateid

Update tempInspectionTemplateSection
set InspectionTemplateId = -3
where InspectionTemplateId >0

Update tempInspectionTemplateSection
set InspectionTemplateId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTemplateSection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplateSection Fvd on vd.InspectionTemplateSectionId = Fvd.InspectionTemplateSectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateId = ulk.oldid
where
	vd.InspectionTemplateId = -3 and ulk.tablename = ''InspectionTemplate''

	select * from tempInspectionTemplateSection
	where InspectionTemplateId not in (Select InspectionTemplateId from InspectionTemplate)

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTemplateSection'',
        	''InspectionTemplateSectionId'',
        	InspectionTemplateSectionId,
        	NewInspectionTemplateSectionId
        From
           	dbo.TempInspectionTemplateSection


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTemplateSection''
  ,@ToTable =''InspectionTemplateSection''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionTemplateSection]
    --        ([InspectionTemplateSectionId]
    --        ,[InspectionTemplateId]
    --        ,[Title]
    --        ,[Sequence]
    --        ,[DateInactive]
	-- 	   ,InspectionTemplateSection_cs_companyid
	-- 	   )
    -- select [NewInspectionTemplateSectionId]
    --        ,[InspectionTemplateId]
    --        ,[Title]
    --        ,[Sequence]
    --        ,[DateInactive]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionTemplateSection




        --2.InspectionTemplateSectionTask
        PRINT 'Insert InspectionTemplateSectionTask';
        SET @sql = '
Select next value for seq_InspectionTemplateSectionTask over (order by a.InspectionTemplateSectionTaskID) as newInspectionTemplateSectionTaskID, a.*
into dbo.tempInspectionTemplateSectionTask
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplateSectionTask a   inner join  tempInspectionTemplateSection b
on a.InspectionTemplateSectionId = b.InspectionTemplateSectionId

Update tempInspectionTemplateSectionTask
set InspectionTemplateSectionId = -3
where InspectionTemplateSectionId >0

Update tempInspectionTemplateSectionTask
set InspectionTemplateSectionId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTemplateSectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTemplateSectionTask Fvd on vd.InspectionTemplateSectionTaskId = Fvd.InspectionTemplateSectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateSectionId = ulk.oldid
where
	vd.InspectionTemplateSectionId = -3 and ulk.tablename = ''InspectionTemplateSection''

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTemplateSectionTask'',
        	''InspectionTemplateSectionTaskId'',
        	InspectionTemplateSectionTaskId,
        	NewInspectionTemplateSectionTaskId
        From
           	dbo.TempInspectionTemplateSectionTask


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTemplateSectionTask''
  ,@ToTable =''InspectionTemplateSectionTask''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionTemplateSectionTask]
    --        ([InspectionTemplateSectionTaskId]
    --        ,[InspectionTemplateSectionId]
    --        ,[Description]
    --        ,[Sequence]
    --        ,[DateInactive]
    --        ,[DateCreated]
    --        ,[Weight]
	-- 	   ,InspectionTemplateSectionTask_cs_companyid
	-- 	   )
    -- select [NewInspectionTemplateSectionTaskId]
    --        ,[InspectionTemplateSectionId]
    --        ,[Description]
    --        ,[Sequence]
    --        ,[DateInactive]
    --        ,[DateCreated]
    --        ,[Weight]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionTemplateSectionTask


        ------------------
        -- InspectionSchedule
        PRINT 'Insert InspectionSchedule';
        SET @sql = '
Select next value for seq_InspectionSchedule over (order by a.InspectionScheduleID) as newInspectionScheduleID, a.*
into dbo.tempInspectionSchedule
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule a
where a.Propertyid in '+@FromProperty+'

Update tempInspectionSchedule
set buildingid = -3 where buildingid > 0

Update tempInspectionSchedule
set Propertyid = -3 where Propertyid > 0

Update tempInspectionSchedule
set EmployeeId_AssignedToSchedule = -3 where EmployeeId_AssignedToSchedule > 0

Update tempInspectionSchedule
set EmployeeId_AssignedToNextInspection = -3 where EmployeeId_AssignedToNextInspection > 0


Update tempInspectionSchedule
set InspectionTemplateId = -3 where InspectionTemplateId > 0



update tempInspectionSchedule
set EmployeeId_AssignedToSchedule = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_AssignedToSchedule = ulk.oldid
where
	vd.EmployeeId_AssignedToSchedule = -3 and ulk.tablename = ''Commonemployee''


update tempInspectionSchedule
set EmployeeId_AssignedToNextInspection = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_AssignedToNextInspection = ulk.oldid
where
	vd.EmployeeId_AssignedToNextInspection = -3 and ulk.tablename = ''Commonemployee''



update tempInspectionSchedule
set Propertyid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Propertyid = ulk.oldid
where
	vd.Propertyid = -3 and ulk.tablename = ''Property''



update tempInspectionSchedule
set Buildingid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Buildingid = ulk.oldid
where
	vd.Buildingid = -3 and ulk.tablename = ''Building''



update tempInspectionSchedule
set InspectionTemplateId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionSchedule vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionSchedule Fvd on vd.InspectionScheduleId = Fvd.InspectionScheduleId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateId = ulk.oldid
where
	vd.InspectionTemplateId = -3 and ulk.tablename = ''InspectionTemplate''


	delete from tempInspectionSchedule where InspectionTemplateId not in (Select InspectionTemplateId from InspectionTemplate)

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionSchedule'',
        	''InspectionScheduleId'',
        	InspectionScheduleId,
        	NewInspectionScheduleId
        From
           	dbo.TempInspectionSchedule

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionSchedule''
  ,@ToTable =''InspectionSchedule''
  ,@CompanyId = '+@ToCompany+'


';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionSchedule]
    --        (
	-- 	   [InspectionScheduleId]
    --        ,[InspectionTemplateId]
    --        ,[BuildingId]
    --        ,[EmployeeId_AssignedToSchedule]
    --        ,[Frequency]
    --        ,[EstimatedCompletionTimeInMinutes]
    --        ,[LocationDetails]
    --        ,[CancellationNotes]
    --        ,[DateInactive]
    --        ,[NextScheduleDate]
    --        ,[DateCreated]
    --        ,[GeneralInspectionNote]
    --        ,[DaysToComplete]
    --        ,[ExpectedCompletionDate]
    --        ,[PropertyId]
    --        ,[StartDate]
    --        ,[NextIssueDate]
    --        ,[EmployeeId_AssignedToNextInspection]
	-- 	   ,[IssueOnWeekends]
	-- 	   ,InspectionSchedule_cs_companyid
	-- 	   )
    -- select [NewInspectionScheduleId]
    --        ,[InspectionTemplateId]
    --        ,[BuildingId]
    --        ,[EmployeeId_AssignedToSchedule]
    --        ,[Frequency]
    --        ,[EstimatedCompletionTimeInMinutes]
    --        ,[LocationDetails]
    --        ,[CancellationNotes]
    --        ,[DateInactive]
    --        ,[NextScheduleDate]
    --        ,[DateCreated]
    --        ,[GeneralInspectionNote]
    --        ,[DaysToComplete]
    --        ,[ExpectedCompletionDate]
    --        ,[PropertyId]
    --        ,[StartDate]
    --        ,[NextIssueDate]
    --        ,[EmployeeId_AssignedToNextInspection]
	-- 	   ,[IssueOnWeekends]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionSchedule

        -- InspectionScheduleArea

        PRINT 'Insert InspectionScheduleArea';
        SET @sql = '
Select next value for seq_InspectionScheduleArea over (order by a.InspectionScheduleAreaID) as newInspectionScheduleAreaID, a.*
into dbo.tempInspectionScheduleArea
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionScheduleArea a inner join tempInspectionSchedule b
on a.InspectionScheduleId = b.InspectionScheduleId

Update tempInspectionScheduleArea
set PropertyId = -3
where PropertyId > 0

update tempInspectionScheduleArea
set AreaID = -3
where AreaID >0



update tempInspectionScheduleArea
set InspectionScheduleId = -3
where InspectionScheduleId >0


update tempInspectionScheduleArea
set Propertyid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionScheduleArea vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionScheduleArea Fvd on vd.InspectionScheduleAreaId = Fvd.InspectionScheduleAreaId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Propertyid = ulk.oldid
where
	vd.Propertyid = -3 and ulk.tablename = ''Property''



update tempInspectionScheduleArea
set Areaid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionScheduleArea vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionScheduleArea Fvd on vd.InspectionScheduleAreaId = Fvd.InspectionScheduleAreaId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Areaid = ulk.oldid
where
	vd.Areaid = -3 and ulk.tablename = ''Area''



update tempInspectionScheduleArea
set InspectionScheduleId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionScheduleArea vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionScheduleArea Fvd on vd.InspectionScheduleAreaId = Fvd.InspectionScheduleAreaId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionScheduleId = ulk.oldid
where
	vd.InspectionScheduleId = -3 and ulk.tablename = ''InspectionSchedule''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionScheduleArea'',
        	''InspectionScheduleAreaId'',
        	InspectionScheduleAreaId,
        	NewInspectionScheduleAreaId
        From
           	dbo.TempInspectionScheduleArea


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionScheduleArea''
  ,@ToTable =''InspectionScheduleArea''
  ,@CompanyId = '+@ToCompany+'


';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionScheduleArea]
    --        (
	-- 	   [InspectionScheduleAreaId]
    --        ,[InspectionScheduleId]
    --        ,[AreaId]
    --        ,[DateInactive]
    --        ,[DateCreated]
    --        ,[PropertyId]
	-- 	   ,InspectionScheduleArea_cs_Companyid
	-- 	   )
    -- select [NewInspectionScheduleAreaId]
    --        ,[InspectionScheduleId]
    --        ,[AreaId]
    --        ,[DateInactive]
    --        ,[DateCreated]
    --        ,[PropertyId]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionScheduleArea


        -- Inspection

        PRINT 'Insert Inspection';
        SET @sql = '
Select next value for seq_Inspection over (order by a.InspectionID) as newInspectionID, a.*
into dbo.tempInspection
from '+@Fromserver+'.'+@FromDB+'.dbo.Inspection a inner join tempInspectionSchedule b
on a.InspectionScheduleId = b.InspectionScheduleId

Update tempInspection
set InspectionScheduleId = -3
where InspectionScheduleId >0

Update tempInspection
set EmployeeId_Assigned = -3
where EmployeeId_Assigned >0


Update tempInspection
set EmployeeId_CompletedBy = -3
where EmployeeId_CompletedBy >0


update tempInspection
set InspectionScheduleId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Inspection Fvd on vd.InspectionId = Fvd.InspectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionScheduleId = ulk.oldid
where
	vd.InspectionScheduleId = -3 and ulk.tablename = ''InspectionSchedule''



update tempInspection
set EmployeeId_Assigned = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Inspection Fvd on vd.InspectionId = Fvd.InspectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_Assigned = ulk.oldid
where
	vd.EmployeeId_Assigned = -3 and ulk.tablename = ''Commonemployee''



update tempInspection
set EmployeeId_CompletedBy = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Inspection Fvd on vd.InspectionId = Fvd.InspectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_CompletedBy = ulk.oldid
where
	vd.EmployeeId_CompletedBy = -3 and ulk.tablename = ''Commonemployee''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Inspection'',
        	''InspectionId'',
        	InspectionId,
        	NewInspectionId
        From
           	dbo.TempInspection


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspection''
  ,@ToTable =''Inspection''
  ,@CompanyId = '+@ToCompany+'


';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[Inspection]
    --        (
	-- 	   [InspectionId]
    --        ,[InspectionScheduleId]
    --        ,[EmployeeId_Assigned]
    --        ,[ExpectedCompletionDate]
    --        ,[DateCreated]
    --        ,[Status]
    --        ,[IsManual]
    --        ,[DateCompleted]
    --        ,[EmployeeId_CompletedBy]
    --        ,[DateUpdated]
    --        ,[WorkStartedDate]
	-- 	   ,inspection_cs_companyid
	-- 	   )
    -- select [NewInspectionId]
    --        ,[InspectionScheduleId]
    --        ,[EmployeeId_Assigned]
    --        ,[ExpectedCompletionDate]
    --        ,[DateCreated]
    --        ,[Status]
    --        ,[IsManual]
    --        ,[DateCompleted]
    --        ,[EmployeeId_CompletedBy]
    --        ,[DateUpdated]
    --        ,[WorkStartedDate]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspection


        -- InspectionHistory

        PRINT 'Insert InspectionHistory';
        SET @sql = '
Select next value for seq_InspectionHistory over (order by a.InspectionHistoryID) as newInspectionHistoryID, a.*
into dbo.tempInspectionHistory
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory a inner join tempInspection b
on a.InspectionId = b.InspectionID

Update tempInspectionHistory
set InspectionId = -3
where InspectionId >0

Update tempInspectionHistory
set EmployeeId_History = -3
where EmployeeId_History >0


Update tempInspectionHistory
set EmployeeId_Updated = -3
where EmployeeId_Updated >0


update tempInspectionHistory
set InspectionId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory Fvd on vd.InspectionHistoryId = Fvd.InspectionHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionId = ulk.oldid
where
	vd.InspectionId = -3 and ulk.tablename = ''Inspection''



update tempInspectionHistory
set EmployeeId_History = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory Fvd on vd.InspectionHistoryId = Fvd.InspectionHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_History = ulk.oldid
where
	vd.EmployeeId_History = -3 and ulk.tablename = ''Commonemployee''



update tempInspectionHistory
set EmployeeId_Updated = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionHistory Fvd on vd.InspectionHistoryId = Fvd.InspectionHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeId_Updated = ulk.oldid
where
	vd.EmployeeId_Updated = -3 and ulk.tablename = ''Commonemployee''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionHistory'',
        	''InspectionHistoryId'',
        	InspectionHistoryId,
        	NewInspectionHistoryId
        From
           	dbo.TempInspectionHistory


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionHistory''
  ,@ToTable =''InspectionHistory''
  ,@CompanyId = '+@ToCompany+'


';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionHistory]
    --        (
	-- 	   [InspectionHistoryId]
    --        ,[InspectionId]
    --        ,[EmployeeId_History]
    --        ,[Event]
    --        ,[DurationInMinutes]
    --        ,[Notes]
    --        ,[DateCreated]
    --        ,[EmployeeId_Updated]
	-- 	   ,InspectionHistory_cs_companyid
	-- 	   )
    -- select [NewInspectionHistoryId]
    --        ,[InspectionId]
    --        ,[EmployeeId_History]
    --        ,[Event]
    --        ,[DurationInMinutes]
    --        ,[Notes]
    --        ,[DateCreated]
    --        ,[EmployeeId_Updated]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionHistory


        -- InspectionTask

        PRINT 'Insert InspectionTask';
        SET @sql = '
Select next value for seq_InspectionTask over (order by a.InspectionTaskID) as newInspectionTaskID, a.*
into dbo.tempInspectionTask
from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask a inner join tempInspection b
on a.InspectionId = b.InspectionID

Update tempInspectionTask
set InspectionId = -3
where InspectionId >0

Update tempInspectionTask
set InspectionScheduleAreaId = -3
where InspectionScheduleAreaId >0



Update tempInspectionTask
set InspectionTemplateSectionTaskId = -3
where InspectionTemplateSectionTaskId >0 and InspectionTemplateSectionTaskId is not null

Update tempInspectionTask
set WorkOrderId = -3
where WorkOrderId >0


update tempInspectionTask
set InspectionId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionId = ulk.oldid
where
	vd.InspectionId = -3 and ulk.tablename = ''Inspection''



update tempInspectionTask
set InspectionScheduleAreaId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionScheduleAreaId = ulk.oldid
where
	vd.InspectionScheduleAreaId = -3 and ulk.tablename = ''InspectionScheduleArea''



update tempInspectionTask
set WorkOrderId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.WorkOrderId = ulk.oldid
where
	vd.WorkOrderId = -3 and ulk.tablename = ''WorkOrder''

Update tempInspectionTask
set InspectionScaleDefinitionId = -3
where InspectionScaleDefinitionId >0


update tempInspectionTask
set InspectionScaleDefinitionId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionScaleDefinitionId = ulk.oldid
where
	vd.InspectionScaleDefinitionId = -3 and ulk.tablename = ''InspectionScaleDefinition''



update tempInspectionTask
set InspectionTemplateSectionTaskId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTask vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTask Fvd on vd.InspectionTaskId = Fvd.InspectionTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTemplateSectionTaskId = ulk.oldid
where
	vd.InspectionTemplateSectionTaskId = -3 and ulk.tablename = ''InspectionTemplateSectionTask''




Update tempInspectionTask
set InspectionScaleDefinitionId = null
where InspectionScaleDefinitionId not in (select InspectionScaleDefinitionId from InspectionScaleDefinition)


delete from tempInspectionTask where InspectionTemplateSectionTaskId not in (Select newInspectionTemplateSectionTaskId from tempInspectionTemplateSectionTask)

select * from tempInspectionTask where InspectionTemplateSectionTaskId not in (Select InspectionTemplateSectionTaskId from InspectionTemplateSectionTask)

 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTask'',
        	''InspectionTaskId'',
        	InspectionTaskId,
        	NewInspectionTaskId
        From
           	dbo.TempInspectionTask


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTask''
  ,@ToTable =''InspectionTask''
  ,@CompanyId = '+@ToCompany+'

';
        EXEC (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionTask]
    --        (
	-- 	   [InspectionTaskId]
    --        ,[InspectionId]
    --        ,[InspectionTemplateSectionTaskId]
    --        ,[InspectionScaleDefinitionId]
    --        ,[InspectionScheduleAreaId]
    --        ,[WorkOrderId]
    --        ,[Notes]
    --        ,[RequiresCorrection]
    --        ,[DateUpdated]
	-- 	   ,InspectionTask_cs_companyid
	-- 	   )
    -- select [NewInspectionTaskId]
    --        ,[InspectionId]
    --        ,[InspectionTemplateSectionTaskId]
    --        ,[InspectionScaleDefinitionId]
    --        ,[InspectionScheduleAreaId]
    --        ,[WorkOrderId]
    --        ,[Notes]
    --        ,[RequiresCorrection]
    --        ,[DateUpdated]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionTask



        -- InspectionTaskAttachment

        PRINT 'Insert InspectionTaskAttachment';
        SET @sql = '
Select next value for seq_InspectionTaskAttachment over (order by a.InspectionTaskAttachmentID) as newInspectionTaskAttachmentID, a.*
into dbo.tempInspectionTaskAttachment
--from '+@Fromserver+'.'+@FromDB+'.dbo.InspectionTaskAttachment a inner join tempInspectionTask b
from '+@Fromserver+'.'+@FromDB+'.dbo.view_InspectionTaskAttachment a inner join tempInspectionTask b
on a.InspectionTaskId = b.InspectionTaskID

Update tempInspectionTaskAttachment
set InspectionTaskId = -3
where InspectionTaskId >0



update tempInspectionTaskAttachment
set InspectionTaskId = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempInspectionTaskAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.InspectionTaskAttachment Fvd on vd.InspectionTaskAttachmentId = Fvd.InspectionTaskAttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InspectionTaskId = ulk.oldid
where
	vd.InspectionTaskId = -3 and ulk.tablename = ''InspectionTask''


 Insert  dbo.'+@lookup+'
        (
    	    TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''InspectionTaskAttachment'',
        	''InspectionTaskAttachmentId'',
        	InspectionTaskAttachmentId,
        	NewInspectionTaskAttachmentId
        From
           	dbo.TempInspectionTaskAttachment


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempInspectionTaskAttachment''
  ,@ToTable =''InspectionTaskAttachment''
  ,@CompanyId = '+@ToCompany+'

';
        exec (@sql);
    -- insert '+@ToDB+'.[dbo].[InspectionTaskAttachment]
    --        (
	-- 	   [InspectionTaskAttachmentId]
    --        ,[InspectionTaskId]
    --        ,[FileName]
    --        ,[FileSize]
    --        ,[Content]
    --        ,[DateCreated]
	-- 	   ,InspectionTaskAttachment_cs_companyid
	-- 	   )
    -- select [NewInspectionTaskAttachmentId]
    --        ,[InspectionTaskId]
    --        ,[FileName]
    --        ,[FileSize]
    --        ,[Content]
    --        ,[DateCreated]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From   tempInspectionTaskAttachment


end --PI
--End of Inspection
--------------------
        PRINT 'Insert GeoDispatchResponse';
        SET @sql = '
	  Select next value for seq_GeoDispatchResponse over (order by GeoDispatchResponseId) as newGeoDispatchResponseID, GeoDispatchResponse.* into tempGeoDispatchResponse from '+@Fromserver+'.'+@FromDB+'.dbo.GeoDispatchResponse
	  inner join tempProperty tp on GeoDispatchResponse.PropertyId = tp.PropertyId
	  

	  Update tempGeoDispatchResponse
	  set DispatchEmployeeId = -3
	  where DispatchEmployeeId is not null and DispatchEmployeeId <> 0 

	  
	  Update tempGeoDispatchResponse
	  set Propertyid = -3
	  where Propertyid is not null and Propertyid <> 0 

	  	  
	  Update tempGeoDispatchResponse
	  set WorkorderId = -3
	  where WorkorderId is not null and WorkorderId <> 0 

	  
		update vd
		set
			vd.DispatchEmployeeId = ulk.[NewID]
		From
			'+@ToDB+'.dbo.tempGeoDispatchResponse vd with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.GeoDispatchResponse Fvd on vd.GeoDispatchResponseID = Fvd.GeoDispatchResponseID inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.DispatchEmployeeId = ulk.oldid
		where
			vd.DispatchEmployeeId = -3 and ulk.tablename = ''Employee''

			
	  
		update vd
		set
			vd.PropertyId = ulk.[NewID]
		From
			'+@ToDB+'.dbo.tempGeoDispatchResponse vd with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.GeoDispatchResponse Fvd on vd.GeoDispatchResponseID = Fvd.GeoDispatchResponseID inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.PropertyId = ulk.oldid
		where
			vd.PropertyId = -3 and ulk.tablename = ''Property''

		update vd
		set
			vd.workorderId = ulk.[NewID]
		From
			'+@ToDB+'.dbo.tempGeoDispatchResponse vd with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.GeoDispatchResponse Fvd on vd.GeoDispatchResponseID = Fvd.GeoDispatchResponseID inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.workorderId = ulk.oldid
		where
			vd.workorderId = -3 and ulk.tablename = ''workorder''

	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''GeoDispatchResponse'',
        	''GeoDispatchResponseID'',
        	GeoDispatchResponseID,
        	newGeoDispatchResponseID
        From
           	dbo.tempGeoDispatchResponse
			
---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempGeoDispatchResponse''
  ,@ToTable =''GeoDispatchResponse''
  ,@CompanyId = '+@ToCompany+'
  

	  ';
        EXEC (@sql);
-- INSERT INTO [dbo].[GeoDispatchResponse]
--            (
-- 		 [GeoDispatchResponseId]
--            ,[WorkorderId]
--            ,[DispatchEmployeeId]
--            ,[PropertyId]
--            ,[DateCreated]
--            ,[GeoDispatchResponse_CS_CompanyId]
-- 		   )

-- 		   select 
-- 		   [NewGeoDispatchResponseId]
--            ,[WorkorderId]
--            ,[DispatchEmployeeId]
--            ,[PropertyId]
--            ,[DateCreated]          
--            ,'+@ToCompany+' as  cs_companyid
-- 		   From tempGeoDispatchResponse
	  

        PRINT 'Insert GeoDispatchResponseDetail';
        SET @sql = '
	  Select next value for seq_GeoDispatchResponseDetail over (order by GeoDispatchResponseDetail.GeoDispatchResponseDetailID) as newGeoDispatchResponseDetailID, GeoDispatchResponseDetail.* into tempGeoDispatchResponseDetail from '+@Fromserver+'.'+@FromDB+'.dbo.GeoDispatchResponseDetail
	  inner join tempGeoDispatchResponse tp on GeoDispatchResponseDetail.GeoDispatchResponseId  = tp.GeoDispatchResponseId
	  

	  Update tempGeoDispatchResponseDetail
	  set employeeId = -3
	  where employeeId is not null and employeeId <> 0 

	  
	  Update tempGeoDispatchResponseDetail
	  set GeoDispatchResponseId = -3
	  where GeoDispatchResponseId is not null and GeoDispatchResponseId <> 0 

	  	  	  
		update vd
		set
			vd.employeeid = ulk.[NewID]
		From
			'+@ToDB+'.dbo.tempGeoDispatchResponseDetail vd with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.GeoDispatchResponseDetail Fvd on vd.GeoDispatchResponseDetailID = Fvd.GeoDispatchResponseDetailID inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.employeeid = ulk.oldid
		where
			vd.employeeid = -3 and ulk.tablename = ''Employee''

			
	  
		update vd
		set
			vd.GeoDispatchResponseId = ulk.[NewID]
		From
			'+@ToDB+'.dbo.tempGeoDispatchResponseDetail vd with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.GeoDispatchResponseDetail Fvd on vd.GeoDispatchResponseDetailID = Fvd.GeoDispatchResponseDetailID inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.GeoDispatchResponseId = ulk.oldid
		where
			vd.GeoDispatchResponseId = -3 and ulk.tablename = ''GeoDispatchResponse''


	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''GeoDispatchResponseDetail'',
        	''GeoDispatchResponseDetailID'',
        	GeoDispatchResponseDetailID,
        	newGeoDispatchResponseDetailID
        From
           	dbo.tempGeoDispatchResponseDetail
			
---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempGeoDispatchResponseDetail''
  ,@ToTable =''GeoDispatchResponseDetail''
  ,@CompanyId = '+@ToCompany+'


	  ';
        exec (@sql);
-- INSERT INTO [dbo].[GeoDispatchResponseDetail]
--            (
-- 		 [GeoDispatchResponseDetailId]
--            ,[EmployeeId]
--            ,[GeoDispatchResponseId]
--            ,[EmployeeName]
--            ,[EmployeeStatus]
--            ,[DateEmployeeStatusUpdated]
--            ,[DeviceNotes]
--            ,[Latitude]
--            ,[Longitude]
--            ,[LastLocationDate]
--            ,[Accuracy]
--            ,[VacationFromDate]
--            ,[VacationToDate]
--            ,[shifts]
--            ,[lastEventDate]
--            ,[lastWorkEvent]
--            ,[LastWorkEventDescription]
--            ,[trWorkOrders]
--            ,[pmWorkOrders]
--            ,[IanaTimeZone]
--            ,[TimeZoneOffset]
--            ,[GeoDispatchResponseDetail_CS_CompanyId]
-- 		   )

-- 		   select 
-- 		   [NewGeoDispatchResponseDetailId]
--            ,[EmployeeId]
--            ,[GeoDispatchResponseId]
--            ,[EmployeeName]
--            ,[EmployeeStatus]
--            ,[DateEmployeeStatusUpdated]
--            ,[DeviceNotes]
--            ,[Latitude]
--            ,[Longitude]
--            ,[LastLocationDate]
--            ,[Accuracy]
--            ,[VacationFromDate]
--            ,[VacationToDate]
--            ,[shifts]
--            ,[lastEventDate]
--            ,[lastWorkEvent]
--            ,[LastWorkEventDescription]
--            ,[trWorkOrders]
--            ,[pmWorkOrders]
--            ,[IanaTimeZone]
--            ,[TimeZoneOffset]          
--            ,'+@ToCompany+' as  cs_companyid
-- 		   From tempGeoDispatchResponseDetail
	  

    -- TR End
    end;
---------------------------------------------
    IF @DoPM = 1
             BEGIN
        IF @DoTR = 0
                     BEGIN
            PRINT 'Insert EmployeeSubscription';
            SET @sql = '
		Select next value for seq_EmployeeSubscription over (order by ESTS.EmployeeSubscriptionid) as newEmployeeSubscriptionid, ESTS.*
		into dbo.TempEmployeeSubscription
			from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscription ESTS   inner join tempe r  on ESTS.Employeeid = r.Employeeid
		  inner join '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeProperty Ep on ESTS.Employeeid = EP.Employeeid
		  where (EP.Propertyid  = 0 or EP.PropertyID in '+@FromProperty+' )


		update TempEmployeeSubscription
		set Employeeid = -3 where employeeid <> 0

		update TempEmployeeSubscription
		set EmployeeIdCreated = -3 where EmployeeIdCreated <> 0

		update TempEmployeeSubscription
		set EmployeeIdUpdated = -3 where EmployeeIdUpdated <> 0

		update trwo
		set trwo.EmployeeIdCreated = ulk.[NewId]
		From
			'+@ToDB+'.dbo.TempEmployeeSubscription trwo with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscription Ftrwo on trwo.EmployeeSubscriptionId = Ftrwo.EmployeeSubscriptionId inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdCreated = ulk.oldid
		where
			trwo.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

		update trwo
		set trwo.EmployeeIdUpdated = ulk.[NewId]
		From
			'+@ToDB+'.dbo.TempEmployeeSubscription trwo with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscription Ftrwo on trwo.EmployeeSubscriptionId = Ftrwo.EmployeeSubscriptionId inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeIdUpdated = ulk.oldid
		where
			trwo.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

		update trwo
		set trwo.EmployeeId = ulk.[NewId]
		From
			'+@ToDB+'.dbo.TempEmployeeSubscription trwo with (nolock) inner join
			'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscription Ftrwo on trwo.EmployeeSubscriptionId = Ftrwo.EmployeeSubscriptionId inner join
			'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeId = ulk.oldid
		where
			trwo.EmployeeId = -3 and ulk.tablename = ''Employee''

select * from TempEmployeeSubscription where MessageTemplateTypeID not in
(Select MessageTemplateTypeID from MessageTemplateType)

delete from tempEmployeeSubscription where MessageTemplateTypeID not in
(Select MessageTemplateTypeID from MessageTemplateType)

		if exists (select * from TempEmployeeSubscription) Begin

		select * from TempEmployeeSubscription where EmployeeIdCreated not in
		(Select employeeid from employee)

		Update TempEmployeeSubscription
		set EmployeeIdCreated = 0
		where EmployeeIdCreated not in
		(Select employeeid from employee)

		Insert  dbo.'+@lookup+'
				(
    				TableName,
        			ColumnName,
        			OldId,
        			[NewId]
				)
				Select
        			''EmployeeSubscription'',
        			''EmployeeSubscriptionID'',
        			EmployeeSubscriptionID,
        			newEmployeeSubscriptionID
				From
           			dbo.TempEmployeeSubscription

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEmployeeSubscription''
  ,@ToTable =''EmployeeSubscription''
  ,@CompanyId = '+@ToCompany+'


		End
		';
            EXEC (@sql);
			-- insert '+@ToDB+'.dbo.EmployeeSubscription
			-- (
			-- 	EmployeeSubscriptionId,
			-- 	MessageTemplateTypeID,
			-- 	EmployeeID,

			-- 	EmployeeIdCreated,
			-- 	EmployeeIdUpdated,
			-- 	DateCreated,
			-- 	DateUpdated
			-- 	,EmployeeSubscription_cs_companyid
			-- )
			-- Select
			-- 	newEmployeeSubscriptionId                ,
			-- 	MessageTemplateTypeID,
			-- 	EmployeeID,

			-- 	EmployeeIdCreated,
			-- 	EmployeeIdUpdated,
			-- 	DateCreated,
			-- 	DateUpdated
			-- 	,'+@ToCompany+' as cs_companyid
			-- From
			-- 	dbo.TempEmployeeSubscription

            print 'Insert EmployeeSubscriptionCriteria'
            SET @sql = '
		  Select next value for seq_EmployeeSubscriptionCriteria over (order by ESTSC.EmployeeSubscriptionCriteriaid) as newEmployeeSubscriptionCriteriaid, ESTSC.*
		  into dbo.TempEmployeeSubscriptionCriteria
		  from '+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria ESTSC
		  inner join TempEmployeeSubscription r  on ESTSC.EmployeeSubscriptionId = r.EmployeeSubscriptionId


		  update TempEmployeeSubscriptionCriteria
		  set EmployeeSubscriptionId = -3 where EmployeeSubscriptionId <> 0
		  and EmployeeSubscriptionId is not null

		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.EmployeeSubscriptionId = ulk.oldid
		  where
				trwo.EmployeeSubscriptionId = -3 and ulk.tablename = ''EmployeeSubscription''

				/* Fred email on 20170120
				WHEN CriteriaType = 1 THEN ExternalId=PropertyID
				WHEN CriteriaType = 2 THEN ExternalId=BuildingId
				WHEN CriteriaType = 3 THEN ExternalId=TenantId
				WHEN CriteriaType = 4 THEN ExternalId=RequestTypeId
				ELSE ''

				*/

		update TempEmployeeSubscriptionCriteria
		set ExternalID = -3

		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.externalId = ulk.oldid
		  where
				trwo.externalId = -3 and ulk.tablename = ''Property''
				and trwo.CriteriaType = 1


		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.externalId = ulk.oldid
		  where
				trwo.externalId = -3 and ulk.tablename = ''Building''
				and trwo.CriteriaType = 2

		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.externalId = ulk.oldid
		  where
				trwo.externalId = -3 and ulk.tablename = ''Tenantid''
				and trwo.CriteriaType = 3

		  update trwo
		  set trwo.EmployeeSubscriptionId = ulk.[NewId]
		  From
				'+@ToDB+'.dbo.TempEmployeeSubscriptionCriteria trwo with (nolock) inner join
				'+@Fromserver+'.'+@FromDB+'.dbo.EmployeeSubscriptionCriteria Ftrwo on trwo.EmployeeSubscriptionCriteriaID = Ftrwo.EmployeeSubscriptionCriteriaID inner join
				'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrwo.externalId = ulk.oldid
		  where
				trwo.externalId = -3 and ulk.tablename = ''RequestType''
				and trwo.CriteriaType = 4

select * from TempEmployeeSubscriptionCriteria where EmployeeSubscriptionId
 not in (Select EmployeeSubscriptionId from EmployeeSubscription)

delete from  TempEmployeeSubscriptionCriteria where EmployeeSubscriptionId
not in (Select EmployeeSubscriptionId from EmployeeSubscription)

		  if exists (select * from TempEmployeeSubscriptionCriteria) Begin
			 Insert  dbo.'+@lookup+'
				(
    				    TableName,
        			    ColumnName,
        			    OldId,
        			    [NewId]
				)
				Select
        			    ''EmployeeSubscriptionCriteria'',
        			    ''EmployeeSubscriptionCriteriaID'',
        			    EmployeeSubscriptionCriteriaID,
        			    NewEmployeeSubscriptionCriteriaID
				From
           			   dbo.TempEmployeeSubscriptionCriteria



---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEmployeeSubscriptionCriteria''
  ,@ToTable =''EmployeeSubscriptionCriteria''
  ,@CompanyId = '+@ToCompany+'


		  End
		  '
            exec (@sql);
			--  insert '+@ToDB+'.dbo.EmployeeSubscriptionCriteria
			--  (
			-- 	EmployeeSubscriptionCriteriaId,
			-- 	[EmployeeSubscriptionId]   ,
			-- 	[CriteriaType] ,
			-- 	[ExternalId]
			-- 	,EmployeeSubscriptionCriteria_cs_companyid
			--  )
			--  Select
			-- 	NewEmployeeSubscriptionCriteriaId,
			-- 	[EmployeeSubscriptionId]   ,
			-- 	[CriteriaType] ,
			-- 	[ExternalId]
			-- 	,'+@ToCompany+' as cs_companyid

			--  From
			-- 	dbo.TempEmployeeSubscriptionCriteria

        end;
        --SELECT @maxid = MAX(Equipmentid) + 10
        --FROM dbo.Equipment;
        PRINT 'Insert Equipment';
        SET @sql = '

Select next value for seq_Equipment over (order by eq.equipmentid) as newEquipmentId, eq.*
into dbo.TempEquipment
from '+@Fromserver+'.'+@FromDB+'.dbo.Equipment eq  inner join temparea a  on a.areaid = eq.areaid
--order by eq.equipmentid

update TempEquipment
set TempEquipment.areaid = temparea.newareaid
from temparea with (nolock)
where
    TempEquipment.areaid = temparea.areaid

update TempEquipment
set Equipmentclassid = [NewId]
from mapping with (nolock)
where tablename = ''Equipmentclass'' and equipmentclassid = fromid
and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

if exists (select * from dbo.tempequipment) 
Begin

	Update TempEquipment set EquipmentClassId = -3, AreaId = -3
	update eq
	set  eq.EquipmentClassId = ulk.[NewId]
	From
		'+@ToDB+'.dbo.TempEquipment eq with (nolock) inner join
		'+@Fromserver+'.'+@FromDB+'.dbo.Equipment Feq on eq.EquipmentId = Feq.EquipmentId inner join
		'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feq.EquipmentClassId = ulk.oldid
	where
		eq.EquipmentClassId = -3 and ulk.tablename = ''EquipmentClass''

	update eq
	set  eq.AreaId = ulk.[NewId]
	From
		'+@ToDB+'.dbo.TempEquipment eq with (nolock) inner join
		'+@Fromserver+'.'+@FromDB+'.dbo.Equipment Feq on eq.EquipmentId = Feq.EquipmentId inner join
		'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feq.AreaId = ulk.oldid
	where
		eq.AreaId = -3 and ulk.tablename = ''Area''

	update '+@ToDB+'.dbo.TempEquipment
	set  AssetCode  = ''''
	where [AssetCode] in (select [AssetCode] from dbo.equipment where AssetCode <> '''')

	Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Equipment'',
        	''EquipmentID'',
        	Equipmentid,
        	NewEquipmentID
        From
           	dbo.TempEquipment

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEquipment''
  ,@ToTable =''Equipment''
  ,@CompanyId = '+@ToCompany+'


----------------------------
/*
		-- Need to change June, 01, 2022
		--backfill Equipmentid for TR workorder with Equipmentid
Sample source:v3Angus	  Target:v3Equity_MI	 
Insert tr wo			newworkorderid 	oldworkorderid	Equipmentid	
							100				2				0	
										
after insert equipment		newequipmentid	oldequipmentId		
								291				103						
					
Logic: use lookup	link with v3Angus.workorder and	v3Equity_MI.workorder and	v3Equity_MI.equipment	
			100	2 0 , 103 291 -> newWOId=100 EquipmentID=103
*/
	Update newwo
	set Equipmentid = eq.newEquipmentId
	from '+@ToDB+'.dbo.workorder newwo
	inner join '+@ToDB+'.dbo.'+@lookup+' as ulk on newwo.workorderid = ulk.[NewId]
	inner join '+@FromDB+'.dbo.workorder oldwo on ulk.OldId=oldwo.workorderid
	inner join '+@ToDB+'.dbo.tempEquipment eq on eq.equipmentid = oldwo.equipmentid
	where 
		ulk.tablename = ''Workorder''
		and oldwo.equipmentId>0 
		and oldwo.WoType=''TR''
----------------------------

End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Equipment
    --     (
    --         EquipmentId          ,
    --         EquipmentClassId     ,
    --         AreaId               ,
    --         IsActiveEquipment    ,
    --         DateWarrantyExpires  ,
    --         EquipmentDescription ,
    --         EquipmentMake        ,
    --         EquipmentModel       ,
    --         EquipmentSN          ,
    --         EquipmentAssetCode   ,
    --         EquipmentDetail      ,
    --         tmpEquipmentId,
	-- 		Equipment_cs_companyid,
    --         AssetCode 
    --         ,EquipmentDateInstall 
    --         ,EquipmentInstallCost 
    --         ,EquipmentReplacementCost 
    --         ,EquipmentCondition 
    --         ,EstimatedUsefulLife
    --         ,LastAssessmentComment 
    --         ,LastAssessmentDate 
    --         ,IsConditionValid

    --     )
    -- select
    --         newEquipmentId          ,
    --         EquipmentClassId     ,
    --         AreaId               ,
    --         IsActiveEquipment    ,
    --         DateWarrantyExpires  ,
    --         EquipmentDescription ,
    --         EquipmentMake        ,
    --         EquipmentModel       ,
    --         EquipmentSN          ,
    --         EquipmentAssetCode   ,
    --         EquipmentDetail      ,
    --         -1
	-- 		,'+@ToCompany+' as cs_companyid
    --         ,AssetCode 
    --         ,EquipmentDateInstall 
    --         ,EquipmentInstallCost 
    --         ,EquipmentReplacementCost 
    --         ,EquipmentCondition 
    --         ,EstimatedUsefulLife
    --         ,LastAssessmentComment 
    --         ,LastAssessmentDate 
    --         ,IsConditionValid
    -- from
    --     dbo.tempEquipment

		 PRINT 'Insert EquipmentHistory without WO';
        SET @sql = '

Select next value for seq_EquipmentHistory over (order by eq.EquipmentHistoryId) as newEquipmentHistoryId, eq.*
into dbo.TempEquipmentHistory
from '+@Fromserver+'.'+@FromDB+'.dbo.EquipmentHistory eq  
inner join tempEquipment a on a.equipmentId = eq.equipmentId
where eq.workorderid = 0 

update TempEquipmentHistory
set TempEquipmentHistory.equipmentId = tempEquipment.newequipmentId
from tempEquipment with (nolock)
where
    TempEquipmentHistory.equipmentId = tempEquipment.equipmentId


if exists (select * from dbo.tempEquipmentHistory) Begin

Update TempEquipmentHistory set  equipmentId = -3
where equipmentid <> 0 

update eq
set  eq.equipmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEquipmentHistory eq with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EquipmentHistory Feq on eq.EquipmentHistoryId = Feq.EquipmentHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feq.equipmentId = ulk.oldid
where
	eq.equipmentId = -3 and ulk.tablename = ''Equipment''

	Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EquipmentHistory'',
        	''EquipmentHistoryID'',
        	EquipmentHistoryid,
        	NewEquipmentHistoryID
        From
           	dbo.TempEquipmentHistory

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEquipmentHistory''
  ,@ToTable =''EquipmentHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.EquipmentHistory      
    --        (
	-- 	   [EquipmentHistoryId]
    --        ,[EquipmentId]
    --        ,[WorkorderId]
    --        ,[EquipmentCondition]
    --        ,[IsConditionValid]
    --        ,[EstimatedUsefulLife]
    --        ,[LastAssessmentComment]
    --        ,[DateUpdated]
    --        ,[EquipmentHistory_CS_CompanyId]
	-- 	   )
    -- select
    --          [newEquipmentHistoryId]
    --        ,[EquipmentId]
    --        ,[WorkorderId]
    --        ,[EquipmentCondition]
    --        ,[IsConditionValid]
    --        ,[EstimatedUsefulLife]
    --        ,[LastAssessmentComment]
    --        ,[DateUpdated]
    --        ,'+@ToCompany+' as [EquipmentHistory_CS_CompanyId]

    -- from
    --     dbo.tempEquipmentHistory

        PRINT 'Insert Gauge';
        SET @sql = '
Select next value for seq_Gauge over (order by ga.Gaugeid) as newGaugeid, ga.*
into dbo.TempGauge
from '+@Fromserver+'.'+@FromDB+'.dbo.Gauge ga  inner join tempEquipment a  on a.Equipmentid = ga.Equipmentid
--order by ga.Gaugeid

update TempGauge
set TempGauge.EquipmentId = tempEquipment.newEquipmentId
from tempEquipment with (nolock)
where
    TempGauge.EquipmentId = tempEquipment.EquipmentId

update TempGauge
set TempGauge.EmployeeIdUpdated = tempce.newEmployeeId
from
    TempGauge with (nolock) inner join tempce with (nolock)
on
    TempGauge.EmployeeIdUpdated = tempce.EmployeeId


update TempGauge
set TempGauge.EmployeeIdCreated = tempce.newEmployeeId
from
    TempGauge with (nolock) inner join tempce with (nolock)
on
    TempGauge.EmployeeIdCreated = tempce.EmployeeId

if exists (select * from dbo.tempGauge) Begin

Update TempGauge set EmployeeIdUpdated = -3 where EmployeeIDUpdated <>0
Update TempGauge set EquipmentId = -3 where EquipmentId <> 0
Update TempGauge set EmployeeIdCreated = -3 where EmployeeIDCreated <> 0

update ga
set  ga.EquipmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempGauge ga with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Gauge Fga on ga.GaugeId = Fga.GaugeId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fga.EquipmentId = ulk.oldid
where
	ga.EquipmentId = -3 and ulk.tablename = ''Equipment''

update tempGauge
set tempGauge.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempGauge with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Gauge Fga on tempGauge.GaugeId = Fga.GaugeId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fga.EmployeeIdUpdated = ulk.oldid
where
	tempGauge.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

update tempGauge
set tempGauge.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempGauge with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Gauge Fga on tempGauge.GaugeId = Fga.GaugeId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fga.EmployeeIdCreated = ulk.oldid
where
	tempGauge.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update TempGauge
set EmployeeIdUpdated = 0
where
	EmployeeIdUpdated not in (Select employeeID from employee)

update TempGauge
set EmployeeIdCreated = 0
where
	EmployeeIdCreated not in (Select employeeID from employee)

	Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Gauge'',
        	''GaugeID'',
        	Gaugeid,
        	NewGaugeID
        From
           	dbo.TempGauge


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempGauge''
  ,@ToTable =''Gauge''
  ,@CompanyId = '+@ToCompany+'


End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Gauge
    --     (
    --         GaugeId,
    --         EquipmentId,
    --         GaugeTitle,
    --         GaugeUnitId,
    --         MinValue,
    --         MaxValue,
    --         DateLastCalibration,
    --         GaugeMeasurementFrequencyId,
    --         NumberOfPreviousReadings,
    --         DateCreated,
    --         DateUpdated,
    --         EmployeeIdCreated,
    --         EmployeeIdUpdated,
    --         GaugeType
	-- 		,Gauge_cs_companyid
    --     )
    -- select
    --         newGaugeId          ,
    --         EquipmentId,
    --         GaugeTitle,
    --         GaugeUnitId,
    --         MinValue,
    --         MaxValue,
    --         DateLastCalibration,
    --         GaugeMeasurementFrequencyId,
    --         NumberOfPreviousReadings,
    --         DateCreated,
    --         DateUpdated,
    --         EmployeeIdCreated,
    --         EmployeeIdUpdated,
    --         GaugeType
	-- 		,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempGauge


        PRINT 'Insert EquipAttachment';
        SET @sql = '
Select next value for seq_EquipAttachment over (order by eqatt.equipAttachmentid) as newequipAttachmentid, eqatt.*
into dbo.TempEquipAttachment
--from '+@Fromserver+'.'+@FromDB+'.dbo.EquipAttachment eqatt  inner join tempEquipment a  on a.Equipmentid = eqatt.Equipmentid
from '+@Fromserver+'.'+@FromDB+'.dbo.View_EquipAttachment eqatt  inner join tempEquipment a  on a.Equipmentid = eqatt.Equipmentid
--order by eqatt.equipAttachmentid

update TempEquipAttachment
set Equipmentid = -3
where
	EquipmentID <> 0


update TempEquipAttachment
set EmployeeId = -3
where
	(EmployeeId <> 0 	and employeeId is not null)

update eqatt
set  eqatt.EquipmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempEquipAttachment eqatt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EquipAttachment Feqatt on eqatt.EquipAttachmentId = Feqatt.EquipAttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feqatt.EquipmentId = ulk.oldid
where
	eqatt.EquipmentId = -3 and ulk.tablename = ''Equipment''


update eqatt
set  eqatt.EmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempEquipAttachment eqatt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EquipAttachment Feqatt on eqatt.EquipAttachmentId = Feqatt.EquipAttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feqatt.EquipmentId = ulk.oldid
where
	eqatt.EmployeeId = -3 and ulk.tablename = ''Employee''


if exists (select * from dbo.tempequipattachment) Begin
    Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EquipAttachment'',
        	''EquipAttachmentID'',
        	EquipAttachmentid,
        	NewEquipAttachmentID
        From
           	dbo.TempEquipAttachment

			select * from TempEquipAttachment
			where EmployeeId not in (Select employeeid from Employee)

			 Update TempEquipAttachment
			 set Employeeid = 0
			where EmployeeId not in (Select employeeid from Employee)

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEquipAttachment''
  ,@ToTable =''EquipAttachment''
  ,@CompanyId = '+@ToCompany+'
  

End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.EquipAttachment
    --     (   [EquipAttachmentId]
    --        ,[EquipmentId]
    --        ,[FileName]
    --        ,[FileType]
    --        ,[FileLength]
    --        ,[FileDescription]
    --        ,[FileData]
    --        ,[DateCreated]
    --        ,[EmployeeId]
	-- 	   ,equipAttachment_cs_companyid
	-- 	   ,isResized
    --     )
    -- select
    --         newEquipAttachmentId
    --        ,[EquipmentId]
    --        ,[FileName]
    --        ,[FileType]
    --        ,[FileLength]
    --        ,[FileDescription]
    --        ,[FileData]
    --        ,[DateCreated]
	-- 	   ,[EmployeeId]
	-- 	   ,'+@ToCompany+' as cs_companyid
	-- 	   ,isResized
    -- from
    --     dbo.tempEquipAttachment

        PRINT 'Insert EquipmentReference';
        SET @sql = '

Select next value for seq_EquipmentReference over (order by eq.EquipmentReferenceId) as newEquipmentReferenceId, eq.*
into dbo.TempEquipmentReference
from '+@Fromserver+'.'+@FromDB+'.dbo.EquipmentReference eq  inner join tempEquipment a  on a.EquipmentId = eq.EquipmentId


update TempEquipmentReference
set EquipmentId = -3
where EquipmentId <> 0


if exists (select * from dbo.tempEquipmentReference) Begin


update eq
set  eq.EquipmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEquipmentReference eq with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EquipmentReference Feq on eq.EquipmentReferenceId = Feq.EquipmentReferenceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feq.EquipmentId = ulk.oldid
where
	eq.EquipmentId = -3 and ulk.tablename = ''Equipment''


	Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EquipmentReference'',
        	''EquipmentReferenceID'',
        	EquipmentReferenceid,
        	NewEquipmentReferenceID
        From
           	dbo.TempEquipmentReference

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEquipmentReference''
  ,@ToTable =''EquipmentReference''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.EquipmentReference
    --     (
    --        [EquipmentReferenceId]
    --        ,[EquipmentId]
    --        ,[Reference]
    --        ,[IsActiveEquipmentReference]
    --        ,[Description]
	-- 	   ,EquipmentReference_cs_companyid
    --     )
    -- select
    --         newEquipmentReferenceId
    --        ,[EquipmentId]
    --        ,[Reference]
    --        ,[IsActiveEquipmentReference]
    --        ,[Description]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempEquipmentReference


        -- if @@error != 0 rollback tran
        PRINT 'Insert PM Schedule';
        SET @sql = '
Select next value for seq_Schedule over (order by sc.scheduleid) as newscheduleid, sc.*
into dbo.TempSchedule
From
    dbo.TempEquipment teq  inner join '+@Fromserver+'.'+@FromDB+'.dbo.Schedule sc  on teq.equipmentid = sc.equipmentid
where sc.requestid is null
--order by sc.scheduleid

update dbo.TempSchedule
set dbo.TempSchedule.equipmentid = newequipmentid
from dbo.TempEquipment with (nolock)
where dbo.TempSchedule.equipmentid = dbo.TempEquipment.equipmentid

update dbo.TempSchedule
set dbo.TempSchedule.EmployeeIdAssigned = tempce.newemployeeid
from
    dbo.TempSchedule with (nolock) inner join tempce with (nolock) on dbo.TempSchedule.EmployeeIdAssigned = tempce.employeeid


if exists (select * from dbo.TempSchedule) Begin
Update TempSchedule set EquipmentId = -3, EmployeeIdAssigned = -3, requestid = case when requestid is not null then -3 else requestid end

update sc
set  sc.EquipmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempSchedule sc with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Schedule Fsc on sc.Scheduleid = Fsc.Scheduleid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fsc.EquipmentId = ulk.oldid
where
	sc.EquipmentId = -3 and ulk.tablename = ''Equipment''

update sc
set  sc.EmployeeIdAssigned = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempSchedule sc with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Schedule Fsc on sc.Scheduleid = Fsc.Scheduleid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fsc.EmployeeIdAssigned = ulk.oldid
where
	sc.EmployeeIdAssigned = -3 and ulk.tablename = ''Employee''

---??? we have just PM Schedule and all RequestID is Null
update sc
set  sc.RequestId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempSchedule sc with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Schedule Fsc on sc.Scheduleid = Fsc.Scheduleid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fsc.RequestId = ulk.oldid
where
	sc.RequestId = -3 and ulk.tablename = ''Request''
-------
	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Schedule'',
        	''ScheduleID'',
        	Scheduleid,
        	NewScheduleID
        From
           	dbo.TempSchedule

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempSchedule''
  ,@ToTable =''Schedule''
  ,@CompanyId = '+@ToCompany+'


End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Schedule
    --     (
    --         ScheduleId,
    --         EquipmentId,
    --         EmployeeIdAssigned,
    --         RequestId,
    --         Priority,
    --         Period,
    --         PeriodType,
    --         ScheduleType,
    --         TimeOfDay,
    --         DateStart,
    --         DateEnd,
    --         CheckMissingValues,
    --         IsActiveSchedule,
    --         IsMonthlyByDay,
    --         DayOfMonth,
    --         DispatchTimeOfDay,
    --         WeekOfMonth,
    --         DayOfWeek,
    --         SeasonStart,
    --         SeasonEnd,
    --         ScheduleDescription,
    --         WoDescription,
    --         ScheduleDetail,
    --         DispatchDays,
    --         DispatchHours,
    --         tmpScheduleId,
	-- 		schedule_cs_companyid

    --     )
    -- SELECT
    --         NEWScheduleId          ,
    --         EquipmentId         ,
    --         EmployeeIdAssigned  ,
    --         case when requestid is not null then -3 else requestid end,
    --         Priority,
    --         Period,
    --         PeriodType,
    --         ScheduleType,
    --         TimeOfDay,
    --         DateStart,
    --         DateEnd,
    --         CheckMissingValues,
    --         IsActiveSchedule,
    --         IsMonthlyByDay,
    --         DayOfMonth,
    --         DispatchTimeOfDay,
    --         WeekOfMonth,
    --         DayOfWeek,
    --         SeasonStart,
    --         SeasonEnd,
    --         ScheduleDescription,
    --         WoDescription,
    --         ScheduleDetail,
    --         DispatchDays,
    --         DispatchHours,
    --         -1
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
    --     dbo.TempSchedule

        PRINT 'Insert Task';
        IF(@IsCorpTask = 0)
                     BEGIN
            SET @sql = '
Select next value for seq_Task over (order by tk.taskid) as newTaskid, tk.*
into dbo.TempTask
From
    '+@Fromserver+'.'+@FromDB+'.dbo.task tk
where tk.propertyid in '+@FromProperty+'
--order by tk.taskid

update TempTask
set TempTask.tradeid = mapping.[NewId]
from
    mapping with (nolock)
where
    TempTask.tradeid = mapping.fromid
and
   mapping.tablename = ''trade''
   and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update temptask
set companyid = '+@ToCompany+'

Update tempTask
set Impairmentid  = b.[newid]
from
    tempTask tt with (nolock) inner join mapping b with (nolock)
on
    tt.Impairmentid = b.fromid
where
    b.tablename = ''Impairment''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update temptask
set
    temptask.propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    temptask.propertyid = tempproperty.propertyid

if exists (select * from temptask) Begin

Update tempTask set PropertyId = -3, TradeId =-3
update tk
set  tk.PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempTask tk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.task Ftk on tk.taskid = Ftk.taskid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftk.PropertyId = ulk.oldid
where
	tk.PropertyId = -3 and ulk.tablename = ''Property''

update tk
set  tk.TradeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempTask tk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.task Ftk on tk.taskid = Ftk.taskid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftk.TradeId = ulk.oldid
where
	tk.TradeId = -3 and ulk.tablename = ''Trade''


	
update tempTask
set TempTask.newTaskId = mapping.[NewId]
from
    mapping with (nolock)
where
    TempTask.TaskId = mapping.fromid
and
   mapping.tablename = ''Task''
   and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Task'',
        	''TaskID'',
        	Taskid,
        	NewTaskID
        From
           	dbo.tempTask


while exists (
SELECT MIN(taskid) FROM temptask
group by Propertyid, taskDescription
having count(*) > 1
)
begin
Update temptask
set TaskDescription = left(TaskDescription,40) + convert(varchar(10),taskid)
from tempTask
where taskid in
(
select min(taskid) from temptask
group by Propertyid, taskDescription
having count(*) > 1
)

end

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempTask''
  ,@ToTable =''task''
  ,@CompanyId = '+@ToCompany+'


End
';
    -- insert '+@ToDB+'.dbo.task
    --     (
    --         TaskId           ,
    --         CompanyId        ,
    --         PropertyId       ,
    --         TradeId          ,
    --         IsActiveTask     ,
    --         MinutesEstimated ,
    --         Period           ,
    --         PeriodType       ,
    --         TaskDescription  ,
    --         TaskDetail       ,
	-- 		tmpTaskId     ,
	-- 		ImpairmentId,
	-- 		task_cs_companyid,
    --         IsAssessmentTask
    --     )
    -- select
    --         newTaskId           ,
    --         CompanyId        ,
    --         PropertyId       ,
    --         TradeId          ,
    --         IsActiveTask     ,
    --         MinutesEstimated ,
    --         Period           ,
    --         PeriodType       ,
    --         TaskDescription  ,
    --         TaskDetail       ,
	-- 		-1,
	-- 		ImpairmentId
	-- 		,'+@ToCompany+' as cs_companyid
    --         ,IsAssessmentTask
        
    -- From
    --         dbo.temptask
	-- 		where newTaskId not in (select taskId from Task)
        END;
        IF(@IsCorpTask = 1)
                     BEGIN
            SET @sql = '
Select next value for seq_Task over (order by tk.taskid) as newTaskid, tk.*
into dbo.TempTask
From
    '+@Fromserver+'.'+@FromDB+'.dbo.task tk
where tk.propertyid in '+@FromProperty+' or 
(tk.PropertyID= 0 and tk.Companyid = '+@FromCompany+'
  and tk.taskid in 
    (
    select taskid from '+@Fromserver+'.'+@FromDB+'.dbo.schedtask stk  inner join tempschedule  on stk.scheduleid = tempschedule.scheduleid
    Union
    Select WoTask.taskid from '+@Fromserver+'.'+@FromDB+'.dbo.WoTask AS WoTask 
        INNER JOIN     '+@Fromserver+'.'+@FromDB+'.dbo.WorkOrder as WorkOrder ON WoTask.WorkOrderId = WorkOrder.WorkOrderId 
        INNER JOIN     '+@Fromserver+'.'+@FromDB+'.dbo.Building as Building ON WorkOrder.BuildingId = Building.BuildingId 
        inner join     '+@Fromserver+'.'+@FromDB+'.dbo.Task as Task on wotask.taskid = task.taskid
       WHERE (Building.PropertyId IN '+@FromProperty+')
       and wotask.taskid not in
       (Select taskid from '+@Fromserver+'.'+@FromDB+'.dbo.task where PropertyId IN '+@FromProperty+')
        and task.Propertyid = 0 and task.companyid ='+@FromCompany+'
    )
)

--and tk.taskid in
--(
--    SELECT tk1.taskid FROM '+@Fromserver+'.'+@FromDB+'.dbo.task tk1 WHERE tk1.taskid IN 
--    (
--        select distinct taskid from '+@Fromserver+'.'+@FromDB+'.dbo.schedtask 
--        where schedtaskid in
--        (
--          SELECT     SchedTask.schedtaskId
--          FROM         '+@Fromserver+'.'+@FromDB+'.dbo.SchedTask INNER JOIN
--                                '+@Fromserver+'.'+@FromDB+'.dbo.Schedule ON SchedTask.ScheduleId = Schedule.ScheduleId INNER JOIN
--                                '+@Fromserver+'.'+@FromDB+'.dbo.Equipment ON Schedule.EquipmentId = Equipment.EquipmentId INNER JOIN
--                                '+@Fromserver+'.'+@FromDB+'.dbo.Area ON Equipment.AreaId = Area.AreaId INNER JOIN
--                                '+@Fromserver+'.'+@FromDB+'.dbo.Building ON Area.BuildingId = Building.BuildingId
--          WHERE     Building.PropertyId IN '+@FromProperty+'
--          and
--           taskid not in (Select taskid from '+@Fromserver+'.'+@FromDB+'.dbo.task where propertyid in '+@FromProperty+')
--        )
    
-- ) and propertyid = 0 
--)

--order by tk.taskid


update TempTask
set TempTask.tradeid = mapping.[NewId]
from
    mapping with (nolock)
where
    TempTask.tradeid = mapping.fromid
and
   mapping.tablename = ''trade''
   and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update temptask
set companyid = '+@ToCompany+'


Update tempTask
set Impairmentid  = b.[newid]
from
    tempTask tt with (nolock) inner join mapping b with (nolock)
on
    tt.Impairmentid = b.fromid
where
    b.tablename = ''Impairment''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'


update temptask
set
    temptask.propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    temptask.propertyid = tempproperty.propertyid

if exists (select * from temptask) Begin

Update tempTask set PropertyId = -3 where PropertyId <> 0

Update tempTask set TradeId =-3

update tk
set  tk.PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempTask tk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.task Ftk on tk.taskid = Ftk.taskid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftk.PropertyId = ulk.oldid
where
	tk.PropertyId = -3 and ulk.tablename = ''Property''

update tk
set  tk.TradeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempTask tk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.task Ftk on tk.taskid = Ftk.taskid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftk.TradeId = ulk.oldid
where
	tk.TradeId = -3 and ulk.tablename = ''Trade''


	
update tempTask
set TempTask.newTaskId = mapping.[NewId]
from
    mapping with (nolock)
where
    TempTask.TaskId = mapping.fromid
and
   mapping.tablename = ''Task''
   and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'
-----?????
-- mark the corp task to property level if just one Property Make unComment
--update temptask
--set
--    temptask.propertyid = (select top 1 newpropertyid from tempProperty)
--where
--    temptask.propertyid = 0

	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Task'',
        	''TaskID'',
        	Taskid,
        	NewTaskID
        From
           	dbo.tempTask


while exists (
SELECT MIN(taskid) FROM temptask
group by Propertyid, taskDescription
having count(*) > 1
)
begin
Update temptask
set TaskDescription = left(TaskDescription,40) + convert(varchar(10),taskid)
from tempTask
where taskid in
(
select min(taskid) from temptask
group by Propertyid, taskDescription
having count(*) > 1
)

end


    insert '+@ToDB+'.dbo.task
        (
            TaskId           ,
            CompanyId        ,
            PropertyId       ,
            TradeId          ,
            IsActiveTask     ,
            MinutesEstimated ,
            Period           ,
            PeriodType       ,
            TaskDescription  ,
            TaskDetail       ,
			tmpTaskId     ,
			ImpairmentId
			,task_cs_companyid
            ,IsAssessmentTask
        )
    select
            newTaskId           ,
            CompanyId        ,
            PropertyId       ,
            TradeId          ,
            IsActiveTask     ,
            MinutesEstimated ,
            Period           ,
            PeriodType       ,
            TaskDescription  ,
            TaskDetail       ,
			-1,
			ImpairmentId
			,'+@ToCompany+' as task_cs_companyid
            ,IsAssessmentTask
    From
            dbo.temptask
			where newTaskId not in (select taskId from Task)
End
';
        END;
        EXEC (@sql);

        PRINT 'Insert SchedTask';
        SET @sql = '
Select next value for seq_SchedTask over (order by stk.SchedTaskId) as newSchedTaskId, stk.*
into dbo.TempSchedTask
from '+@Fromserver+'.'+@FromDB+'.dbo.schedtask stk  inner join tempschedule  on stk.scheduleid = tempschedule.scheduleid
--order by stk.schedtaskid

update tempschedtask
set tempschedtask.taskid = temptask.newtaskid
from
    temptask with (nolock)
where
    tempschedtask.taskid = temptask.taskid

update tempschedtask
set tempschedtask.scheduleid = tempschedule.newscheduleid
from
    tempschedule with (nolock)
where
    tempschedtask.scheduleid = tempschedule.scheduleid

if exists (select * from tempschedtask) begin

update tempschedtask set ScheduleId = -3, TaskId = -3
update stk
set  stk.TaskId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempschedtask stk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SchedTask Fstk on stk.SchedTaskId = Fstk.SchedTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fstk.TaskId = ulk.oldid
where
	stk.TaskId = -3 and ulk.tablename = ''Task''

update stk
set  stk.ScheduleId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempschedtask stk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SchedTask Fstk on stk.SchedTaskId = Fstk.SchedTaskId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fstk.ScheduleId = ulk.oldid
where
	stk.ScheduleId = -3 and ulk.tablename = ''Schedule''

	  insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''schedTask'',
        	''schedTaskID'',
        	schedTaskid,
        	NewschedTaskID
        From
            tempschedtask

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempschedtask''
  ,@ToTable =''Schedtask''
  ,@CompanyId = '+@ToCompany+'
  

end
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Schedtask
    --     (
    --         SchedTaskId      ,
    --         ScheduleId       ,
    --         TaskId           ,
    --         IsBaseTask       ,
    --         Multiplier       ,
    --         Offset           ,
    --         MinutesEstimated ,
    --         tmpscheduleid    ,
	-- 		tmptaskid
	-- 		,Schedtask_cs_companyid
    --     )
    -- select
    --         newSchedTaskId      ,
    --         ScheduleId       ,
    --         TaskId           ,
    --         IsBaseTask       ,
    --         Multiplier       ,
    --         Offset           ,
    --         MinutesEstimated ,
    --         -1,
    --         -1
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
	--         Tempschedtask

        PRINT 'Insert TaskLine';
        SET @sql = '
Select next value for seq_Taskline over (order by tkl.tasklineid) as newtasklineId, tkl.*
into dbo.Temptaskline
from '+@Fromserver+'.'+@FromDB+'.dbo.taskline tkl  inner join dbo.temptask  on tkl.taskid = temptask.taskid
--order by tkl.tasklineid

update dbo.temptaskline
set dbo.temptaskline.taskid = dbo.temptask.newtaskid
from
    dbo.temptask with (nolock)
where
    dbo.temptaskline.taskid = dbo.temptask.taskid

if exists (select * from temptaskline) begin

update temptaskline set TaskId = -3
update tkl
set  tkl.TaskId = ulk.[NewId]
From
	'+@ToDB+'.dbo.temptaskline tkl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Taskline Ftkl on tkl.TasklineId = Ftkl.TasklineId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftkl.TaskId = ulk.oldid
where
	tkl.TaskId = -3 and ulk.tablename = ''Task''

	 insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''TaskLine'',
        	''TaskLineID'',
        	Tasklineid,
        	NewTaskLineID
        From
            temptaskline

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''temptaskline''
  ,@ToTable =''Taskline''
  ,@CompanyId = '+@ToCompany+'

end
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Taskline
    --     (
    --         TaskLineId       ,
    --         TaskLineSequence ,
    --         TaskId           ,
    --         TaskLineType     ,
    --         TaskLineDetail   ,
    --         tmpTaskLineId
	-- 		,taskline_cs_companyid
    --     )
    -- select
    --         newTaskLineId       ,
    --         TaskLineSequence ,
    --         TaskId,
    --         TaskLineType     ,
    --         TaskLineDetail   ,
    --         -1
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
    --     temptaskline

        PRINT 'Insert SchedItem';
        SET @sql = '
Select next value for seq_SchedItem over (order by si.scheditemId) as newscheditemId, si.*
into dbo.tempscheditem
from
    '+@Fromserver+'.'+@FromDB+'.dbo.scheditem si  inner join tempschedule  on si.scheduleid = tempschedule.scheduleid
--order by si.scheditemid

update dbo.tempscheditem
set dbo.tempscheditem.scheduleid = tempschedule.newscheduleid
from
    tempschedule with (nolock)
where
    dbo.tempscheditem.scheduleid = tempschedule.scheduleid

if exists (select * from tempscheditem) begin

update tempscheditem set ScheduleId = -3
update stk
set  stk.ScheduleId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempscheditem stk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.scheditem Fstk on stk.SchedItemId = Fstk.SchedItemId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fstk.ScheduleId = ulk.oldid
where
	stk.ScheduleId = -3 and ulk.tablename = ''Schedule''

	 insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''SchedItem'',
        	''ScheditemID'',
        	ScheditemID,
        	NewScheditemID
        From
            tempscheditem

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempscheditem''
  ,@ToTable =''scheditem''
  ,@CompanyId = '+@ToCompany+'


end
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.scheditem
    --     (
    --         SchedItemId      ,
    --         SchedItemSequence    ,
    --         ScheduleId           ,
    --         SchedItemDescription ,
    --         SchedItemLocation    ,
    --         SchedItemType        ,
    --         tmpScheduleItemId
	-- 		,scheditem_cs_companyid
    --     )
    -- select
    --         newSchedItemId          ,
    --         SchedItemSequence    ,
    --         ScheduleId,
    --         SchedItemDescription ,
    --         SchedItemLocation    ,
    --         SchedItemType        ,
    --         -1
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
    --     tempscheditem

        PRINT 'Insert Workorder PM';
        SET @sql = '
Select next value for seq_Document over (order by wo.workorderid) as newworkorderId, wo.*
into dbo.tempwo
from
    '+@Fromserver+'.'+@FromDB+'.dbo.workorder wo  inner join '+@Fromserver+'.'+@FromDB+'.dbo.building b  on b.buildingid = wo.buildingid
where b.propertyid in '+@FromProperty+' and wo.wotype = ''PM''
--order by wo.workorderid

update two
set two.areaid = m.newareaid
from
    tempwo two with (nolock) inner join temparea m with (nolock) on two.areaid = m.areaid

update tempwo
set
    tempwo.buildingid = tempbuilding.newbuildingid
from
    tempbuilding with (nolock)
where
    tempwo.buildingid = tempbuilding.buildingid

update tempwo
set tempwo.equipmentid = tempequipment.newequipmentid
from
    tempequipment with (nolock)
where
    tempwo.equipmentid = tempequipment.equipmentid

update tempwo
set tempwo.tradeid = mapping.[NewId]
from
    mapping with (nolock)
where
    tempwo.tradeid = mapping.fromid
and
    mapping.tablename = ''trade''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update tempwo
set tempwo.EmployeeIdAssigned = tempce.newEmployeeId
from
    tempwo with (nolock) inner join tempce with (nolock)
on
    tempwo.EmployeeIdAssigned = tempce.EmployeeId

update tempwo
set tempwo.EmployeeIdOwner = tempce.newEmployeeId
from
    tempwo with (nolock) inner join tempce with (nolock)
on
    tempwo.EmployeeIdOwner = tempce.EmployeeId


update tempwo
set tempwo.EmployeeIdRequested = tempce.newEmployeeId
from
    tempwo with (nolock) inner join tempce with (nolock)
on
    tempwo.EmployeeIdRequested = tempce.EmployeeId

update tempwo
set tempwo.EmployeeIdCreated = tempce.newEmployeeId
from
    tempwo with (nolock) inner join tempce with (nolock)
on
    tempwo.EmployeeIdCreated = tempce.EmployeeId

update tempwo
set tempwo.EmployeeIdUpdated = tempce.newEmployeeId
from
    tempwo with (nolock) inner join tempce with (nolock)
on
    tempwo.EmployeeIdUpdated = tempce.EmployeeId

update tempwo
set tempwo.scheduleid = tempschedule.newscheduleid
from
    tempschedule with (nolock)
where
    tempwo.scheduleid = tempschedule.scheduleid
';
        EXEC (@sql);
        SET @sql = '
Update tempwo set BuildingId = -3, AreaId = -3, TradeId = -3, EquipmentId = -3, scheduleid = case when scheduleid is null then scheduleid else -3 end, EmployeeIdAssigned = -3, EmployeeIdOwner = -3, EmployeeIdRequested = -3, ReservationId = case when ReservationId is null then ReservationId else -3 end, ResourceId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3,EmployeeIdDispatched =-3

update tempWO
set BulletinID = -3
where BulletinID is not null and BulletinID <> 0



update tempWO
set ReservationAmenityId = -3
where ReservationAmenityId is not null and ReservationAmenityId <> 0


update pmwo
set pmwo.ReservationAmenityId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.ReservationAmenityId = ulk.oldid
where
	pmwo.ReservationAmenityId = -3 and ulk.tablename = ''ReservationAmenity'' and pmwo.wotype = ''PM''


update pmwo
set pmwo.buildingid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.buildingid = ulk.oldid
where
	pmwo.buildingid = -3 and ulk.tablename = ''building'' and pmwo.wotype = ''PM''

update pmwo
set pmwo.AreaId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.AreaId = ulk.oldid
where
	pmwo.AreaId = -3 and ulk.tablename = ''Area'' and pmwo.wotype = ''PM''

update pmwo
set pmwo.TradeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.TradeId = ulk.oldid
where
	pmwo.TradeId = -3 and ulk.tablename = ''Trade'' and pmwo.wotype = ''PM''

update pmwo
set pmwo.EquipmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.EquipmentId = ulk.oldid
where
	pmwo.EquipmentId = -3 and ulk.tablename = ''Equipment'' and pmwo.wotype = ''PM''

update pmwo
set pmwo.ScheduleId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.ScheduleId = ulk.oldid
where
	pmwo.ScheduleId = -3 and ulk.tablename = ''Schedule'' and pmwo.wotype = ''PM''


update pmwo
set pmwo.EmployeeIdDispatched = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.EmployeeIdDispatched = ulk.oldid
where
	pmwo.EmployeeIdDispatched = -3 and ulk.tablename = ''Employee'' and pmwo.wotype = ''PM''

UPDATE 	dbo.tempwo SET EmployeeIdDispatched= 0 WHERE EmployeeIdDispatched = -3

update pmwo
set pmwo.EmployeeIdAssigned = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.EmployeeIdAssigned = ulk.oldid
where
	pmwo.EmployeeIdAssigned = -3 and ulk.tablename = ''Employee'' and pmwo.wotype = ''PM''

UPDATE 	dbo.tempwo SET EmployeeIdAssigned= 0 WHERE EmployeeIdAssigned = -3

update pmwo
set pmwo.EmployeeIdOwner = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.EmployeeIdOwner = ulk.oldid
where
	pmwo.EmployeeIdOwner = -3 and ulk.tablename = ''Employee'' and pmwo.wotype = ''PM''

	UPDATE 	dbo.tempwo SET EmployeeIdOwner= 0 WHERE EmployeeIdOwner = -3

update pmwo
set pmwo.EmployeeIdRequested = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.EmployeeIdRequested = ulk.oldid
where
	pmwo.EmployeeIdRequested = -3 and ulk.tablename = ''Employee'' and pmwo.wotype = ''PM''

UPDATE 	dbo.tempwo SET EmployeeIdRequested= 0 WHERE EmployeeIdRequested = -3

update pmwo
set pmwo.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.EmployeeIdCreated = ulk.oldid
where
	pmwo.EmployeeIdCreated = -3 and ulk.tablename = ''Employee'' and pmwo.wotype = ''PM''

UPDATE 	dbo.tempwo SET EmployeeIdCreated= 0 WHERE EmployeeIdCreated = -3

update pmwo
set pmwo.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.EmployeeIdUpdated = ulk.oldid
where
	pmwo.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee'' and pmwo.wotype = ''PM''

UPDATE 	dbo.tempwo SET EmployeeIdUpdated= 0 WHERE EmployeeIdUpdated = -3

update pmwo
set pmwo.ReservationId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.ReservationId = ulk.oldid
where
	pmwo.ReservationId = -3 and ulk.tablename = ''Reservation'' and pmwo.wotype = ''PM''

update pmwo
set pmwo.ResourceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.ResourceId = ulk.oldid
where
	pmwo.ResourceId = -3 and ulk.tablename = ''Resource'' and pmwo.wotype = ''PM''


update pmwo
set pmwo.BulletinID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwo pmwo with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder Fpmwo on pmwo.WorkorderId = Fpmwo.WorkorderId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmwo.BulletinID = ulk.oldid
where
	pmwo.BulletinID = -3 and ulk.tablename = ''Bulletin'' and pmwo.wotype = ''PM''

';
        EXEC (@sql);
        SET @sql = '
if exists (select * from tempwo) begin
    insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Workorder'',
        	''WorkorderID'',
        	workorderID,
        	NewWorkorderid
        From
            dbo.tempwo



INSERT INTO dbo.ArsWorkOrder (
	WorkOrderKey
		, workOrderId
		, db
		, dateUpdatedArs
		,arsworkorder_cs_companyid
	)
	SELECT
		next value for seq_ArsWorkOrder
		,newWorkorderId
		, db = DB_NAME()
		, GETDATE()
		,'+@ToCompany+' as cs_companyid
	FROM  dbo.tempwo


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
--  ,@FromTable =''temptempwo''
  ,@FromTable =''tempwo''
  ,@ToTable =''workorder''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);

    -- insert '+@ToDB+'.dbo.workorder
    --     (
    --         WorkOrderId	,
    --         DisplayId,
    --         SortId,
    --         DateWarrantyExpires,
    --         --EquipmentClassDescription_fr,

    --         BuildingId,
    --         WoType,
    --         WoStatus,
    --         AreaId,
    --         RequestId,
    --         ReservationId,
    --         EquipmentId,
    --         ScheduleId,
    --         TenantId,
    --         ContactId,
    --         LeaseId,
    --         EmployeeIdAssigned,
    --         EmployeeIdOwner,
    --         EmployeeIdRequested,
    --         RequestTypeId,
    --         TradeId,
    --         ResourceId,
    --         EstimateId,
    --         AddressId,
    --         DispatchHours,
    --         WoSequence,
    --         Priority,
    --         Todo,
    --         WoHistoryEvent,
    --         TimeResponse,
    --         TimeCompletion,
    --         TimeOverdue,
    --         EstimateStatus,

    --         InactiveLease,
    --         MissingLease,
    --         SnoozeLength,
    --         SnoozeUnit,
    --         --WoStatusDescription,
    --         WoDescription,
    --         DateScheduled,
    --         DateExpiry,
    --         DateReceived,
    --         DateOpened,
    --         DateAssigned,
    --         DateToDispatch,
    --         DateDispatched,
    --         DateDeliveryConfirmed,
    --         DateResponded,
    --         DateAccepted,
    --         DateWorkStarted,
    --         DateWorkCompleted,
    --         DateClosed,
    --         DateCancelled,
    --         DateVerified,
    --         DateReversed,
    --         DateToEscalate1,
    --         DateToEscalate2,
    --         DateToEscalate3,
    --         DateEscalated1,
    --         DateEscalated2,
    --         DateEscalated3,
    --         DateSnoozeUntil,
    --         IsWithMessages,
    --         IsCallAttention,
    --         IsAutoCancelled,
    --         IsMissingValues,
    --         IsRequestWithMessages,
    --         IsEscalated,
    --         IsPendingInvoice,
    --         IsProcessed,
    --         IsReviewRequired,
    --         IsEstimateRequired,
    --         ExternalAddressCode,
    --         ExternalAltAddressCode,
    --         --EquipmentClassDescription,
    --         EquipmentDescription,
    --         EquipmentMake,
    --         EquipmentModel,
    --         EquipmentSN,
    --         EquipmentAssetCode,
    --         EquipmentDetail,
    --         CustomerReferenceNumber,
    --         SecondaryContactName,
    --         SecondaryContactInfo,
    --         LocationNotes,
    --         LocationType,
    --         WorkOrderCustom1,
    --         WorkOrderCustom2,
    --         WorkOrderCustom3,
    --         WorkOrderCustom4,
    --         WorkOrderCustom5,
    --         CostAsset,
    --         WoDetail,
    --         EmployeeIdCreated,
    --         DateCreated,
    --         EmployeeIdUpdated,
    --         DateUpdated,
    --         tmpWorkOrderId,
    --         EmployeeIdDispatched,
    --         UnableToDispatch,
    --         TimeAcceptance  ,
    --         RequestSource ,
	-- 	  CompleteVersion,
	-- 	  [IsImpairment]  ,
	-- 	  [Reason]  ,
	-- 	  [Tag]   ,
	-- 	  [ConfirmImpairmentOnline]   ,
	-- 	  QRSRating,
	-- 	QRSComment,
	-- 	BulletinID,
	-- 	RatingSource,
	-- 	workorder_cs_companyid,
	-- 	ReservationAmenityId,
	-- 	DateScheduledKey
    --     )
    -- select
    --         newWorkOrderId               ,
    --         DisplayId,
    --         SortId,
    --         DateWarrantyExpires,
    --         --EquipmentClassDescription_fr,

    --         BuildingId,
    --         WoType,
    --         WoStatus,
    --         AreaId,
    --         RequestId,
    --         ReservationId,
    --         EquipmentId,
    --         ScheduleId,
    --         TenantId,
    --         ContactId,
    --         LeaseId,
    --         EmployeeIdAssigned,
    --         EmployeeIdOwner,
    --         EmployeeIdRequested,
    --         RequestTypeId,
    --         TradeId,
    --         ResourceId,
    --         EstimateId,
    --         AddressId,
    --         DispatchHours,
    --         WoSequence,
    --         Priority,
    --         Todo,
    --         WoHistoryEvent,
    --         TimeResponse,
    --         TimeCompletion,
    --         TimeOverdue,
    --         EstimateStatus,

    --         InactiveLease,
    --         MissingLease,
    --         SnoozeLength,
    --         SnoozeUnit,
    --         --WoStatusDescription,
    --         WoDescription,
    --         DateScheduled,
    --         DateExpiry,
    --         DateReceived,
    --         DateOpened,
    --         DateAssigned,
    --         DateToDispatch,
    --         DateDispatched,
    --         DateDeliveryConfirmed,
    --         DateResponded,
    --         DateAccepted,
    --         DateWorkStarted,
    --         DateWorkCompleted,
    --         DateClosed,
    --         DateCancelled,
    --         DateVerified,
    --         DateReversed,
    --         DateToEscalate1,
    --         DateToEscalate2,
    --         DateToEscalate3,
    --         DateEscalated1,
    --         DateEscalated2,
    --         DateEscalated3,
    --         DateSnoozeUntil,
    --         IsWithMessages,
    --         IsCallAttention,
    --         IsAutoCancelled,
    --         IsMissingValues,
    --         IsRequestWithMessages,
    --         IsEscalated,
    --         IsPendingInvoice,
    --         IsProcessed,
    --         IsReviewRequired,
    --         IsEstimateRequired,
    --         ExternalAddressCode,
    --         ExternalAltAddressCode,
    --         --EquipmentClassDescription,
    --         EquipmentDescription,
    --         EquipmentMake,
    --         EquipmentModel,
    --         EquipmentSN,
    --         EquipmentAssetCode,
    --         EquipmentDetail,
    --         CustomerReferenceNumber,
    --         SecondaryContactName,
    --         SecondaryContactInfo,
    --         LocationNotes,
    --         LocationType,
    --         WorkOrderCustom1,
    --         WorkOrderCustom2,
    --         WorkOrderCustom3,
    --         WorkOrderCustom4,
    --         WorkOrderCustom5,
    --         CostAsset,
    --         WoDetail,
    --         EmployeeIdCreated,
    --         DateCreated,
    --         EmployeeIdUpdated,
    --         DateUpdated,
    --         -1 ,
    --         EmployeeIdDispatched,
    --         UnableToDispatch,
    --         TimeAcceptance  ,
    --         RequestSource ,
	-- 	  CompleteVersion,
	-- 	  [IsImpairment]  ,
	-- 	  [Reason]  ,
	-- 	  [Tag]   ,
	-- 	  [ConfirmImpairmentOnline]   ,
	-- 	  QRSRating,
	-- 	QRSComment,
	-- 	BulletinID,
	-- 	RatingSource,
	-- 	'+@ToCompany+' as cs_companyid,
	-- 	ReservationAmenityId,
	-- 	DateScheduledKey
    -- from
    --     tempwo

		 PRINT 'Insert EquipmentHistory with WO';
        SET @sql = '

Select next value for seq_EquipmentHistory over (order by eq.EquipmentHistoryId) as newEquipmentHistoryId, eq.*
into dbo.TempEquipmentHistory_WO
from '+@Fromserver+'.'+@FromDB+'.dbo.EquipmentHistory eq  
inner join tempEquipment a  on a.equipmentId = eq.equipmentId
inner join tempwo wo on wo.workorderid = eq.workorderid 
where eq.workorderid <> 0 


if exists (select * from dbo.TempEquipmentHistory_WO) Begin

Update TempEquipmentHistory_WO set  equipmentId = -3
where equipmentid <> 0 


Update TempEquipmentHistory_WO set  workorderid = -3
where workorderid <> 0 

update eq
set  eq.equipmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEquipmentHistory_WO eq with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EquipmentHistory Feq on eq.EquipmentHistoryId = Feq.EquipmentHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feq.equipmentId = ulk.oldid
where
	eq.equipmentId = -3 and ulk.tablename = ''Equipment''


	update eq
set  eq.workorderid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempEquipmentHistory_WO eq with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.EquipmentHistory Feq on eq.EquipmentHistoryId = Feq.EquipmentHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feq.workorderid = ulk.oldid
where
	eq.workorderid = -3 and ulk.tablename = ''workorder''

	Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''EquipmentHistory'',
        	''EquipmentHistoryID'',
        	EquipmentHistoryid,
        	NewEquipmentHistoryID
        From
           	dbo.TempEquipmentHistory_WO

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempEquipmentHistory_WO''
  ,@ToTable =''EquipmentHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.EquipmentHistory      
    --        (
	-- 	   [EquipmentHistoryId]
    --        ,[EquipmentId]
    --        ,[WorkorderId]
    --        ,[EquipmentCondition]
    --        ,[IsConditionValid]
    --        ,[EstimatedUsefulLife]
    --        ,[LastAssessmentComment]
    --        ,[DateUpdated]
    --        ,[EquipmentHistory_CS_CompanyId]
	-- 	   )
    -- select
    --          [newEquipmentHistoryId]
    --        ,[EquipmentId]
    --        ,[WorkorderId]
    --        ,[EquipmentCondition]
    --        ,[IsConditionValid]
    --        ,[EstimatedUsefulLife]
    --        ,[LastAssessmentComment]
    --        ,[DateUpdated]
    --        ,'+@ToCompany+' as [EquipmentHistory_CS_CompanyId]

    -- from
    --     dbo.TempEquipmentHistory_WO


        PRINT 'Insert Message PM';
        SET @sql = '
Select next value for seq_Message over (order by mg.MessageId) as newMessageId , mg.*
into dbo.tempmessage
from
    '+@Fromserver+'.'+@FromDB+'.dbo.message mg  inner join tempwo  on tempwo.workorderid = mg.workorderid


update tempmessage
set
    tempmessage.propertyid = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    tempmessage.propertyid = tempproperty.propertyid

update tempmessage
set tempmessage.workorderid = tempwo.newworkorderid
from
    tempwo with (nolock)
where
    tempmessage.workorderid = tempwo.workorderid

update tempmessage
set tempmessage.EmployeeIdFrom = tempce.newEmployeeId
from
    tempmessage with (nolock) inner join tempce with (nolock)
on
    tempmessage.EmployeeIdFrom = tempce.EmployeeId

update tempmessage
set tempmessage.EmployeeIdTo = tempce.newEmployeeId
from
    tempmessage with (nolock) inner join tempce with (nolock)
on
    tempmessage.EmployeeIdTo = tempce.EmployeeId

if exists (select * from tempmessage) Begin


update tempmessage set PropertyId = -3,
WorkOrderId = case when workorderid is null then workorderid else -3 end,
TenantId = case when tenantid is null then tenantid else  -3 end,
ContactId = case when contactid is null then contactid else  -3 end,
EmployeeIDFrom = case when EmployeeIdFrom is null then EmployeeIDFrom else -3 end,
EmployeeIDTo = case when EmployeeIDTo is null then EmployeeIdTo Else -3 end,
EmployeeIdUpdated = case when EmployeeIdUpdated is null then EmployeeIdUpdated Else -3 end,
EmployeeIdCreated = case when EmployeeIdCreated is null then EmployeeIdCreated Else -3 end


update pmm
set pmm.PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempmessage pmm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Fpmm on pmm.MessageId = Fpmm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmm.PropertyId = ulk.oldid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder fwo on fpmm.workorderid = fwo.workorderid
where
	pmm.PropertyId = -3 and ulk.tablename = ''Property'' and fwo.wotype = ''PM''

update pmm
set pmm.WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempmessage pmm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Fpmm on pmm.MessageId = Fpmm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmm.WorkOrderId = ulk.oldid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder fwo on fpmm.workorderid = fwo.workorderid
where
	pmm.WorkOrderId = -3 and ulk.tablename = ''WorkOrder'' and fwo.wotype = ''PM''

update pmm
set pmm.EmployeeIdFrom = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempmessage pmm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Fpmm on pmm.MessageId = Fpmm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmm.EmployeeIdFrom = ulk.oldid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder fwo on fpmm.workorderid = fwo.workorderid
where
	pmm.EmployeeIdFrom = -3 and ulk.tablename = ''Employee'' and fwo.wotype = ''PM''

update pmm
set pmm.EmployeeIdTo = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempmessage pmm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Fpmm on pmm.MessageId = Fpmm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmm.EmployeeIdTo = ulk.oldid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder fwo on fpmm.workorderid = fwo.workorderid
where
	pmm.EmployeeIdTo = -3 and ulk.tablename = ''Employee'' and fwo.wotype = ''PM''


update pmm
set pmm.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempmessage pmm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Fpmm on pmm.MessageId = Fpmm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmm.EmployeeIdUpdated = ulk.oldid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder fwo on fpmm.workorderid = fwo.workorderid
where
	pmm.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee'' and fwo.wotype = ''PM''


	update pmm
set pmm.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempmessage pmm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Fpmm on pmm.MessageId = Fpmm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fpmm.EmployeeIdCreated = ulk.oldid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.workorder fwo on fpmm.workorderid = fwo.workorderid
where
	pmm.EmployeeIdCreated = -3 and ulk.tablename = ''Employee'' and fwo.wotype = ''PM''

	Update	dbo.tempmessage
	set contactid = 0
	where contactid not in (select newcontactid from tempcontact)  and contactid <>0


	Update	dbo.tempmessage
	set [EmployeeIdFrom] = 0
	where [EmployeeIdFrom] not in (select employeeid from employee)  AND
	[EmployeeIdFrom] <>0


	Update	dbo.tempmessage
	set [EmployeeIdTo] = 0
	where [EmployeeIdTo] not in (select employeeid from employee)  AND
	 [EmployeeIdTo] <>0


	Update	dbo.tempmessage
	set [EmployeeIdCreated] = 0
	where [EmployeeIdCreated] not in (select employeeid from employee)  AND
	 [EmployeeIdCreated] <>0


	Update	dbo.tempmessage
	set [EmployeeIdUpdated] = 0
	where [EmployeeIdUpdated] not in (select employeeid from employee)  AND
	 [EmployeeIdUpdated] <>0

-- If we copy COI, there is an update for COIID

update tempmessage
set
	COIID = null


insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Message'',
        	''MessageID'',
        	MessageID,
        	NewMessageid
        From
            tempmessage

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempmessage''
  ,@ToTable =''Message''
  ,@CompanyId = '+@ToCompany+'


end
';

        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Message
    -- (
	-- 	[MessageId]
    --     ,[DiscriminatorType]
    --     ,[CoiId]
    --     ,[PropertyId]
    --     ,[RequestId]
    --     ,[WorkOrderId]
    --     ,[TenantId]
    --     ,[ContactId]
    --     ,[EmployeeIdFrom]
    --     ,[EmployeeIdTo]
    --     ,[IsMessageRead]
    --     ,[MessageIdParent]
    --     ,[DateSent]
    --     ,[DateReceived]
    --     ,[FromAddress]
    --     ,[ToAddress]
    --     ,[CcAddress]
    --     ,[Subject]
    --     ,[Body]
    --     ,[tmpInboxid]
    --     ,[MessageType]
    --     ,[IsMessageDeleted]
    --     ,[EmployeeIdCreated]
    --     ,[DateCreated]
    --     ,[tmpMessageID]
    --     --,[DateCreatedUtc]
	-- 	,[Category]
	-- 	,[ManuallyClassified]
	-- 	,[EmployeeIdUpdated]
	-- 	,[DateUpdated]
	-- 	,message_cs_companyid
    -- )
    -- Select
	-- 	[NewMessageId]
    --     ,[DiscriminatorType]
    --     ,[CoiId]
    --     ,[PropertyId]
    --     ,[RequestId]
    --     ,[WorkOrderId]
    --     ,[TenantId]
    --     ,[ContactId]
    --     ,[EmployeeIdFrom]
    --     ,[EmployeeIdTo]
    --     ,[IsMessageRead]
    --     ,Null AS [MessageIdParent]
    --     ,[DateSent]
    --     ,[DateReceived]
    --     ,[FromAddress]
    --     ,[ToAddress]
    --     ,[CcAddress]
    --     ,[Subject]
    --     ,[Body]
    --     ,-1 as [tmpInboxid]
    --     ,[MessageType]
    --     ,[IsMessageDeleted]
    --     ,[EmployeeIdCreated]
    --     ,[DateCreated]
    --     ,MessageID as [tmpMessageID]
    --     --,[DateCreatedUtc]
	-- 	,[Category]
	-- 	,[ManuallyClassified]
	-- 	,[EmployeeIdUpdated]
	-- 	,[DateUpdated]
	-- 	,'+@ToCompany+' as cs_companyid

    -- From
    --     dbo.tempmessage


        PRINT 'Insert MessageAttachement PM';
        SET @sql = 'select NULL AS newMessageid, NULL AS newAttachmentid, ma.* into dbo.tempMessageAttachmentPM from
               '+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment ma  inner join tempmessage tm  on ma.Messageid = tm.Messageid

Update ma
set
	NewMessageid = ulk.[NewID]
From
    '+@ToDB+'.dbo.tempMessageAttachmentPM ma with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment Fma on ma.MessageID = fma.MessageID
	and Fma.AttachmentID = ma.AttachmentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fma.MessageId = ulk.oldid
where
   ulk.tablename = ''Message''

Update ma
set
	NewAttachmentID = ulk.[NewID]
From
    '+@ToDB+'.dbo.tempMessageAttachmentPM ma with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment Fma on ma.MessageID = fma.MessageID
	and Fma.AttachmentID = ma.AttachmentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fma.AttachmentID = ulk.oldid
where
	 ulk.tablename = ''FileAttachment''




	insert '+@ToDB+'.dbo.[MessageAttachment]
           (
           [MessageId]
           ,[AttachmentId]
           ,[tmpMessageAttachmentID]
		   ,MessageAttachment_cs_companyid
           )

       select   [NewMessageId]
           ,[NewAttachmentId]
           ,[tmpMessageAttachmentID]
		   ,'+@ToCompany+' as cs_companyid
        From tempMessageAttachmentPM
    ';
        EXEC (@sql);

        PRINT 'Insert Wotask';
        SET @sql = '
Select next value for seq_wotask over (order by wotk.wotaskid) as newwotaskid, wotk.*
into dbo.tempwotask
from
    '+@Fromserver+'.'+@FromDB+'.dbo.wotask wotk  inner join tempwo  on wotk.workorderid = tempwo.workorderid
--order by wotk.wotaskid

update tempwotask
set tempwotask.workorderid = tempwo.newworkorderid
from
    tempwo with (nolock)
where
    tempwotask.workorderid = tempwo.workorderid

update tempwotask
set tempwotask.tradeid = mapping.[NewId]
from
    mapping with (nolock)
where
    tempwotask.tradeid = mapping.Fromid
and
    mapping.tablename = ''Trade''
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

update tempwotask
set tempwotask.taskid = temptask.newtaskid
from
    temptask with (nolock)
where
    tempwotask.taskid = temptask.taskid

if exists (select * from tempwotask) Begin

update Tempwotask set WorkOrderId = -3, TradeId = -3, TaskId = case when TaskId is null then taskid  when taskid = -1 then taskid  else -3 end

update Tempwotask set employeeid = -3
where employeeid <> 0 and employeeid is not null

update wotk
set  wotk.WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempwotask wotk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.wotask fwotk on wotk.wotaskid = fwotk.wotaskid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwotk.WorkOrderId = ulk.oldid
where
	wotk.WorkOrderId = -3 and ulk.tablename = ''WorkOrder''

update wotk
set  wotk.TradeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempwotask wotk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.wotask fwotk on wotk.wotaskid = fwotk.wotaskid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwotk.TradeId = ulk.oldid
where
	wotk.TradeId = -3 and ulk.tablename = ''Trade''

update wotk
set  wotk.TaskId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempwotask wotk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.wotask fwotk on wotk.wotaskid = fwotk.wotaskid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwotk.TaskId = ulk.oldid
where
	wotk.TaskId = -3 and ulk.tablename = ''Task''


update wotk
set  wotk.EmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.Tempwotask wotk with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.wotask fwotk on wotk.wotaskid = fwotk.wotaskid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwotk.EmployeeId = ulk.oldid
where
	wotk.employeeid = -3 and ulk.tablename = ''Employee''

	insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Wotask'',
        	''WotaskID'',
        	WotaskID,
        	NewWotaskID
        From
            dbo.Tempwotask

select * from Tempwotask where employeeid not in (Select  employeeid from employee)

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempwotask''
  ,@ToTable =''wotask''
  ,@CompanyId = '+@ToCompany+'


End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.wotask
    --     (
    --        [WoTaskId]
    --        ,[WorkOrderId]
    --        ,[TradeId]
    --        ,[TaskId]
    --        ,[EmployeeId]
    --        ,[MinutesEstimated]
    --        ,[MinutesWorked]
    --        ,[WoTaskDescription]
    --        ,[WoTaskDetail]
    --        ,[tmpWoTaskId]
	-- 	 ,[DateStarted]
	-- 	  ,[DateCompleted]
	-- 	  ,[DateEscalated1]
	-- 	  ,[DateEscalated2]
	-- 	  ,[DateEscalated3]
	-- 	  ,[DateToEscalate1]
	-- 	  ,[DateToEscalate2]
	-- 	  ,wotask_cs_companyid
    --     )
    -- Select
    --       [NewWoTaskId]
    --        ,[WorkOrderId]
    --        ,[TradeId]
    --        ,[TaskId]
    --        ,[EmployeeId]
    --        ,[MinutesEstimated]
    --        ,[MinutesWorked]
    --        ,[WoTaskDescription]
    --        ,[WoTaskDetail]
    --        ,[tmpWoTaskId]
	-- 	  ,[DateStarted]
	-- 	  ,[DateCompleted]
	-- 	  ,[DateEscalated1]
	-- 	  ,[DateEscalated2]
	-- 	  ,[DateEscalated3]
	-- 	  ,[DateToEscalate1]
	-- 	  ,[DateToEscalate2]
    --       ,'+@ToCompany+' as cs_companyid
    -- From
    --     Tempwotask

        PRINT 'Insert Wohistory PM';
        SET @sql = '
Select next value for seq_wohistory over (order by woh.wohistoryid) as newwohistoryId, woh.*
into dbo.tempwoh
from
    '+@Fromserver+'.'+@FromDB+'.dbo.wohistory woh  inner join tempwo  on woh.workorderid = tempwo.workorderid
--order by woh.wohistoryid

update tempwoh
set tempwoh.EmployeeId = tempce.newEmployeeId
from
    tempwoh with (nolock) inner join tempce with (nolock)
on
    tempwoh.EmployeeId = tempce.EmployeeId

update tempwoh
set tempwoh.EmployeeIdUpdated = tempce.newEmployeeId
from
    tempwoh with (nolock) inner join tempce with (nolock)
on
    tempwoh.EmployeeIdUpdated = tempce.EmployeeId

update tempwoh
set tempwoh.EmployeeIdCreated = tempce.newEmployeeId
from
    tempwoh with (nolock) inner join tempce with (nolock)
on
    tempwoh.EmployeeIdCreated = tempce.EmployeeId

update tempwoh
set tempwoh.workorderid = tempwo.newworkorderid
from
    tempwo with (nolock)
where
    tempwoh.workorderid = tempwo.workorderid

update tempwoh
set tempwoh.wotaskid = tempwotask.newwotaskid
from
    tempwotask with (nolock)
where
    tempwoh.wotaskid = tempwotask.wotaskid


update tempwoh set WorkOrderId = -3, wotaskid = case when wotaskid is null then wotaskid else -3 end, EmployeeId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3
update woh
set  woh.WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.WorkOrderId = ulk.oldid
where
	woh.WorkOrderId = -3 and ulk.tablename = ''WorkOrder''

update woh
set  woh.EmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeId = ulk.oldid
where
	woh.EmployeeId = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdCreated = ulk.oldid
where
	woh.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdUpdated = ulk.oldid
where
	woh.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

update woh
set  woh.WoTaskId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwoh woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistory Fwoh on woh.WoHistoryId = Fwoh.WoHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.WoTaskId = ulk.oldid
where
	woh.WoTaskId = -3 and ulk.tablename = ''WoTask''

Select
        newWoHistoryId                , woHistoryID,
        WorkOrderId	,
        WoTaskId	,
        EmployeeId	,
        MinutesWorked	,
        WoHistoryDate	,
        WoHistoryEvent	,
        WoHistoryStatus	,
        --WoHistoryStatusDescription	,
        WoHistoryDetail	,
        EmployeeIdCreated	,
        DateCreated	,
        EmployeeIdUpdated	,
        DateUpdated

    From
        tempwoh      where  employeeid not in (Select employeeid from employee)


Update tempwoh
set EmployeeIdCreated = 0
where EmployeeIdCreated not in (select employeeid from employee)


Update tempwoh
set EmployeeIdUpdated = 0
where EmployeeIdUpdated not in (select employeeid from employee)


Update tempwoh
set EmployeeId = 0
where EmployeeId not in (select employeeid from employee)


if exists (select * from tempwoh) begin

	insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''wohistory'',
        	''wohistoryID'',
        	wohistoryID,
        	Newwohistoryid
        From
            tempwoh

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempwoh''
  ,@ToTable =''wohistory''
  ,@CompanyId = '+@ToCompany+'


end
';
        EXEC (@sql);
--    insert '+@ToDB+'.dbo.wohistory
--         (
-- 			[WoHistoryId]
--            ,[WorkOrderId]
--            ,[WoTaskId]
--            ,[EmployeeId]
--            ,[MinutesWorked]
--            ,[WoHistoryDate]
--            ,[WoHistoryEvent]
--            ,[WoHistoryStatus]
--            ,[WoHistoryDetail]
--            ,[EmployeeIdCreated]
--            ,[DateCreated]
--            ,[EmployeeIdUpdated]
--            ,[DateUpdated]
--            ,[tmpWoHistoryID]
--            --,[DateUpdatedUtc]
--            --,[DateCreatedUtc]
--            ,[ApprovalLevel]
--            ,[BillableTotal]
--            ,[NonBillableTotal]
-- 		   ,wohistory_cs_companyid
--         )

--     Select
--        [NewWoHistoryId]
--         ,[WorkOrderId]
--         ,[WoTaskId]
--         ,[EmployeeId]
--         ,[MinutesWorked]
--         ,[WoHistoryDate]
--         ,[WoHistoryEvent]
--         ,[WoHistoryStatus]
--         ,[WoHistoryDetail]
--         ,[EmployeeIdCreated]
--         ,[DateCreated]
--         ,[EmployeeIdUpdated]
--         ,[DateUpdated]
--         ,[tmpWoHistoryID]
--         --,[DateUpdatedUtc]
--         --,[DateCreatedUtc]
--         ,[ApprovalLevel]
--         ,[BillableTotal]
--         ,[NonBillableTotal]
-- 		,'+@ToCompany+' as cs_companyid
--     From
--         tempwoh

        PRINT 'Insert WoHistoryDetail PM';
        SET @sql = '
Select next value for seq_WoHistoryDetail over (order by wohdetail.WoHistoryDetailId) as newWoHistoryDetailId, wohdetail.*
into dbo.tempPMwohDetail
from
    '+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail wohdetail  inner join tempwoh  on wohdetail.woHistoryID = tempwoh.woHistoryID
--order by wohdetail.WoHistoryDetailId


update tempPMwohDetail set woHistoryID = -3, WoHistoryDetailEmployeeId = -3, EmployeeIdCreated = -3, EmployeeIdUpdated = -3

update woh
set  woh.woHistoryID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempPMwohDetail woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail Fwoh on woh.WoHistoryDetailId = Fwoh.WoHistoryDetailId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.woHistoryID = ulk.oldid
where
	woh.woHistoryID = -3 and ulk.tablename = ''WoHistory''

update woh
set  woh.WoHistoryDetailEmployeeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempPMwohDetail woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail Fwoh on woh.WoHistoryDetailId = Fwoh.WoHistoryDetailId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.WoHistoryDetailEmployeeId = ulk.oldid
where
	woh.WoHistoryDetailEmployeeId = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempPMwohDetail woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail Fwoh on woh.WoHistoryDetailId = Fwoh.WoHistoryDetailId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdCreated = ulk.oldid
where
	woh.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update woh
set  woh.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempPMwohDetail woh with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WoHistoryDetail Fwoh on woh.WoHistoryDetailId = Fwoh.WoHistoryDetailId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fwoh.EmployeeIdUpdated = ulk.oldid
where
	woh.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

	If exists (select * from tempPMwohDetail) Begin
	insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''WoHistoryDetail'',
        	''WoHistoryDetailID'',
        	WoHistoryDetailID,
        	NewWoHistoryDetailid
        From
            tempPMwohDetail

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempPMwohDetail''
  ,@ToTable =''WoHistoryDetail''
  ,@CompanyId = '+@ToCompany+'


End
';
        EXEC (@sql);
    --  insert '+@ToDB+'.dbo.WoHistoryDetail
    -- (

    --         [WoHistoryDetailId]
    --        ,[WoHistoryId]
    --        ,[WoHistoryDetailEvent]
    --        ,[WoHistoryDetailDate]
    --        ,[DateCreated]
    --        ,[DateUpdated]
    --        ,[WoHistoryDetailEmployeeId]
    --        ,[EmployeeIdCreated]
    --        ,[EmployeeIdUpdated]
    --        ,[Comments]
    --        ,[tmpWoHistoryDetailID]
	-- 	   ,wohistorydetail_cs_companyid

    -- )
    -- Select
    --         [NewWoHistoryDetailId]
    --        ,[WoHistoryId]
    --        ,[WoHistoryDetailEvent]
    --        ,[WoHistoryDetailDate]
    --        ,[DateCreated]
    --        ,[DateUpdated]
    --        ,[WoHistoryDetailEmployeeId]
    --        ,[EmployeeIdCreated]
    --        ,[EmployeeIdUpdated]
    --        ,[Comments]
    --        ,[tmpWoHistoryDetailID]
	-- 	   ,'+@ToCompany+' as cs_companyid

    -- From
    --     dbo.tempPMwohDetail
        PRINT 'Insert Woitem';
        SET @sql = '
Select next value for seq_woitem over (order by woi.woitemid) as newwoitemid, woi.*
into dbo.tempwoitem
from
    '+@Fromserver+'.'+@FromDB+'.dbo.woitem woi  inner join tempwo  on tempwo.workorderid = woi.workorderid
--order by woi.woitemid

update tempwoitem
set tempwoitem.workorderid = tempwo.newworkorderid
from
    tempwo with (nolock)
where
    tempwoitem.workorderid = tempwo.workorderid

if exists (select * from tempwoitem) begin

update tempwoitem set WorkOrderId = -3 where WorkorderID <> 0
update tempwoitem set SchedItemId = -3 where SchedItemID <> 0

update woi
set  woi.WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwoitem woi with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.woitem fwoi on woi.WoItemId = fwoi.WoItemId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwoi.WorkOrderId = ulk.oldid
where
	woi.WorkOrderId= -3 and ulk.tablename = ''WorkOrder''

update woi
set  woi.SchedItemID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwoitem woi with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.woitem fwoi on woi.WoItemId = fwoi.WoItemId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwoi.SchedItemID = ulk.oldid
where
	woi.SchedItemID= -3 and ulk.tablename = ''SchedItem''

	insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
    Select
        	''Woitem'',
        	''WoitemID'',
        	WoitemID,
        	NewWoitemID
    From
        tempwoitem

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempwoitem''
  ,@ToTable =''woitem''
  ,@CompanyId = '+@ToCompany+'


End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.woitem
    --     (
    --         WoItemId          ,
    --         WorkOrderId       ,
    --         SchedItemId       ,
    --         WoItemState       ,
    --         WoItemDescription ,
    --         WoItemLocation    ,
    --         WoItemType        ,
    --       --[DateUpdatedUtc] ,
    --       --[DateCreatedUtc] ,
    --         tmpItemId
	-- 		,woitem_cs_companyid
    --     )
    -- select
    --         newWoItemId          ,
    --         WorkOrderId,
    --         SchedItemId,
    --         WoItemState       ,
    --         WoItemDescription ,
    --         WoItemLocation    ,
    --         WoItemType        ,
	-- 	  --[DateUpdatedUtc] ,
    --       --[DateCreatedUtc] ,
    --         -1
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
    --     tempwoitem

        PRINT 'Insert Wotaskline';
        SET @sql = '
Select next value for seq_Wotaskline over (order by wotkl.wotasklineid) as newwotasklineid, wotkl.*
into dbo.tempwotkl
from
    '+@Fromserver+'.'+@FromDB+'.dbo.wotaskline wotkl  inner join tempwotask  on tempwotask.wotaskid = wotkl.wotaskid
--order by wotkl.wotasklineid

update tempwotkl
set tempwotkl.wotaskid = tempwotask.newwotaskid
from
    tempwotask with (nolock)
where
    tempwotkl.wotaskid = tempwotask.wotaskid

update tempwotkl
set tempwotkl.TaskLineId = temptaskline.newTaskLineId
from
    temptaskline with (nolock)
where
    tempwotkl.TaskLineId = temptaskline.TaskLineId

if exists (select * from tempwotkl) begin

update tempwotkl set WoTaskId = -3 where wotaskid is not null

update tempwotkl set tasklineID = -3 where tasklineID is not null

update wotkl
set  wotkl.WoTaskId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwotkl wotkl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Wotaskline fwotkl on wotkl.Wotasklineid = fwotkl.Wotasklineid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwotkl.WoTaskId = ulk.oldid
where
	wotkl.WoTaskId = -3 and ulk.tablename = ''WoTask''

update wotkl
set  wotkl.tasklineID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwotkl wotkl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Wotaskline fwotkl on wotkl.Wotasklineid = fwotkl.Wotasklineid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwotkl.tasklineID = ulk.oldid
where
	wotkl.tasklineID = -3 and ulk.tablename = ''taskline''

Update tempwotkl
set tasklineID = null
where tasklineID  = -3

	 insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
    Select
        	''Wotaskline'',
        	''WotasklineID'',
        	WotasklineID,
        	NewWotasklineID
    From
        tempwotkl

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempwotkl''
  ,@ToTable =''woTaskline''
  ,@CompanyId = '+@ToCompany+'

end';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.Wotaskline
    --     (
    --         WoTaskLineId            ,
    --        WoTaskId                ,
    --         TaskLineId              ,
    --         WoTaskLineType          ,
    --         WoTaskLineDetail        ,
    --         WoTaskLineReadingValue  ,
    --         WoTaskLineCheckingValue ,
    --         tmpWoTaskLineId
	-- 		,wotaskline_cs_companyid
    --     )
    -- select
    --         newWoTaskLineId            ,
    --         WoTaskId,
    --         TaskLineId              ,
    --         WoTaskLineType          ,
	-- 		WoTaskLineDetail        ,
    --         WoTaskLineReadingValue  ,
    --         WoTaskLineCheckingValue ,
    --         -1
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
    --     tempwotkl

        PRINT 'Insert WorkorderVirtual';
        SET @sql = '
Select next value for seq_WorkOrderVirtual over (order by wov.WorkOrderVirtualId) as newWorkorderVirtualId , wov.*
into dbo.tempwov
from
    '+@Fromserver+'.'+@FromDB+'.dbo.WorkOrderVirtual wov  inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.schedtask stk  on stk.schedtaskid = wov.schedtaskid inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.schedule sc  on sc.scheduleid = stk.scheduleid inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.equipment eq  on sc.equipmentid = eq.equipmentid  inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.area a  on eq.areaid = a.areaid inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.building b  on a.buildingid = b.buildingid
where
    b.propertyid in '+@FromProperty+'
--order by wov.WorkOrderVirtualId

update tempwov
set tempwov.ScheduleId = tempschedule.newScheduleId
from
    tempschedule with (nolock)
where
    tempwov.ScheduleId = tempschedule.ScheduleId

update tempwov
set tempwov.TaskId = tempTask.NewTaskId
from
    tempTask with (nolock)
where
    tempwov.TaskId = tempTask.TaskId

update tempwov
set tempwov.schedtaskid = tempschedtask.newschedtaskid
from
    tempschedtask with (nolock)
where
    tempwov.schedtaskid = tempschedtask.schedtaskid

update tempwov
set tempwov.EmployeeIdAssigned = tempce.newEmployeeId
from
    tempwov with (nolock) inner join tempce with (nolock)
on
    tempwov.EmployeeIdAssigned = tempce.EmployeeId

if exists (select * from tempwov) begin

update tempwov set ScheduleId = -3, EmployeeIdAssigned = -3, SchedTaskId = -3,BuildingId = -3

update wov
set  wov.ScheduleId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwov wov with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WorkOrderVirtual fwov on wov.WorkOrderVirtualId = fwov.WorkOrderVirtualId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwov.ScheduleId = ulk.oldid
where
	wov.ScheduleId = -3 and ulk.tablename = ''Schedule''

update wov
set  wov.EmployeeIdAssigned = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwov wov with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WorkOrderVirtual fwov on wov.WorkOrderVirtualId = fwov.WorkOrderVirtualId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwov.EmployeeIdAssigned = ulk.oldid
where
	wov.EmployeeIdAssigned = -3 and ulk.tablename = ''Employee''

update wov
set  wov.SchedTaskId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwov wov with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WorkOrderVirtual fwov on wov.WorkOrderVirtualId = fwov.WorkOrderVirtualId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwov.SchedTaskId = ulk.oldid
where
	wov.SchedTaskId = -3 and ulk.tablename = ''SchedTask''

update wov
set  wov.buildingid = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempwov wov with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.WorkOrderVirtual fwov on wov.WorkOrderVirtualId = fwov.WorkOrderVirtualId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fwov.buildingid = ulk.oldid
where
	wov.buildingid = -3 and ulk.tablename = ''building''

	 insert dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
    Select
        	''WorkOrderVirtual'',
        	''WorkOrderVirtualId'',
        	WorkOrderVirtualId,
        	NewWorkOrderVirtualId
    From
        tempwov

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempwov''
  ,@ToTable =''WorkOrderVirtual''
  ,@CompanyId = '+@ToCompany+'


end';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.WorkOrderVirtual
    --     (
    --         WorkOrderVirtualId,
    --         ScheduleId,
    --         SchedTaskId,
    --         EmployeeIdAssigned,
    --         DateScheduled,
    --         DateExpiry,
    --         TaskId,
	-- 	  buildingid
	-- 	  ,WorkOrderVirtual_cs_companyid

    --     )
    -- select
    --         newWorkOrderVirtualId ,
    --         ScheduleId,
    --         SchedTaskId,
    --         EmployeeIdAssigned,
    --         DateScheduled,
    --         DateExpiry,
    --         TaskId,
	-- 	  buildingid
	-- 	  ,'+@ToCompany+' as cs_companyid

    -- From
    --     tempwov

        PRINT 'Insert GaugeReading';
        SET @sql = ' Select next value for seq_GaugeReading over (order by GaugeReading.gaugeReadingID) as newGaugeReadingID, GaugeReading.*
into dbo. tempGaugeReading from '+@Fromserver+'.'+@FromDB+'.dbo.GaugeReading inner join tempGauge
on GaugeReading.GaugeID = tempGauge.GaugeID
--order by GaugeReading.gaugeReadingID

Update tempGaugeReading
set workorderID = -3
where workorderid is not null and workorderid <> 0

Update tempGaugeReading
set GaugeID = -3
where gaugeid is not null and gaugeid <> 0

Update tempGaugeReading
set EmployeeIDCreated = -3
where EmployeeidCreated is not null and EmployeeIDCreated <> 0

Update tempGaugeReading
set EmployeeIDUpdated = -3
where EmployeeIDUpdated is not null and EmployeeIDUpdated <> 0



update eqatt
set  GaugeID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempGaugeReading eqatt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.GaugeReading Feqatt on eqatt.GaugeReadingID = Feqatt.GaugeReadingID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feqatt.GaugeID = ulk.oldid
where
	eqatt.GaugeID = -3 and ulk.tablename = ''Gauge''


update eqatt
set  WorkOrderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempGaugeReading eqatt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.GaugeReading Feqatt on eqatt.GaugeReadingID = Feqatt.GaugeReadingID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feqatt.WorkorderID = ulk.oldid
where
	eqatt.WorkorderID = -3 and ulk.tablename = ''Workorder''

update eqatt
set  employeeIDCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempGaugeReading eqatt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.GaugeReading Feqatt on eqatt.GaugeReadingID = Feqatt.GaugeReadingID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feqatt.employeeIDCreated = ulk.oldid
where
	eqatt.employeeIDCreated = -3 and ulk.tablename = ''Employee''

update eqatt
set  employeeIDUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempGaugeReading eqatt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.GaugeReading Feqatt on eqatt.GaugeReadingID = Feqatt.GaugeReadingID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Feqatt.employeeIDUpdated = ulk.oldid
where
	eqatt.employeeIDUpdated = -3 and ulk.tablename = ''Employee''

if exists (select * from dbo.tempGaugeReading) Begin
    Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''GaugeReading'',
        	''GaugeReadingID'',
        	GaugeReadingID,
        	newGaugeReadingID
        From
           	dbo.tempGaugeReading

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempGaugeReading''
  ,@ToTable =''GaugeReading''
  ,@CompanyId = '+@ToCompany+'


End
';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[GaugeReading]
    --     (
    --      [GaugeReadingId]
    --        ,[GaugeId]
    --        ,[Value]
    --        ,[DateReadingTaken]
    --        ,[WorkOrderId]
    --        ,[DateCreated]
    --        ,[DateUpdated]
    --        ,[EmployeeIdCreated]
    --        ,[EmployeeIdUpdated]
	-- 	   ,Gaugereading_cs_companyid
    --     )
    -- select
    --        [NewGaugeReadingId]
    --        ,[GaugeId]
    --        ,[Value]
    --        ,[DateReadingTaken]
    --        ,[WorkOrderId]
    --        ,[DateCreated]
    --        ,[DateUpdated]
    --        ,[EmployeeIdCreated]
    --        ,[EmployeeIdUpdated]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempGaugeReading

        PRINT 'Insert SchedGauge';
        SET @sql = ' Select  SchedGauge.*
into dbo.tempSchedGauge from '+@Fromserver+'.'+@FromDB+'.dbo.SchedGauge inner join tempGauge
on SchedGauge.GaugeID = tempGauge.GaugeID


Update tempSchedGauge
set GaugeID = ulk.[newid]
from tempSchedGauge inner join '+@ToDB+'.dbo.'+@lookup+' ulk  on tempSchedGauge.GaugeID = ulk.oldid
where ulk.tablename =''Gauge''

Update tempSchedGauge
set ScheduleID = ulk.[newid]
from tempSchedGauge inner join '+@ToDB+'.dbo.'+@lookup+' ulk  on tempSchedGauge.ScheduleID = ulk.oldid
where ulk.tablename =''Schedule''

insert SchedGauge
(ScheduleID,GaugeID, schedgauge_cs_companyid)
Select ScheduleID,GaugeID ,'+@ToCompany+' as cs_companyid
from tempSchedGauge

';
        exec (@sql);
    end;

    -- PM End
--------------------------------------------------------------
    -- ACS Begin
    if @DoACS = 1
             begin

        -- ACS is refered to building and contact

        PRINT 'Insert ACS';
        SET @sql = 'select next value for seq_ACS over (order by ACS.ACSid) as newACSID, ACS.* into dbo.tempACS from '+@Fromserver+'.'+@FromDB+'.dbo.ACS  inner join tempBuilding
	on ACS.acsId = tempBuilding.acsid

	update tempACS
	set Companyid =  '+@ToCompany+'

	if exists (select * from tempACS)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''acs'',
        	''AcsID'',
        	AcsID,
        	newAcsID
        From
           	dbo.tempACS

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempACS''
  ,@ToTable =''ACS''
  ,@CompanyId = '+@ToCompany+'

	end

	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[ACS]
    --     (
	-- 		[AcsId]
    --        ,[AccessToken]
    --        ,[Notes]
    --        ,[CompanyId]
	-- 	   ,[ContactTerminatedNotificationEmail]
	-- 	   ,ACS_cs_companyid
    --     )
    -- select
    --        [NewAcsId]
    --        ,[AccessToken]
    --        ,[Notes]
    --        ,[CompanyId]
	-- 	   ,[ContactTerminatedNotificationEmail]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempACS


        PRINT 'Insert AcsBadgeType';
        SET @sql = ' select next value for seq_AcsBadgeType over (order by a.NewAcsBadgeTypeId) as newAcsBadgeTypeid, a.* into tempAcsBadgeType from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsBadgeType a
	inner join tempACS on a.Acsid = tempACS.Acsid

	Update tempAcsBadgeType
	set Acsid = -3
	where Acsid is not null and Acsid <> 0


	Update tempAcsBadgeType
	set ACSID = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsBadgeType dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsBadgeType Ftbl on dtbl.AcsBadgeTypeid = ftbl.AcsBadgeTypeid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ACSID = ulk.oldid
where
	dtbl.ACSId = -3 and ulk.tablename = ''ACS''

	if exists (select * from tempAcsBadgeType)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsBadgeType'',
        	''AcsBadgeTypeId'',
        	AcsBadgeTypeID,
        	newAcsBadgeTypeID
        From
           	dbo.tempAcsBadgeType

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsBadgeType''
  ,@ToTable =''AcsBadgeType''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsBadgeType]
    --     (
	-- 		[AcsBadgeTypeId]
    --        ,[AcsId]
    --        ,[Code]
    --        ,[Description]
    --        ,[IsDefaultForVisitors]
    --        ,[IsDefaultForTenants]
	-- 	   ,Acsbadgetype_cs_companyid
	-- 	   ,Name
    --     )
    -- select
    --        [NewAcsBadgeTypeId]
    --        ,[AcsId]
    --        ,[Code]
    --        ,[Description]
    --        ,[IsDefaultForVisitors]
    --        ,[IsDefaultForTenants]
	-- 	   ,'+@ToCompany+' as cs_companyid
	-- 	   ,Name
    -- from
    --     dbo.tempAcsBadgeType


        PRINT 'Insert AcsTenantBadgeType';
        SET @sql = ' select next value for seq_AcsTenantBadgeType over (order by a.AcsTenantBadgeTypeid) as newAcsTenantBadgeTypeid, a.* into tempAcsBadgeTypeTenantBadeType from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantBadgeType a
	inner join tempAcsBadgeType on a.AcsBadgeTypeId = tempAcsBadgeType.AcsBadgeTypeId

	Update tempAcsBadgeTypeTenantBadeType
	set AcsBadgeTypeId = -3
	where AcsBadgeTypeId is not null and AcsBadgeTypeId <> 0

	Update tempAcsBadgeTypeTenantBadeType
	set Tenantid = -3
	where Tenantid is not null and Tenantid <> 0

	Update tempAcsBadgeTypeTenantBadeType
	set AcsBadgeTypeId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsBadgeTypeTenantBadeType dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantBadgeType Ftbl on dtbl.AcsTenantBadgeTypeid = ftbl.AcsTenantBadgeTypeid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsBadgeTypeId = ulk.oldid
where
	dtbl.AcsBadgeTypeId = -3 and ulk.tablename = ''AcsBadgeType''

	Update tempAcsBadgeTypeTenantBadeType
	set Tenantid = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsBadgeTypeTenantBadeType dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantBadgeType Ftbl on dtbl.AcsTenantBadgeTypeid = ftbl.AcsTenantBadgeTypeid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.Tenantid = ulk.oldid
where
	dtbl.Tenantid = -3 and ulk.tablename = ''Tenant''

	if exists (select * from tempAcsBadgeTypeTenantBadeType)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsTenantBadgeType'',
        	''AcsTenantBadgeTypeId'',
        	AcsTenantBadgeTypeID,
        	newAcsTenantBadgeTypeID
        From
           	dbo.tempAcsBadgeTypeTenantBadeType

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcstenantbadgetype''
  ,@ToTable =''Acstenantbadgetype''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsTenantBadgeType]
    --     (
	-- 		[AcsTenantBadgeTypeId]
    --        ,[TenantId]
    --        ,[AcsBadgeTypeId]
    --        ,[IsDefault]
	-- 	   ,AcsTenantBadgeType_cs_companyid
    --     )
    -- select
    --        [NewAcsTenantBadgeTypeId]
    --           ,[TenantId]
    --        ,[AcsBadgeTypeId]
    --        ,[IsDefault]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempAcsBadgeTypeTenantBadeType


        PRINT 'Insert AcsFacilityCode';
        SET @sql = ' select next value for seq_AcsFacilityCode over (order by a.AcsFacilityCodeId) as newAcsFacilityCodeid, a.* into tempAcsFacilityCode from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsFacilityCode a
	inner join tempACS on a.Acsid = tempACS.Acsid

	Update tempAcsFacilityCode
	set Acsid = -3
	where Acsid is not null and Acsid <> 0


	Update tempAcsFacilityCode
	set ACSID = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsFacilityCode dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsFacilityCode Ftbl on dtbl.AcsFacilityCodeid = ftbl.AcsFacilityCodeid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ACSID = ulk.oldid
where
	dtbl.ACSId = -3 and ulk.tablename = ''ACS''

	if exists (select * from tempAcsFacilityCode)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsFacilityCode'',
        	''AcsFacilityCodeId'',
        	AcsFacilityCodeID,
        	newAcsFacilityCodeID
        From
           	dbo.tempAcsFacilityCode

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsFacilityCode''
  ,@ToTable =''AcsFacilityCode''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsFacilityCode]
    --     (
	-- 	[AcsFacilityCodeId]
    --        ,[AcsId]
    --        ,[Code]
    --        ,[Name]
    --        ,[Description]
    --        ,[IsDefaultForVisitors]
    --        ,[IsDefaultForTenants]
    --        ,[AcsFacilityCode_CS_CompanyId]
    --     )
    -- select
    --        [NewAcsFacilityCodeId]
    --        ,[AcsId]
    --        ,[Code]
    --        ,[Name]
    --        ,[Description]
    --        ,[IsDefaultForVisitors]
    --        ,[IsDefaultForTenants]
    --        ,'+@ToCompany+' as cs_companyid
		 
    -- from
    --     dbo.tempAcsFacilityCode


        PRINT 'Insert AcsTenantFacilityCode';
        SET @sql = ' select next value for seq_AcsTenantFacilityCode over (order by a.AcsTenantFacilityCodeId) as newAcsTenantFacilityCodeid, a.* into tempAcsFacilityCodeTenantFacilityCode from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantFacilityCode a
	inner join tempAcsFacilityCode on a.AcsFacilityCodeId = tempAcsFacilityCode.AcsFacilityCodeId
	inner join tempTenant on a.Tenantid = tempTenant.TenantId

	Update tempAcsFacilityCodeTenantFacilityCode
	set AcsFacilityCodeId = -3
	where AcsFacilityCodeId is not null and AcsFacilityCodeId <> 0

	Update tempAcsFacilityCodeTenantFacilityCode
	set TenantId = -3
	where TenantId is not null and TenantId <> 0

	Update tempAcsFacilityCodeTenantFacilityCode
	set AcsFacilityCodeId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsFacilityCodeTenantFacilityCode dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantFacilityCode Ftbl on dtbl.AcsTenantFacilityCodeid = ftbl.AcsTenantFacilityCodeid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsFacilityCodeId = ulk.oldid
where
	dtbl.AcsFacilityCodeId = -3 and ulk.tablename = ''AcsFacilityCode''

	Update tempAcsFacilityCodeTenantFacilityCode
	set TenantId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsFacilityCodeTenantFacilityCode dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantFacilityCode Ftbl on dtbl.AcsTenantFacilityCodeid = ftbl.AcsTenantFacilityCodeid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.TenantId = ulk.oldid
where
	dtbl.TenantId = -3 and ulk.tablename = ''Tenant''

	if exists (select * from tempAcsFacilityCodeTenantFacilityCode)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsTenantFacilityCode'',
        	''AcsTenantFacilityCodeId'',
        	AcsTenantFacilityCodeID,
        	newAcsTenantFacilityCodeID
        From
           	dbo.tempAcsFacilityCodeTenantFacilityCode

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcstFacilityCodeTenantFacilityCode''
  ,@ToTable =''AcsTenantFacilityCode''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsTenantFacilityCode]
    --     (
	-- 	[AcsTenantFacilityCodeId]
    --        ,[TenantId]
    --        ,[AcsFacilityCodeId]
    --        ,[IsDefault]
    --        ,[AcsTenantFacilityCode_CS_CompanyId]
    --     )
    -- select
    --        [NewAcsTenantFacilityCodeId]
    --        ,[TenantId]
    --        ,[AcsFacilityCodeId]
    --        ,[IsDefault]           
    --        ,'+@ToCompany+' as cs_companyid
		 
    -- from
    --     dbo.tempAcsFacilityCodeTenantFacilityCode


        PRINT 'Insert AcsAccessLevel';
        SET @sql = ' select next value for seq_AcsAccessLevel over (order by a.AcsAccessLevelId) as newAcsAccessLevelid, a.* into tempAcsAccessLevel from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsAccessLevel a
	inner join tempACS on a.Acsid = tempACS.Acsid

	Update tempAcsAccessLevel
	set Acsid = -3
	where Acsid is not null and Acsid <> 0


	Update tempAcsAccessLevel
	set ACSID = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsAccessLevel dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsAccessLevel Ftbl on dtbl.AcsAccessLevelid = ftbl.AcsAccessLevelid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ACSID = ulk.oldid
where
	dtbl.ACSId = -3 and ulk.tablename = ''ACS''

	if exists (select * from tempAcsAccessLevel)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsAccessLevel'',
        	''AcsAccessLevelId'',
        	AcsAccessLevelID,
        	newAcsAccessLevelID
        From
           	dbo.tempAcsAccessLevel

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsAccessLevel''
  ,@ToTable =''AcsAccessLevel''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsAccessLevel]
    --     (
	-- 		[AcsAccessLevelId]
    --        ,[AcsId]
    --        ,[Code]
    --        ,[Description]
    --        ,[IsDefaultForVisitors]
    --        ,[IsDefaultForTenants]
	-- 	   ,AcsAccessLevel_cs_companyid
	-- 	   ,Name
    --     )
    -- select
    --        [NewAcsAccessLevelId]
    --        ,[AcsId]
    --        ,[Code]
    --        ,[Description]
    --        ,[IsDefaultForVisitors]
    --        ,[IsDefaultForTenants]
	-- 	   ,'+@ToCompany+' as cs_companyid
	-- 	   ,Name
    -- from
    --     dbo.tempAcsAccessLevel


        PRINT 'Insert AcsUserMap';
        SET @sql = ' select next value for seq_ACSUserMap over (order by a.AcsUserMapId) as newAcsUserMapid, a.* into tempAcsUserMap from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsUserMap a
	inner join tempACS on a.Acsid = tempACS.Acsid

	Update tempAcsUserMap
	set Acsid = -3

	Update tempAcsUserMap
	set Contactid = -3
	where Contactid is not null and contactid <> 0

	Update tempAcsUserMap
	set ACSID = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsUserMap dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsUserMap Ftbl on dtbl.AcsUserMapid = ftbl.AcsUserMapid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ACSID = ulk.oldid
where
	dtbl.ACSId = -3 and ulk.tablename = ''ACS''

	Update tempAcsUserMap
	set Contactid = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsUserMap dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsUserMap Ftbl on dtbl.AcsUserMapid = ftbl.AcsUserMapid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ACSID = ulk.oldid
where
	dtbl.Contactid = -3 and ulk.tablename = ''Contact''

	if exists (select * from tempAcsUserMap)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsUserMap'',
        	''AcsUserMapId'',
        	AcsUserMapID,
        	newAcsUserMapID
        From
           	dbo.tempAcsUserMap

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsUserMap''
  ,@ToTable =''AcsUserMap''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsUserMap]
    --     (
	-- 		[AcsUserMapId]
    --        ,[AcsId]
    --        ,[ExternalId]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[DateInactive]
    --        ,[ContactId]
	-- 	   ,AcsUsermap_cs_companyid
    --     )
    -- select
    --        [NewAcsUserMapId]
    --        ,[AcsId]
    --        ,[ExternalId]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[DateInactive]
    --        ,[ContactId]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempAcsUserMap


        PRINT 'Insert AcsTenantRequest';
        SET @sql = ' select next value for seq_AcsTenantRequest over (order by a.AcsTenantRequestId) as newAcsTenantRequestid, a.* into tempAcsTenantRequest from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantRequest a
	inner join tempContact on a.ContactIdRequestedFor = tempContact.ContactId

	Update tempAcsTenantRequest
	set WorkorderId = -3
	where workorderid <> 0


	Update tempAcsTenantRequest
	set ContactIdRequestedFor = -3
	where ContactIdRequestedFor is not null and ContactIdRequestedFor <> 0

	Update tempAcsTenantRequest
	set ContactIdRequestedBy = -3
	where ContactIdRequestedBy is not null and ContactIdRequestedBy <> 0

	Update tempAcsTenantRequest
	set EmployeeIdApprovedBy = -3
	where EmployeeIdApprovedBy is not null and EmployeeIdApprovedBy <> 0



	Update tempAcsTenantRequest
	set WorkorderId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsTenantRequest dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantRequest Ftbl on dtbl.AcsTenantRequestid = ftbl.AcsTenantRequestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.WorkorderId = ulk.oldid
where
	dtbl.WorkorderId = -3 and ulk.tablename = ''Workorder''

	Update tempAcsTenantRequest
	set ContactIdRequestedFor = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsTenantRequest dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantRequest Ftbl on dtbl.AcsTenantRequestid = ftbl.AcsTenantRequestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ContactIdRequestedFor = ulk.oldid
where
	dtbl.ContactIdRequestedFor = -3 and ulk.tablename = ''Contact''

	Update tempAcsTenantRequest
	set ContactIdRequestedBy = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsTenantRequest dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantRequest Ftbl on dtbl.AcsTenantRequestid = ftbl.AcsTenantRequestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ContactIdRequestedBy = ulk.oldid
where
	dtbl.ContactIdRequestedBy = -3 and ulk.tablename = ''Contact''

	Update tempAcsTenantRequest
	set EmployeeIdApprovedBy = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsTenantRequest dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantRequest Ftbl on dtbl.AcsTenantRequestid = ftbl.AcsTenantRequestid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.EmployeeIdApprovedBy = ulk.oldid
where
	dtbl.EmployeeIdApprovedBy = -3 and ulk.tablename = ''Employee''

	if exists (select * from tempAcsTenantRequest)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsTenantRequest'',
        	''AcsTenantRequestId'',
        	AcsTenantRequestID,
        	newAcsTenantRequestID
        From
           	dbo.tempAcsTenantRequest

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsTenantRequest''
  ,@ToTable =''AcsTenantRequest''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsTenantRequest]
    --     (
	-- 		[AcsTenantRequestId]
    --        ,[ScanCode]
    --        ,[WorkOrderId]
    --        ,[ContactIdRequestedBy]
    --        ,[ContactIdRequestedFor]
    --        ,[BuildingId]
    --        ,[ActivationDate]
    --        ,[ExpiryDate]
    --        ,[DateRequested]
    --        ,[DateUpdated]
    --        ,[Notes]
    --        ,[Status]
    --        ,[EmployeeIdApprovedBy]
	-- , AcsTenantRequest_cs_companyid
    --     )
    -- select
	-- 		[NewAcsTenantRequestId]
    --        ,[ScanCode]
    --        ,[WorkOrderId]
    --        ,[ContactIdRequestedBy]
    --        ,[ContactIdRequestedFor]
    --        ,[BuildingId]
    --        ,[ActivationDate]
    --        ,[ExpiryDate]
    --        ,[DateRequested]
    --        ,[DateUpdated]
    --        ,[Notes]
    --        ,[Status]
    --        ,[EmployeeIdApprovedBy]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempAcsTenantRequest

        PRINT 'Insert Photo';
        --SET @sql = ' select next value for seq_Photo as newPhotoid, a.* into tempPhoto from  '+@Fromserver+'.'+@FromDB+'.dbo.Photo a
        SET @sql = ' select next value for seq_Photo over (order by a.PhotoId) as newPhotoid, a.* into tempPhoto from  '+@Fromserver+'.'+@FromDB+'.dbo.view_Photo a
	inner join tempAcsTenantRequest on a.AcsTenantRequestId = tempAcsTenantRequest.AcsTenantRequestId

	Update tempPhoto
	set Companyid = '+@ToCompany+'

	Update tempPhoto
	set ContactId = -3
	where ContactId is not null and ContactId <> 0

	Update tempPhoto
	set RestrictedVisitorID = -3
	where RestrictedVisitorID is not null and RestrictedVisitorID <> 0

	Update tempPhoto
	set AcsTenantRequestId = -3
	where AcsTenantRequestId is not null and AcsTenantRequestId <> 0

	Update tempPhoto
	set employeeid = -3
	where employeeid is not null and employeeid <> 0

	Update tempPhoto
	set ContactId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempPhoto dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Photo Ftbl on dtbl.Photoid = ftbl.Photoid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ContactID = ulk.oldid
where
	dtbl.ContactId = -3 and ulk.tablename = ''Contact''

	Update tempPhoto
	set RestrictedVisitorID = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempPhoto dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Photo Ftbl on dtbl.Photoid = ftbl.Photoid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.RestrictedVisitorID = ulk.oldid
where
	dtbl.RestrictedVisitorID = -3 and ulk.tablename = ''Visitor''

	Update tempPhoto
	set AcsTenantRequestId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempPhoto dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Photo Ftbl on dtbl.Photoid = ftbl.Photoid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsTenantRequestId = ulk.oldid
where
	dtbl.AcsTenantRequestId = -3 and ulk.tablename = ''AcsTenantRequest''

	Update tempPhoto
	set employeeid = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempPhoto dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Photo Ftbl on dtbl.Photoid = ftbl.Photoid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsTenantRequestId = ulk.oldid
where
	dtbl.employeeid = -3 and ulk.tablename = ''employee''

	if exists (select * from tempPhoto)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Photo'',
        	''PhotoId'',
        	PhotoID,
        	newPhotoID
        From
           	dbo.tempPhoto

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempPhoto''
  ,@ToTable =''Photo''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[Photo]
    --     (
	-- 		[PhotoId]
    --        ,[Size]
    --        ,[Bytes]
    --        ,[Format]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[DateInactive]
    --        ,[Details]
    --        ,[CompanyId]
    --        ,[ContactId]
    --        ,[RestrictedVisitorId]
    --        ,[AcsTenantRequestId]
	-- 	   ,employeeid
	-- 	   ,Photo_cs_companyid
	-- 	   ,isResized
    --     )
    -- select
	-- 		[NewPhotoId]
    --        ,[Size]
    --        ,[Bytes]
    --        ,[Format]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[DateInactive]
    --        ,[Details]
    --        ,[CompanyId]
    --        ,[ContactId]
    --        ,[RestrictedVisitorId]
    --        ,[AcsTenantRequestId]
	-- 	   ,employeeid
	-- 	   ,'+@ToCompany+' as cs_companyid
	-- 	   ,isResized
    -- from
    --     dbo.tempPhoto

        PRINT 'Insert AcsDeactivationReason';
        SET @sql = ' select next value for seq_AcsDeactivationReason over (order by a.AcsDeactivationReasonId) as newAcsDeactivationReasonid, a.* into tempAcsDeactivationReason from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsDeactivationReason a
	inner join tempAcs on a.[AcsId] = tempAcs.[AcsId]

	Update tempAcsDeactivationReason
	set AcsId = -3
	where AcsId is not null and AcsId <> 0

	Update tempAcsDeactivationReason
	set AcsId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsDeactivationReason dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsDeactivationReason Ftbl on dtbl.AcsDeactivationReasonid = ftbl.AcsDeactivationReasonid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsId = ulk.oldid
where
	dtbl.AcsId = -3 and ulk.tablename = ''Acs''

	if exists (select * from tempAcsDeactivationReason)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsDeactivationReason'',
        	''AcsDeactivationReasonId'',
        	AcsDeactivationReasonID,
        	newAcsDeactivationReasonID
        From
           	dbo.tempAcsDeactivationReason

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsDeactivationReason''
  ,@ToTable =''AcsDeactivationReason''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsDeactivationReason]
    --     (
	-- 		[AcsDeactivationReasonId]
    --        ,[AcsId]
    --        ,[ExternalId]
    --        ,[AddToRestricted]
    --        ,[IsDefaultForAcs]
	-- 	   ,AcsDeactivationReason_cs_companyid
	-- 	   ,DeactivationCategory
    --     )
    -- select
	-- 		[NewAcsDeactivationReasonId]
    --        ,[AcsId]
    --        ,[ExternalId]
    --        ,[AddToRestricted]
    --        ,[IsDefaultForAcs]
	-- 	   ,'+@ToCompany+' as cs_companyid
	-- 	   ,DeactivationCategory
    -- from
    --     dbo.tempAcsDeactivationReason


        PRINT 'Insert AcsDeactivationReasonLocale';
        SET @sql = ' select next value for seq_AcsDeactivationReasonLocale over (order by a.AcsDeactivationReasonLocaleId) as newAcsDeactivationReasonLocaleid, a.* into tempAcsDeactivationReasonLocale from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsDeactivationReasonLocale a
	inner join tempAcsDeactivationReason on a.[AcsDeactivationReasonId] = tempAcsDeactivationReason.[AcsDeactivationReasonId]

	Update tempAcsDeactivationReasonLocale
	set AcsDeactivationReasonId = -3
	where AcsDeactivationReasonId is not null and AcsDeactivationReasonId <> 0

	Update tempAcsDeactivationReasonLocale
	set AcsDeactivationReasonId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsDeactivationReasonLocale dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsDeactivationReasonLocale Ftbl on dtbl.AcsDeactivationReasonLocaleid = ftbl.AcsDeactivationReasonLocaleid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsDeactivationReasonId = ulk.oldid
where
	dtbl.AcsDeactivationReasonId = -3 and ulk.tablename = ''AcsDeactivationReason''

	if exists (select * from tempAcsDeactivationReasonLocale)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsDeactivationReasonLocale'',
        	''AcsDeactivationReasonLocaleId'',
        	AcsDeactivationReasonLocaleID,
        	newAcsDeactivationReasonLocaleID
        From
           	dbo.tempAcsDeactivationReasonLocale

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsDeactivationReasonLocale''
  ,@ToTable =''AcsDeactivationReasonLocale''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsDeactivationReasonLocale]
    --     (
	-- 		[AcsDeactivationReasonLocaleId]
    --        ,[AcsDeactivationReasonId]
    --        ,[LocaleCode]
    --        ,[AcsDeactivationReasonDescription]
	-- 	   ,AcsDeactivationReasonLocale_cs_companyid
    --     )
    -- select
	-- 		[NewAcsDeactivationReasonLocaleId]
    --        ,[AcsDeactivationReasonId]
    --        ,[LocaleCode]
    --        ,[AcsDeactivationReasonDescription]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempAcsDeactivationReasonLocale


        PRINT 'Insert AcsCredential';
        SET @sql = ' select next value for seq_AcsCredential over (order by a.AcsCredentialId) as newAcsCredentialid, a.* into tempAcsCredential from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsCredential a
	inner join tempBuilding on a.[buildingid] = tempBuilding.[buildingid]

	Update tempAcsCredential
	set AcsUserMapId = -3
	where AcsUserMapId is not null and AcsUserMapId <> 0

	Update tempAcsCredential
	set buildingid = -3
	where buildingid is not null and buildingid <> 0

	Update tempAcsCredential
	set [AcsDeactivationReasonId] = -3
	where [AcsDeactivationReasonId] is not null and [AcsDeactivationReasonId] <> 0

	Update tempAcsCredential
	set [EmployeeIdCreatedBy] = -3
	where [EmployeeIdCreatedBy] is not null and [EmployeeIdCreatedBy] <> 0

	Update tempAcsCredential
	set [ContactIdUpdatedBy] = -3
	where [ContactIdUpdatedBy] is not null and [ContactIdUpdatedBy] <> 0

	Update tempAcsCredential
	set AcsUserMapId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsCredential dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsCredential Ftbl on dtbl.AcsCredentialid = ftbl.AcsCredentialid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsUserMapId = ulk.oldid
where
	dtbl.AcsUserMapId = -3 and ulk.tablename = ''AcsUserMap''

	Update tempAcsCredential
	set buildingid = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsCredential dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsCredential Ftbl on dtbl.AcsCredentialid = ftbl.AcsCredentialid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.buildingid = ulk.oldid
where
	dtbl.buildingid = -3 and ulk.tablename = ''building''

	Update tempAcsCredential
	set [AcsDeactivationReasonId] = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsCredential dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsCredential Ftbl on dtbl.AcsCredentialid = ftbl.AcsCredentialid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.[AcsDeactivationReasonId] = ulk.oldid
where
	dtbl.[AcsDeactivationReasonId] = -3 and ulk.tablename = ''AcsDeactivationReason''

	Update tempAcsCredential
	set [EmployeeIdCreatedBy] = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsCredential dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsCredential Ftbl on dtbl.AcsCredentialid = ftbl.AcsCredentialid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.[EmployeeIdCreatedBy] = ulk.oldid
where
	dtbl.[EmployeeIdCreatedBy] = -3 and ulk.tablename = ''Employee''

	Update tempAcsCredential
	set [ContactIdUpdatedBy] = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsCredential dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsCredential Ftbl on dtbl.AcsCredentialid = ftbl.AcsCredentialid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.[ContactIdUpdatedBy] = ulk.oldid
where
	dtbl.[ContactIdUpdatedBy] = -3 and ulk.tablename = ''Contact''

	if exists (select * from tempAcsCredential)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsCredential'',
        	''AcsCredentialId'',
        	AcsCredentialID,
        	newAcsCredentialID
        From
           	dbo.tempAcsCredential

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsCredential''
  ,@ToTable =''AcsCredential''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsCredential]
    --     (
	-- 		[AcsCredentialId]
    --        ,[AcsUserMapId]
    --        ,[BuildingId]
    --        ,[ExternalId]
    --        ,[ScanCode]
    --        ,[ActivationDate]
    --        ,[ExpiryDate]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[AcsDeactivationReasonId]
    --        ,[EmployeeIdCreatedBy]
    --        ,[ContactIdUpdatedBy]
	-- 	   ,[Status]
	-- 	   ,[AcsBadgeTypeId]
	-- 	   ,AcsCredential_cs_companyid
	-- 	   ,AcsFacilityCodeId
    --     )
    -- select
	-- 		[NewAcsCredentialId]
    --        ,[AcsUserMapId]
    --        ,[BuildingId]
    --        ,[ExternalId]
    --        ,[ScanCode]
    --        ,[ActivationDate]
    --        ,[ExpiryDate]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[AcsDeactivationReasonId]
    --        ,[EmployeeIdCreatedBy]
    --        ,[ContactIdUpdatedBy]
	-- 	   ,Status
	-- 	   ,[AcsBadgeTypeId]
	-- 	   ,'+@ToCompany+' as cs_companyid
	-- 	   ,AcsFacilityCodeId
    -- from
    --     dbo.tempAcsCredential


        PRINT 'Insert AcsCredentialSwipe';
        SET @sql = ' select next value for seq_AcsCredentialSwipe over (order by a.AcsCredentialSwipeId) as newAcsCredentialSwipeid, a.* into
				 tempAcsCredentialSwipe from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsCredentialSwipe a
	inner join TempAcsCredential b on a.AcsCredentialId = b.AcsCredentialId

	Update tempAcsCredentialSwipe
	set AcsCredentialId = -3
	where AcsCredentialId is not null and AcsCredentialId <> 0

	Update tempAcsCredentialSwipe
	set AcsCredentialId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsCredentialSwipe dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsCredentialSwipe Ftbl on dtbl.AcsCredentialSwipeid = ftbl.AcsCredentialSwipeid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsCredentialId = ulk.oldid
where
	dtbl.AcsCredentialId = -3 and ulk.tablename = ''AcsCredential''

	if exists (select * from tempAcsCredentialSwipe)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsCredentialSwipe'',
        	''AcsCredentialSwipeId'',
        	AcsCredentialSwipeID,
        	newAcsCredentialSwipeID
        From
           	dbo.tempAcsCredentialSwipe

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsCredentialSwipe''
  ,@ToTable =''AcsCredentialSwipe''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsCredentialSwipe]
    --     (
	-- 		[AcsCredentialSwipeId]
    --        ,[AcsCredentialId]
    --        ,[DateCreated]
    --        ,[ExternalLocationId]
    --        ,[ExternalLocationName]
	-- 	   ,[ExternalDeviceId]
	-- 	   ,[ExternalDeviceName]
	-- 	   ,[ExternalEventId]
	-- 	   ,[SwipeDate]
	-- 	   ,[Description]
	-- 	   ,AcsCredentialSwipe_cs_companyid
    --     )
    -- select
    --        [NewAcsCredentialSwipeId]
    --        ,[AcsCredentialId]
    --        ,[DateCreated]
    --        ,[ExternalLocationId]
    --        ,[ExternalLocationName]
	-- 	   ,[ExternalDeviceId]
	-- 	   ,[ExternalDeviceName]
	-- 	   ,[ExternalEventId]
	-- 	   ,[SwipeDate]
	-- 	   ,[Description]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempAcsCredentialSwipe


        PRINT 'Insert AcsCredentialAccessLevel';
        SET @sql = ' select next value for seq_AcsCredentialAccessLevel over (order by a.AcsCredentialAccessLevelId) as newAcsCredentialAccessLevelid, a.* into
				 tempAcsCredentialAccessLevel from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsCredentialAccessLevel a
	inner join TempAcsCredential b on a.AcsCredentialId = b.AcsCredentialId

	Update tempAcsCredentialAccessLevel
	set AcsCredentialId = -3
	where AcsCredentialId is not null and AcsCredentialId <> 0

	Update tempAcsCredentialAccessLevel
	set AcsAccessLevelID = -3
	where AcsAccessLevelID is not null and AcsAccessLevelID <> 0

	Update tempAcsCredentialAccessLevel
	set AcsCredentialId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsCredentialAccessLevel dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsCredentialAccessLevel Ftbl on dtbl.AcsCredentialAccessLevelid = ftbl.AcsCredentialAccessLevelid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsCredentialId = ulk.oldid
where
	dtbl.AcsCredentialId = -3 and ulk.tablename = ''AcsCredential''

	Update tempAcsCredentialAccessLevel
	set AcsAccessLevelID = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsCredentialAccessLevel dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsCredentialAccessLevel Ftbl on dtbl.AcsCredentialAccessLevelid = ftbl.AcsCredentialAccessLevelid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsAccessLevelID = ulk.oldid
where
	dtbl.AcsAccessLevelID = -3 and ulk.tablename = ''AcsAccessLevel''

	if exists (select * from tempAcsCredentialAccessLevel)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsCredentialAccessLevel'',
        	''AcsCredentialAccessLevelId'',
        	AcsCredentialAccessLevelID,
        	newAcsCredentialAccessLevelID
        From
           	dbo.tempAcsCredentialAccessLevel

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsCredentialAccessLevel''
  ,@ToTable =''AcsCredentialAccessLevel''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsCredentialAccessLevel]
    --     (
	-- 		[AcsCredentialAccessLevelId]
    --        ,[AcsCredentialId]
    --        ,[AcsAccessLevelId]
	-- 	  , AcsCredentialAccessLevel_cs_companyid
    --     )
    -- select
    --        [NewAcsCredentialAccessLevelId]
    --        ,[AcsCredentialId]
    --        ,[AcsAccessLevelId]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempAcsCredentialAccessLevel


        PRINT 'Insert AcsHeartbeat';
        SET @sql = ' select next value for seq_AcsHeartbeat over (order by a.AcsHeartbeatId) as newAcsHeartbeatid, a.* into tempAcsHeartbeat from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsHeartbeat a
	inner join tempBuilding on a.[buildingid] = tempBuilding.[buildingid]

	Update tempAcsHeartbeat
	set buildingid = -3
	where buildingid is not null and buildingid <> 0

	Update tempAcsHeartbeat
	set buildingid = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsHeartbeat dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsHeartbeat Ftbl on dtbl.AcsHeartbeatid = ftbl.AcsHeartbeatid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.buildingid = ulk.oldid
where
	dtbl.buildingid = -3 and ulk.tablename = ''building''

	if exists (select * from tempAcsHeartbeat)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsHeartbeat'',
        	''AcsHeartbeatId'',
        	AcsHeartbeatID,
        	newAcsHeartbeatID
        From
           	dbo.tempAcsHeartbeat

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsHeartbeat''
  ,@ToTable =''AcsHeartbeat''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsHeartbeat]
    --     (
	-- 		[AcsHeartbeatId]
    --        ,[BuildingId]
    --        ,[DateCreated]
    --        ,[HeartbeatType]
    --        ,[Message]
	-- 	   ,AcsHeartbeat_cs_companyid
    --     )
    -- select
	-- 		[NewAcsHeartbeatId]
    --        ,[BuildingId]
    --        ,[DateCreated]
    --        ,[HeartbeatType]
    --        ,[Message]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempAcsHeartbeat


        PRINT 'Insert AcsTenantAccessLevel';
        SET @sql = ' select next value for seq_AcsTenantAccessLevel over (order by a.AcsTenantAccessLevelId) as newAcsTenantAccessLevelid, a.* into
				 tempAcsTenantAccessLevel from  '+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantAccessLevel a
	inner join  TempAcsAccessLevel b on a.AcsAccessLevelId = b.AcsAccessLevelId

	Update tempAcsTenantAccessLevel
	set AcsAccessLevelId = -3
	where AcsAccessLevelId is not null and AcsAccessLevelId <> 0

	Update tempAcsTenantAccessLevel
	set TenantId = -3
	where TenantId is not null and TenantId <> 0

	Update tempAcsTenantAccessLevel
	set AcsAccessLevelId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsTenantAccessLevel dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantAccessLevel Ftbl on dtbl.AcsTenantAccessLevelid = ftbl.AcsTenantAccessLevelid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsAccessLevelId = ulk.oldid
where
	dtbl.AcsAccessLevelId = -3 and ulk.tablename = ''AcsAccessLevel''

	Update tempAcsTenantAccessLevel
	set TenantId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempAcsTenantAccessLevel dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.AcsTenantAccessLevel Ftbl on dtbl.AcsTenantAccessLevelid = ftbl.AcsTenantAccessLevelid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.TenantId = ulk.oldid
where
	dtbl.TenantId = -3 and ulk.tablename = ''Tenant''

	if exists (select * from tempAcsTenantAccessLevel)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''AcsTenantAccessLevel'',
        	''AcsTenantAccessLevelId'',
        	AcsTenantAccessLevelID,
        	newAcsTenantAccessLevelID
        From
           	dbo.tempAcsTenantAccessLevel

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempAcsTenantAccessLevel''
  ,@ToTable =''AcsTenantAccessLevel''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[AcsTenantAccessLevel]
    --     (
	-- 		[AcsTenantAccessLevelId]
    --        ,[TenantId]
    --        ,[AcsAccessLevelId]
    --        ,[IsDefault]
	-- 	   ,AcsTenantAccessLevel_cs_companyid
    --     )
    -- select
    --        [NewAcsTenantAccessLevelId]
    --        ,[TenantId]
    --        ,[AcsAccessLevelId]
    --        ,[IsDefault]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempAcsTenantAccessLevel


        PRINT 'Insert VisitorContact';
        SET @sql = ' select next value for seq_VisitorContact over (order by a.VisitorContactID) as newVisitorContactid, a.* into tempVisitorContact from  '+@Fromserver+'.'+@FromDB+'.dbo.VisitorContact a
	inner join tempTenant on a.[TenantIdHost] = tempTenant.[TenantId]

	Update tempVisitorContact
	set TenantIdHost = -3
	where TenantIdHost is not null and TenantIdHost <> 0

	Update tempVisitorContact
	set TenantIdHost = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempVisitorContact dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.VisitorContact Ftbl on dtbl.VisitorContactid = ftbl.VisitorContactid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.TenantIdHost = ulk.oldid
where
	dtbl.TenantIdHost = -3 and ulk.tablename = ''Tenant''

	if exists (select * from tempVisitorContact)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''VisitorContact'',
        	''VisitorContactId'',
        	VisitorContactID,
        	newVisitorContactID
        From
           	dbo.tempVisitorContact

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempVisitorContact''
  ,@ToTable =''VisitorContact''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[VisitorContact]
    --     (
	-- 		[VisitorContactID]
    --        ,[TenantIdHost]
    --        ,[VisitorFirstName]
    --        ,[VisitorLastName]
    --        ,[SecuritySystemVisitorID]
    --        ,[DateCreatedUtc]
    --        ,[DateUpdatedUtc]
	-- 	   ,VisitorContact_cs_companyid
    --     )
    -- select
	-- 		[NewVisitorContactID]
    --        ,[TenantIdHost]
    --        ,[VisitorFirstName]
    --        ,[VisitorLastName]
    --        ,[SecuritySystemVisitorID]
    --        ,[DateCreatedUtc]
    --        ,[DateUpdatedUtc]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempVisitorContact


    -- process ACS

    END;

    -- ASC End
-------------------------------------------------
    -- Fix fileAttachment

    PRINT 'Fix fileAttachment';
    SET @sql = '

update tempFileAttachment set workorderid = -3 where workorderid <> 0 and workorderid is not null
update tempFileAttachment set RequestID = -3 where RequestID <> 0 and RequestID is not null

update vd
set
	vd.RequestID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempFileAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment Fvd on vd.AttachmentId = Fvd.AttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.RequestID = ulk.oldid
where
	vd.RequestID = -3 and ulk.tablename = ''Request''


update vd
set
	vd.WorkOrderID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempFileAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.FileAttachment Fvd on vd.AttachmentId = Fvd.AttachmentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.WorkorderID = ulk.oldid
where
	vd.WorkOrderID = -3 and ulk.tablename = ''WorkOrder''

update tempFileAttachment 
set workorderID = null
where workorderid = -3

update tempFileAttachment 
set RequestID = null
where RequestID = -3

update FileAttachment
set workorderID = tf.workorderid
,RequestId = tf.RequestId
from FileAttachment inner join tempFileAttachment tf on FileAttachment.AttachmentID = tf.NewAttachmentID

	';
    EXEC (@sql);

    PRINT 'Insert ResourceWO';
    SET @sql = '
Select  next value for seq_ResourceWO over (Order by ResourceWO.ResourceWoId) as newResourceWOid, ResourceWO.*
into tempResourceWO
from '+@Fromserver+'.'+@FromDB+'.dbo.ResourceWO  ResourceWO inner join TempResource tp  on tp.ResourceID = ResourceWO.ResourceID
--order by ResourceWO.ResourceWOid



if exists (select * from tempResourceWO) Begin


update tempResourceWO set  ResourceID = -3
where ResourceID is not null and ResourceID <> 0

update tempResourceWO set RequestTypeID = -3
Where RequestTypeId is not null and RequestTypeID <> 0

update tempResourceWO set EmployeeIDDispatchTo = -3
where EmployeeIDDispatchTo is not null and EmployeeIDDispatchTo <> 0 

update tempResourceWO set  ResourceAmenityId = -3
where ResourceAmenityId is not null and ResourceAmenityId <> 0

update vd
set
	vd.RequestTypeID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempResourceWO vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceWO Fvd on vd.ResourceWOid = Fvd.ResourceWOid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.RequestTypeID = ulk.oldid
where
	vd.RequestTypeID = -3 and ulk.tablename = ''RequestType''

update vd
set
	vd.ResourceID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempResourceWO vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceWO Fvd on vd.ResourceWOid = Fvd.ResourceWOid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ResourceID = ulk.oldid
where
	vd.ResourceID = -3 and ulk.tablename = ''Resource''


update vd
set
	vd.ResourceAmenityID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempResourceWO vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceWO Fvd on vd.ResourceWOid = Fvd.ResourceWOid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ResourceAmenityID = ulk.oldid
where
	vd.ResourceAmenityID = -3 and ulk.tablename = ''ResourceAmenity''

update vd
set
	vd.EmployeeIDDispatchTo = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempResourceWO vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceWO Fvd on vd.ResourceWOID = Fvd.ResourceWOID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIDDispatchTo = ulk.oldid
where
	vd.EmployeeIDDispatchTo = -3 and ulk.tablename = ''Commonemployee''


	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ResourceWO'',
        	''ResourceWOID'',
        	ResourceWOID,
        	NewResourceWOID
        From
           	dbo.tempResourceWO

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempResourceWO''
  ,@ToTable =''ResourceWO''
  ,@CompanyId = '+@ToCompany+'


End
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ResourceWO
    --     (
    --         ResourceWoId,
    --         RequestTypeId,
    --         ResourceId,
    --         EmployeeIdDispatchTo,
    --         RequiredDuration,
    --         RequiredBeforeOrAfter,
    --         RequiredResStartOrResEnd,
    --         RequiredDurationUnit,
    --         DispatchDuration,
    --         Priority,
    --         DispatchNotes
	-- 		,ResourceWO_cs_companyid
	-- 		,ResourceAmenityID

    --     )
    -- select
    --         NewResourceWoId,
    --         RequestTypeId,
    --         ResourceId,
    --         EmployeeIdDispatchTo,
    --         RequiredDuration,
    --         RequiredBeforeOrAfter,
    --         RequiredResStartOrResEnd,
    --         RequiredDurationUnit,
    --         DispatchDuration,
    --         Priority,
    --         DispatchNotes
	-- 		,'+@ToCompany+' as cs_companyid
	-- 		,ResourceAmenityID

    -- From
    --     tempResourceWO

    PRINT 'Insert ResourceWOService';
    SET @sql = '
Select  next value for seq_ResourceWOService over (order by ResourceWOService.ResourceWoServiceId) as newResourceWOServiceid, ResourceWOService.*
into tempResourceWOService
from '+@Fromserver+'.'+@FromDB+'.dbo.ResourceWOService  ResourceWOService inner join TempResourceWo tp  on tp.ResourceWoID = ResourceWOService.ResourceWoID



if exists (select * from tempResourceWOService) Begin


update tempResourceWOService set  ResourceID = -3
where  ResourceID is not null and  ResourceID <> 0 

update tempResourceWOService set  ResourceWoID = -3
where  ResourceWoID is not null and  ResourceWoID <> 0 

update tempResourceWOService set  ServiceID = -3
where  ServiceID is not null and  ServiceID <> 0 

update vd
set
	vd.ResourceID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempResourceWOService vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceWOService Fvd on vd.ResourceWOServiceid = Fvd.ResourceWOServiceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ResourceID = ulk.oldid
where
	vd.ResourceID = -3 and ulk.tablename = ''Resource''

update vd
set
	vd.ResourceWoID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempResourceWOService vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceWOService Fvd on vd.ResourceWOServiceid = Fvd.ResourceWOServiceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ResourceWoID = ulk.oldid
where
	vd.ResourceWoID = -3 and ulk.tablename = ''ResourceWo''



update vd
set
	vd.ServiceID = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempResourceWOService vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.ResourceWOService Fvd on vd.ResourceWOServiceID = Fvd.ResourceWOServiceID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ServiceID = ulk.oldid
where
	vd.ServiceID = -3 and ulk.tablename = ''Service''


	  Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''ResourceWOService'',
        	''ResourceWOServiceID'',
        	ResourceWOServiceID,
        	NewResourceWOServiceID
        From
           	dbo.tempResourceWOService

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempResourceWOService''
  ,@ToTable =''ResourceWOService''
  ,@CompanyId = '+@ToCompany+'

End
';
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.ResourceWOService
    --     (
    --        [ResourceWoServiceId]
    --        ,[ResourceWoId]
    --        ,[ServiceId]
    --        ,[ResourceId]
	-- 	   ,ResourceWoService_CS_CompanyId 

    --     )
    -- select
    --         NewResourceWOServiceId
    --         ,[ResourceWoId]
    --         ,[ServiceId]
    --         ,[ResourceId]
	-- 		,'+@ToCompany+' as cs_companyid

    -- From
    --     tempResourceWOService

    ---- Insert Subscription
    PRINT 'Insert Subscription';
    SET @sql = ' Select next value for seq_Subscription over (order by Subscription.SubscriptionId) as newSubscriptionId, Subscription.*
into dbo.tempSubscription
from
    '+@Fromserver+'.'+@FromDB+'.dbo.Subscription Subscription
Where Subscription.CompanyID = '+@FromCompany+' and contactID != 0
and contactid in ( select contactid from '+@Fromserver+'.'+@FromDB+'.dbo.contact c
inner join '+@Fromserver+'.'+@FromDB+'.dbo.Area AS a ON c.BaseAreaId    = a.AreaId
inner join '+@Fromserver+'.'+@FromDB+'.dbo.building AS b ON a.buildingId    = b.buildingId
where b.propertyid in '+@FromProperty+')



Update tempSubscription
set
    CompanyID = '+@ToCompany+'

update tempsubscription
set contactid = -3
where contactid is not null and contactid <> 0


update vd
set
	vd.contactid = ulk.[NewID]
From
	'+@ToDB+'.dbo.tempSubscription vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Subscription Fvd on vd.SubscriptionID = Fvd.SubscriptionID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.contactid = ulk.oldid
where
	vd.contactid = -3 and ulk.tablename = ''Contact''

delete from tempSubscription where contactid not in (Select [newContactId] from tempContact)


if exists (select * from tempSubscription) begin

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Subscription'',
        	''SubscriptionID'',
        	SubscriptionID,
        	NewSubscriptionID
        From
           	dbo.tempSubscription

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempSubscription''
  ,@ToTable =''Subscription''
  ,@CompanyId = '+@ToCompany+'

End
';
    --Print @sql
    EXEC (@sql);
-- insert '+@ToDB+'.dbo.Subscription
--     (
--        [CompanyId]
--         ,[ContactId]
--         ,[Module]
--         ,[HasSubscription]
--         ,[SubscriptionId]
--         ,[tmpSubscriptionID]
--         ,[tmpSubscriptionType]
--         ,[ContactSubscriptionType]
-- 		,Subscription_cs_companyid

--     )

--     Select
--        [CompanyId]
--         ,[ContactId]
--         ,[Module]
--         ,[HasSubscription]
--         ,[NewSubscriptionId]
--         ,[tmpSubscriptionID]
--         ,[tmpSubscriptionType]
--         ,[ContactSubscriptionType]
-- 		,'+@ToCompany+' as cs_companyid

--     From
--         tempSubscription

	--------------------------
    ---- Insert Visit Module
	if @DoVisit = 1
Begin
    PRINT 'Insert VisitType';
    SET @sql = '
Select next value for seq_VisitType over (order by VisitType.VisitTypeID) as newVisitTypeId, visitType.*
into dbo.tempvisitType
from
    '+@Fromserver+'.'+@FromDB+'.dbo.VisitType VisitType
Where VisitType.PropertyID in '+@FromProperty+'
--order by VisitType.VisitTypeID

Update tempvisitType
set tempvisitType.PropertyID = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    tempvisitType.propertyid = tempproperty.propertyid

if exists (select * from tempVisitType) begin



Update TempvisitType set PropertyId = -3
update b
set
	b.propertyid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisitType b with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.VisitType Fb on b.VisitTypeid = Fb.VisitTypeid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fb.propertyid = ulk.oldid
where
	b.propertyid = -3 and ulk.tablename = ''Property''

	Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''VisitType'',
        	''VisitTypeID'',
        	VisitTypeID,
        	NewVisitTypeID
        From
           	dbo.TempVisitType

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempVisitType''
  ,@ToTable =''VisitType''
  ,@CompanyId = '+@ToCompany+'

End
';
    --print (@sql)
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.visitType
    -- (
    --     VisitTypeID,
    --     PropertyID,
    --     IsCOIRequired,
    --     visitTypeDescription
	-- 	,visitType_cs_companyid
    -- )
    -- Select
    --     NewVisitTypeID,
    --     PropertyID,
    --     IsCOIRequired,
    --     visitTypeDescription
	-- 	,'+@ToCompany+' as cs_companyid
    -- From
    --     TempVisitType


    PRINT 'Insert VisitAlert';
    SET @sql = '
Select next value for seq_VisitAlert over (order by VisitAlert.VisitAlertID) as newVisitAlertId, VisitAlert.*
into dbo.tempVisitAlert
from
    '+@Fromserver+'.'+@FromDB+'.dbo.VisitAlert VisitAlert
Where VisitAlert.PropertyID in '+@FromProperty+'
--order by VisitAlert.VisitAlertID

Update tempVisitAlert
set tempVisitAlert.PropertyID = tempproperty.newpropertyid
from
    tempproperty with (nolock)
where
    tempVisitAlert.propertyid = tempproperty.propertyid

if exists (select * from tempVisitAlert) begin


Update TempVisitAlert set PropertyId = -3
update b
set
	b.propertyid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisitAlert b with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.VisitAlert Fb on b.VisitAlertid = Fb.VisitAlertid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fb.propertyid = ulk.oldid
where
	b.propertyid = -3 and ulk.tablename = ''Property''


    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''VisitAlert'',
        	''VisitAlertID'',
        	VisitAlertID,
        	NewVisitAlertID
        From
           	dbo.TempVisitAlert

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempVisitAlert''
  ,@ToTable =''VisitAlert''
  ,@CompanyId = '+@ToCompany+'

End
';
    --print (@sql)
    EXEC (@sql);
    -- insert '+@ToDB+'.dbo.VisitAlert
    -- (
    --     VisitAlertID,
    --     PropertyID,
    --     DayThreshold,
    --     IntervalThreshold
	-- 	,visitAlert_cs_companyid
    -- )
    -- Select
    --     NewVisitAlertID,
    --     PropertyID,
    --     DayThreshold,
    --     IntervalThreshold
	-- 	,'+@ToCompany+' as cs_companyid
    -- From
    --     TempVisitAlert


    PRINT 'Insert VisitSchedule';
    SET @sql = '
Select next value for seq_VisitSchedule over (order by VisitSchedule.ScheduleID)  as newScheduleId, VisitSchedule.*
into dbo.tempVisitSchedule
from
    '+@Fromserver+'.'+@FromDB+'.dbo.VisitSchedule VisitSchedule
	where scheduleId in
	(
	select visit.scheduleid from
    '+@Fromserver+'.'+@FromDB+'.dbo.Visit visit inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Area  Area on Visit.AreaIdDestination = Area.AreaId inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Building Building on Area.BuildingID = Building.BuildingId
Where building.PropertyID in '+@FromProperty+'
)

if exists (select * from tempVisitSchedule) begin

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''VisitSchedule'',
        	''ScheduleID'',
        	ScheduleID,
        	NewScheduleID
        From
           	dbo.TempVisitSchedule

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempVisitSchedule''
  ,@ToTable =''VisitSchedule''
  ,@CompanyId = '+@ToCompany+'


End
';
    --print (@sql)

    EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.VisitSchedule
    --     (
    --      [ScheduleId]
    --        ,[DateStart]
    --        ,[DateEnd]
    --        ,[TimeExpected]
    --        ,[Sunday]
    --        ,[Monday]
    --        ,[Tuesday]
    --        ,[Wednesday]
    --        ,[Thursday]
    --        ,[Friday]
    --        ,[Saturday]
	-- 	   ,visitschedule_cs_companyid
	-- 	   )
	-- 	   select
	-- 	   [NewScheduleId]
    --        ,[DateStart]
    --        ,[DateEnd]
    --        ,[TimeExpected]
    --        ,[Sunday]
    --        ,[Monday]
    --        ,[Tuesday]
    --        ,[Wednesday]
    --        ,[Thursday]
    --        ,[Friday]
    --        ,[Saturday]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- from
    --         tempVisitSchedule

    PRINT 'Insert Visit';
    SET @sql = '
Select next value for seq_Visit over (order by Visit.VisitID)  as newVisitId, visit.*
into dbo.tempvisit
from
    '+@Fromserver+'.'+@FromDB+'.dbo.Visit visit inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Area  Area on Visit.AreaIdDestination = Area.AreaId inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Building Building on Area.BuildingID = Building.BuildingId
Where building.PropertyID in '+@FromProperty+'
--order by Visit.VisitID

Update tempvisit
set
    visitTypeId = -3
Where
    visitTypeId <> 0

Update tempvisit
set
    VendorID = -3
where
    VendorID <> 0

update tempvisit
set
    ContactIdEnteredBy = -3,
    EmployeeIdEnteredBy = -3,
    TenantIDHost = -3,
    ContactIDHost = -3,
    AreaIDdestination = -3


update tempvisit
set
    ContactIdUpdatedBy = -3 
where
	ContactIdUpdatedBy is not null and ContactIdUpdatedBy <> 0 

	
update tempvisit
set
    EmployeeIdUpdatedBy = -3 
where
	EmployeeIdUpdatedBy is not null and EmployeeIdUpdatedBy <> 0 


update tempvisit
set
    scheduleid = -3
where scheduleid > 0

update vt
set
	vt.visitTypeId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.visitTypeid = ulk.oldid
where
	vt.visitTypeId = -3 and ulk.tablename = ''VisitType''

update vt
set
	vt.vendorId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.Vendorid = ulk.oldid
where
	vt.vendorId = -3 and ulk.tablename = ''Vendor''

update vt
set
	vt.ContactIdEnteredBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.ContactIdEnteredBy = ulk.oldid
where
	vt.ContactIdEnteredBy = -3 and ulk.tablename = ''Contact''


update vt
set
	vt.ContactIdUpdatedBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.ContactIdUpdatedBy = ulk.oldid
where
	vt.ContactIdUpdatedBy = -3 and ulk.tablename = ''Contact''

update vt
set
	vt.EmployeeIdEnteredBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.EmployeeIdEnteredBy = ulk.oldid
where
	vt.EmployeeIdEnteredBy = -3 and ulk.tablename = ''Employee''


update vt
set
	vt.EmployeeIdUpdatedBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.EmployeeIdUpdatedBy = ulk.oldid
where
	vt.EmployeeIdUpdatedBy = -3 and ulk.tablename = ''Employee''


update vt
set
	vt.TenantIDHost = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.TenantIDHost = ulk.oldid
where
	vt.TenantIDHost = -3 and ulk.tablename = ''Tenant''



update vt
set
	vt.ContactIDHost = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.ContactIDHost = ulk.oldid
where
	vt.ContactIDHost = -3 and ulk.tablename = ''Contact''


update vt
set
	vt.AreaIDdestination = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.AreaIDdestination = ulk.oldid
where
	vt.AreaIDdestination = -3 and ulk.tablename = ''area''

UPDATE tempVisit
SET AreaIDdestination = 0
WHERE AreaIDdestination NOT IN (SELECT AreaID FROM dbo.Area)

SELECT * FROM tempVisit WHERE ContactIdEnteredBy NOT IN (SELECT ContactID FROM dbo.Contact)
SELECT * FROM tempVisit WHERE ContactIdHost NOT IN (SELECT ContactID FROM dbo.Contact)

UPDATE tempVisit
SET ContactIdEnteredBy = 0
WHERE ContactIdEnteredBy NOT IN (SELECT ContactID FROM dbo.Contact)

---Added code
UPDATE tempVisit
SET ContactIdUpdatedBy = 0
WHERE ContactIdUpdatedBy NOT IN (SELECT ContactID FROM dbo.Contact)
-------------

UPDATE tempVisit
SET ContactIdHost = 0
WHERE ContactIdHost NOT IN (SELECT ContactID FROM dbo.Contact)

UPDATE tempVisit
SET		TenantIdHost = 0
WHERE	TenantIdHost NOT IN (SELECT TenantID FROM Tenant)

UPDATE tempVisit
SET		EmployeeIdEnteredBy = 0
WHERE	EmployeeIdEnteredBy NOT IN (SELECT EmployeeID FROM Employee)

---Added code
UPDATE tempVisit
SET		EmployeeIdUpdatedBy = 0
WHERE	EmployeeIdUpdatedBy NOT IN (SELECT EmployeeID FROM Employee)
-------------
update vt
set
	vt.ScheduleId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempVisit vt with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visit Fvt on vt.Visitid = Fvt.Visitid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Fvt.ScheduleId = ulk.oldid
where
	vt.ScheduleId = -3 and ulk.tablename = ''VisitSchedule''



if exists (select * from tempVisit) begin

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Visit'',
        	''VisitID'',
        	VisitID,
        	NewVisitID
        From
           	dbo.TempVisit

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempVisit''
  ,@ToTable =''Visit''
  ,@CompanyId = '+@ToCompany+'

End
';
    --print (@sql)
    EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.visit
    --     (
    --       [VisitId]
    --        ,[VisitTypeId]
    --        ,[VendorId]
    --        ,[ContactIdEnteredBy]
    --        ,[EmployeeIdEnteredBy]
    --        ,[TenantIdHost]
    --        ,[ContactIdHost]
    --        ,[AreaIdDestination]
    --        ,[ScheduleId]
    --        ,[GroupSize]
    --        ,[VisitStatus]
    --        ,[EscortType]
    --        ,[NotificationType]
    --        ,[VisitorCountTotal]
    --        ,[VisitorCountCheckedIn]
    --        ,[VisitorCountCheckedOut]
    --        ,[DateCreated]
    --        ,[DateExpected]
    --        ,[EscortDescription]
    --        ,[NotificationDescription]
    --        ,[HostName]
    --        ,[HostPhone]
    --        ,[DestinationDescription]
    --        ,[Notes]
    --        ,[tmpVisitorId]
    --        ,[NotifyHost]
    --        ,[NotifyList]
	-- 	   ,VisitSource
    --   	   ,[MarkForCancellation]
    --        ,AngusIntegrationVisitId
    --        ,IsSyncFromIntegration
    --        ,AngusIntegrationOwnerCompanyId
	-- 	   ,visit_cs_companyid
	-- 	   ,DateExpiry
	-- 	   ,IsSingleUse
	-- 	   ,EmployeeIdUpdatedBy
	-- 	   ,ContactIdUpdatedBy
	-- 	   ,DateUpdated
	-- 	   ,IsDirty
    --           )
    -- Select
    --       [newVisitId]
    --        ,[VisitTypeId]
    --        ,[VendorId]
    --        ,[ContactIdEnteredBy]
    --        ,[EmployeeIdEnteredBy]
    --        ,[TenantIdHost]
    --        ,[ContactIdHost]
    --        ,[AreaIdDestination]
    --        ,[ScheduleId]
    --        ,[GroupSize]
    --        ,[VisitStatus]
    --        ,[EscortType]
    --        ,[NotificationType]
    --        ,[VisitorCountTotal]
    --        ,[VisitorCountCheckedIn]
    --        ,[VisitorCountCheckedOut]
    --        ,[DateCreated]
    --        ,[DateExpected]
    --        ,[EscortDescription]
    --        ,[NotificationDescription]
    --        ,[HostName]
    --        ,[HostPhone]
    --        ,[DestinationDescription]
    --        ,[Notes]
    --        ,[tmpVisitorId]
    --        ,[NotifyHost]
    --        ,[NotifyList]
    --   	   ,[VisitSource]
    --   	   ,[MarkForCancellation]
    --        ,AngusIntegrationVisitId
    --        ,IsSyncFromIntegration
    --        ,AngusIntegrationOwnerCompanyId
	-- 	   ,'+@ToCompany+' as cs_companyid
	-- 	   ,DateExpiry
	-- 	   ,IsSingleUse
	-- 	   ,EmployeeIdUpdatedBy
	-- 	   ,ContactIdUpdatedBy
	-- 	   ,DateUpdated
	-- 	   ,IsDirty
    -- from
    --         tempVisit

    PRINT 'Insert Visitor';
    SET @sql = '
Select next value for seq_Visitor over (order by vr.VisitorID) as newVisitorid, vr.*
into dbo.TempVisitor
from '+@Fromserver+'.'+@FromDB+'.dbo.view_Visitor vr inner join tempvisit tv on Vr.visitid = tv.visitId
--from '+@Fromserver+'.'+@FromDB+'.dbo.Visitor vr inner join tempvisit tv on Vr.visitid = tv.visitId
--order by vr.visitorID


Update tempVisitor
set
    visitID = -3,
    EmployeeIdCheckedInBy = -3,
    EmployeeIdCheckedOutBy = -3,
    EmployeeIdBadgePrintedBy = -3


update tempVisitor
set
    EmployeeIdUpdatedBy = -3 
where
	EmployeeIdUpdatedBy is not null and EmployeeIdUpdatedBy <> 0 

		
update tempVisitor
set
    ContactIdUpdatedBy = -3 
where
	ContactIdUpdatedBy is not null and ContactIdUpdatedBy <> 0 


update tvor
set
	tvor.visitID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visitor Ftvor on tvor.Visitorid = Ftvor.VisitorID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.visitID = ulk.oldid
where
	tvor.VisitID = -3 and ulk.tablename = ''visit''


update tvor
set
	tvor.EmployeeIdCheckedInBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visitor Ftvor on tvor.Visitorid = Ftvor.VisitorID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.EmployeeIdCheckedInBy = ulk.oldid
where
	tvor.EmployeeIdCheckedInBy = -3 and ulk.tablename = ''Employee''

update tvor
set
	tvor.EmployeeIdUpdatedBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visitor Ftvor on tvor.Visitorid = Ftvor.VisitorID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.EmployeeIdUpdatedBy = ulk.oldid
where
	tvor.EmployeeIdUpdatedBy = -3 and ulk.tablename = ''Employee''

update tvor
set
	tvor.ContactIdUpdatedBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visitor Ftvor on tvor.Visitorid = Ftvor.VisitorID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.ContactIdUpdatedBy = ulk.oldid
where
	tvor.ContactIdUpdatedBy = -3 and ulk.tablename = ''Contact''

update tvor
set
	tvor.EmployeeIdCheckedOutBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visitor Ftvor on tvor.Visitorid = Ftvor.VisitorID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.EmployeeIdCheckedOutBy = ulk.oldid
where
	tvor.EmployeeIdCheckedOutBy = -3 and ulk.tablename = ''Employee''

update tvor
set
	tvor.EmployeeIdBadgePrintedBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Visitor Ftvor on tvor.Visitorid = Ftvor.VisitorID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.EmployeeIdBadgePrintedBy = ulk.oldid
where
	tvor.EmployeeIdBadgePrintedBy = -3 and ulk.tablename = ''Employee''

----Added Code
UPDATE  TempVisitor
SET
ContactIdUpdatedBy = 0
WHERE	ContactIdUpdatedBy NOT IN (SELECT ContactID FROM Contact)
--------------
UPDATE  TempVisitor
SET
EmployeeIdCheckedInBy = 0
WHERE	EmployeeIdCheckedInBy NOT IN (SELECT employeeID FROM employee)

UPDATE  TempVisitor
SET
EmployeeIdCheckedOutBy = 0
WHERE	EmployeeIdCheckedOutBy NOT IN (SELECT employeeID FROM employee)

UPDATE  TempVisitor
SET
EmployeeIdBadgePrintedBy = 0
WHERE	EmployeeIdBadgePrintedBy NOT IN (SELECT employeeID FROM employee)


if exists (select * from TempVisitor) Begin

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Visitor'',
        	''VisitorID'',
        	VisitorID,
        	NewVisitorID
        From
           	dbo.TempVisitor

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempVisitor''
  ,@ToTable =''Visitor''
  ,@CompanyId = '+@ToCompany+'


End
';
    --print (@sql)
    EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.Visitor
    -- (
    --   [VisitorId]
	-- 	,[VisitId]
	-- 	,[EmployeeIdCheckedInBy]
	-- 	,[EmployeeIdCheckedOutBy]
	-- 	,[EmployeeIdBadgePrintedBy]
	-- 	,[IsPrimaryVisitor]
	-- 	,[VisitorCompany]
	-- 	--,[VisitorName]
	-- 	,[DateCreated]
	-- 	,[DateCheckedIn]
	-- 	,[DateCheckedOut]
	-- 	,[DateBadgePrinted]
	-- 	,[tmpVisitorId]
	-- 	,[RestrictionType]
	-- 	,[Picture]
	-- 	,[RestrictionNotes]
	-- 	,[SecuritySystemVisitorID]
	-- 	,[SecuritySystemBarCode]
	-- 	,[PhotoLength]
	-- 	,[PhotoData]
	-- 	,VisitorEmail
	-- 	,Pin
	-- 	,CheckInSource
	-- 	,[VisitorFirstName]
	-- 	,[VisitorLastName]
	-- 	,[SecuritySystemVisitID]
	-- 	,AngusIntegrationVisitorId
	-- 	,IsSyncFromIntegration
	-- 	,visitor_cs_companyid
	-- 	,VisitorType
	-- 	,EmployeeIdUpdatedBy
	-- 	,ContactIdUpdatedBy
	-- 	,DateUpdated
	-- 	,isResized
	-- 	)
    -- Select
    -- [NewVisitorId]
	-- 	,[VisitId]
	-- 	,[EmployeeIdCheckedInBy]
	-- 	,[EmployeeIdCheckedOutBy]
	-- 	,[EmployeeIdBadgePrintedBy]
	-- 	,[IsPrimaryVisitor]
	-- 	,[VisitorCompany]
	-- 	--,[VisitorName]
	-- 	,[DateCreated]
	-- 	,[DateCheckedIn]
	-- 	,[DateCheckedOut]
	-- 	,[DateBadgePrinted]
	-- 	,[tmpVisitorId]
	-- 	,[RestrictionType]
	-- 	,[Picture]
	-- 	,[RestrictionNotes]
	-- 	,[SecuritySystemVisitorID]
	-- 	,[SecuritySystemBarCode]
	-- 	,[PhotoLength]
	-- 	,[PhotoData]
	-- 	,VisitorEmail
	-- 	,Pin
	-- 	,CheckInSource
	-- 	,[VisitorFirstName]
	-- 	,[VisitorLastName]
	-- 	,SecuritySystemVisitID
	-- 	,AngusIntegrationVisitorId
	-- 	,IsSyncFromIntegration
	-- 	,'+@ToCompany+' as cs_companyid
	-- 	,VisitorType
	-- 	,EmployeeIdUpdatedBy
	-- 	,ContactIdUpdatedBy
	-- 	,DateUpdated
	-- 	,isResized
    -- From
    --     tempVisitor
    PRINT 'Insert RestrictedVisitor';
    SET @sql = '
Select next value for seq_RestrictedVisitor over (order by vr.RestrictedID) as newRestrictedId ,vr.*
into dbo.TempRestrictedVisitor
from '+@Fromserver+'.'+@FromDB+'.dbo.RestrictedVisitor  vr where
PropertyID in '+@FromProperty+'



Update tempRestrictedVisitor
set
    EmployeeIdCreated = -3,
	EmployeeIdUpdated =-3,
	PropertyID =-3

update tvor
set
	tvor.PropertyID = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempRestrictedVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.RestrictedVisitor Ftvor on tvor.Restrictedid = Ftvor.RestrictedID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.PropertyID = ulk.oldid
where
	tvor.PropertyID = -3 and ulk.tablename = ''Property''


update tvor
set
	tvor.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempRestrictedVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.RestrictedVisitor Ftvor on tvor.Restrictedid = Ftvor.RestrictedID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.EmployeeIdCreated = ulk.oldid
where
	tvor.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

update tvor
set
	tvor.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempRestrictedVisitor tvor with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.RestrictedVisitor Ftvor on tvor.Restrictedid = Ftvor.RestrictedID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftvor.EmployeeIdUpdated = ulk.oldid
where
	tvor.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''



if exists (select * from TempRestrictedVisitor) Begin

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''RestrictedVisitor'' as TableName ,
			''RestrictedID'' as columnname,
        	RestrictedID,
        	NewRestrictedID
        From
           	dbo.tempRestrictedVisitor

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempRestrictedVisitor''
  ,@ToTable =''RestrictedVisitor''
  ,@CompanyId = '+@ToCompany+'

End
';
    -- print (@sql)
    EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.RestrictedVisitor
    -- (
    --  [RestrictedId]
    --     --,[RestrictedName]
    --     ,[RestrictedCompany]
    --     ,[PropertyId]
    --     ,[EmployeeIdCreated]
    --    -- ,[Alias]
    --     ,[RequestedBy]
    --     ,[Profile]
    --     ,[Instructions]
    --     ,[DateCreated]
    --     ,[IsActive]
    --     ,[EmployeeIdUpdated]
    --     ,[DateUpdated]
    --     ,[tmpRestrictedVisitorID]
	-- 	,[RestrictedFirstName]
	-- 	,[RestrictedMiddleName]
	-- 	,[RestrictedLastName]
	-- 	,[AliasFirstName]
	-- 	,[AliasMiddleName]
	-- 	,[AliasLastName]
	-- 	,[HasPhoto],restrictedvisitor_cs_companyid
    -- )
    -- Select
	-- 	[NewRestrictedId]
    --      --  ,[RestrictedName]
    --        ,[RestrictedCompany]
    --        ,[PropertyId]
    --        ,[EmployeeIdCreated]
    --       -- ,[Alias]
    --        ,[RequestedBy]
    --        ,[Profile]
    --        ,[Instructions]
    --        ,[DateCreated]
    --        ,[IsActive]
    --        ,[EmployeeIdUpdated]
    --        ,[DateUpdated]
    --        ,[tmpRestrictedVisitorID]
	-- 	   ,[RestrictedFirstName]
	-- 		,[RestrictedMiddleName]
	-- 		,[RestrictedLastName]
	-- 		,[AliasFirstName]
	-- 		,[AliasMiddleName]
	-- 		,[AliasLastName]
	-- 		,[HasPhoto]
	-- 		,'+@ToCompany+' as cs_companyid
    -- From
    --     tempRestrictedVisitor
 
    PRINT 'Insert Photo RetstrictedVisitor';
    SET @sql = ' select next value for seq_Photo over (order by a.PhotoId) as newPhotoid, a.* into tempPhotoRetstrictedVisitor 
    from  '+@Fromserver+'.'+@FromDB+'.dbo.Photo a
	inner join tempRestrictedVisitor  on a.RestrictedVisitorID = tempRestrictedVisitor.RestrictedID

	--where a.photoid in 
	--(select a.photoid from  '+@Fromserver+'.'+@FromDB+'.dbo.Photo a
	--inner join tempRestrictedVisitor on a.RestrictedVisitorID = tempRestrictedVisitor.RestrictedID
	--)


	Update tempPhotoRetstrictedVisitor
	set Companyid = '+@ToCompany+'

	Update tempPhotoRetstrictedVisitor
	set ContactId = -3
	where ContactId is not null and ContactId <> 0

	Update tempPhotoRetstrictedVisitor
	set RestrictedVisitorID = -3
	where RestrictedVisitorID is not null and RestrictedVisitorID <> 0

	Update tempPhotoRetstrictedVisitor
	set AcsTenantRequestId = -3
	where AcsTenantRequestId is not null and AcsTenantRequestId <> 0


	Update tempPhotoRetstrictedVisitor
	set employeeid = -3
	where employeeid is not null and employeeid <> 0



	Update tempPhotoRetstrictedVisitor
	set ContactId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempPhotoRetstrictedVisitor dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Photo Ftbl on dtbl.Photoid = ftbl.Photoid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.ContactID = ulk.oldid
where
	dtbl.ContactId = -3 and ulk.tablename = ''Contact''


	Update tempPhotoRetstrictedVisitor
	set RestrictedVisitorID = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempPhotoRetstrictedVisitor dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Photo Ftbl on dtbl.Photoid = ftbl.Photoid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.RestrictedVisitorID = ulk.oldid
where
	--dtbl.RestrictedVisitorID = -3 and ulk.tablename = ''Visitor''
	dtbl.RestrictedVisitorID = -3 and ulk.tablename = ''RestrictedVisitor''

	Update tempPhotoRetstrictedVisitor
	set AcsTenantRequestId = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempPhotoRetstrictedVisitor dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Photo Ftbl on dtbl.Photoid = ftbl.Photoid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsTenantRequestId = ulk.oldid
where
	dtbl.AcsTenantRequestId = -3 and ulk.tablename = ''AcsTenantRequest''


	Update tempPhotoRetstrictedVisitor
	set employeeid = ulk.[newid]
	From
	'+@ToDB+'.dbo.tempPhotoRetstrictedVisitor dtbl with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Photo Ftbl on dtbl.Photoid = ftbl.Photoid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on ftbl.AcsTenantRequestId = ulk.oldid
where
	dtbl.employeeid = -3 and ulk.tablename = ''employee''
    select * from tempPhotoRetstrictedVisitor where photoid not in (select photoid from Photo)


	if exists (select * from tempPhotoRetstrictedVisitor)
	Begin
		 Insert  dbo.'+@lookup+'
     (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Photo'',
        	''PhotoId'',
        	PhotoID,
        	newPhotoID
        From
           	dbo.tempPhotoRetstrictedVisitor

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempPhotoRetstrictedVisitor''
  ,@ToTable =''Photo''
  ,@CompanyId = '+@ToCompany+'

	end
	';
        EXEC (@sql);
    -- insert '+@ToDB+'.dbo.[Photo]
    --     (
	-- 		[PhotoId]
    --        ,[Size]
    --        ,[Bytes]
    --        ,[Format]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[DateInactive]
    --        ,[Details]
    --        ,[CompanyId]
    --        ,[ContactId]
    --        ,[RestrictedVisitorId]
    --        ,[AcsTenantRequestId]
	-- 		,employeeid
	-- 		,Photo_cs_companyid
    --     )
    -- select
	-- 		[NewPhotoId]
    --        ,[Size]
    --        ,[Bytes]
    --        ,[Format]
    --        ,[DateUpdated]
    --        ,[DateCreated]
    --        ,[DateInactive]
    --        ,[Details]
    --        ,[CompanyId]
    --        ,[ContactId]
    --        ,[RestrictedVisitorId]
    --        ,[AcsTenantRequestId]
	-- 		,employeeid
	-- 		,'+@ToCompany+' as cs_companyid
    -- from
    --     dbo.tempPhotoRetstrictedVisitor


end
--	End Visit Module

    ---- Insert PropertyTenant
    PRINT 'Insert PropertyTenant';
    -------Make Change to solve tenant spam properties
    SET @sql = ' Select PropertyTenant.*
into dbo.tempPropertyTenant
from
    '+@Fromserver+'.'+@FromDB+'.dbo.PropertyTenant PropertyTenant
Where PropertyTenant.PropertyID in '+@FromProperty+' and PropertyTenant.TenantID in
(select TenantID from tempTenant)




Update tempPropertyTenant
set
    PropertyID = TempProperty.NewPropertyID
From
    tempPropertyTenant inner join tempProperty on tempPropertyTenant.PropertyID = tempProperty.PropertyID

Update tempPropertyTenant
set
    tempPropertyTenant.TenantID = tempTenant.newTenantID
from
    tempPropertyTenant inner join tempTenant on tempPropertyTenant.TenantID = tempTenant.TenantID


if exists (select * from tempPropertyTenant) begin
insert '+@ToDB+'.dbo.PropertyTenant
    (
        PropertyID,
        TenantID,
        IsBaseProperty,
        IsActivePropertyTenant
		,propertytenant_cs_companyid
    )
    Select
        PropertyID,
        TenantID,
        IsBaseProperty,
        IsActivePropertyTenant
		,'+@ToCompany+' as cs_companyid
    From
        tempPropertyTenant
End
';
    --Print @sql
    EXEC (@sql);
    ----Survey
    IF @DoSurvey = 1
             BEGIN
        PRINT 'Insert SurveyProperty';
        SET @sql = '
Select r.*
into dbo.tempSurveyProperty
from
    '+@Fromserver+'.'+@FromDB+'.dbo.SurveyProperty r  inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Property p  on p.Propertyid = r.Propertyid
where p.propertyid in '+@FromProperty+' and p.companyid = '+@FromCompany+'
--order by r.SurveyID

update tempSurveyProperty
set Propertyid = NewPropertyId
From tempSurveyProperty inner join
tempProperty on tempSurveyProperty.PropertyId = tempProperty.PropertyId

';
        EXEC (@sql);
        PRINT 'Insert Survey';
        SET @sql = '
Select next value for seq_Survey over (order by p.Surveyid) as newSurveyId, p.*
into dbo.TempSurvey
from '+@Fromserver+'.'+@FromDB+'.dbo.Survey p
where p.Surveyid in (Select SurveyID from dbo.tempSurveyProperty)
--order by p.Surveyid

Update TempSurvey
set CompanyId = '+@ToCompany+'


if exists (select * from tempSurvey) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Survey'',
        	''SurveyId'',
        	SurveyId,
        	newSurveyId
        From
           	dbo.tempSurvey

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempSurvey''
  ,@ToTable =''Survey''
  ,@CompanyId = '+@ToCompany+'

Update tempSurveyProperty
Set
    SurveyID = tempSurvey.newSurveyID
from
    tempSurveyProperty inner join tempSurvey on tempSurveyProperty.SurveyID = tempSurvey.SurveyId

Insert '+@ToDB+'.dbo.SurveyProperty
    (
    SurveyId,
    PropertyId
	,surveyproperty_cs_companyid
    )
Select
    SurveyID,
    PropertyId
	,'+@ToCompany+' as cs_companyid
from
    tempSurveyProperty
End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.Survey
    --     (
    --         SurveyId,
    --         CompanyId,
    --         Surveyname,
    --         WelcomeMessage,
    --         ThankYouMessage,
    --         dateTimeCreated,
    --         DateTimeUpdated
	-- 		,survey_cs_companyid

    --     )
    -- Select
	-- 		newSurveyId    ,
    --         CompanyId,
    --         Surveyname,
    --         WelcomeMessage,
    --         ThankYouMessage,
    --         dateTimeCreated,
    --         DateTimeUpdated
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempSurvey


        PRINT 'Insert SurveyQuestion';
        SET @sql = '
Select next value for seq_SurveyQuestion over (order by p.Questionid) as newQuestionId, p.*
into dbo.TempSurveyQuestion
from '+@Fromserver+'.'+@FromDB+'.dbo.SurveyQuestion p
where p.Surveyid in (Select SurveyID from dbo.tempSurvey)
--order by p.Questionid

update tempSurveyQuestion set Surveyid = -3

update tempSurveyQuestion
set
	Surveyid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempSurveyQuestion vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyQuestion Fvd on vd.Questionid = Fvd.Questionid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Surveyid = ulk.oldid
where
	vd.SurveyId = -3 and ulk.tablename = ''Survey''


if exists (select * from tempSurveyQuestion) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''SurveyQuestion'',
        	''QuestionId'',
        	QuestionId,
        	newQuestionId
        From
           	dbo.tempSurveyQuestion

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempSurveyQuestion''
  ,@ToTable =''SurveyQuestion''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.SurveyQuestion
    --     (
    --         QuestionId,
    --         SurveyId,
    --         QuestionText,
    --         QuestionType,
    --         QuestionOrder,
    --         Layout
	-- 		,surveyquestion_cs_companyid
    --     )
    -- Select
	-- 		newQuestionId    ,
    --         SurveyId,
    --         QuestionText,
    --         QuestionType,
    --         QuestionOrder,
    --         Layout
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempSurveyQuestion


        PRINT 'Insert SurveyChoice';
        SET @sql = '
Select next value for seq_SurveyChoice over (order by p.Choiceid) as newChoiceId, p.*
into dbo.TempSurveyChoice
from '+@Fromserver+'.'+@FromDB+'.dbo.SurveyChoice p
where p.Questionid in (Select QuestionID from dbo.tempSurveyQuestion)
--order by p.Choiceid

Update TempSurveyChoice
set
    QuestionId = -3

update TempSurveyChoice
set
	Questionid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempSurveyChoice vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyChoice Fvd on vd.Choiceid = Fvd.ChoiceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Questionid = ulk.oldid
where
	vd.QuestionId = -3 and ulk.tablename = ''SurveyQuestion''

if exists (select * from tempSurveyChoice) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''SurveyChoice'',
        	''ChoiceId'',
        	ChoiceId,
        	newChoiceId
        From
           	dbo.tempSurveyChoice

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempSurveyChoice''
  ,@ToTable =''SurveyChoice''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.SurveyChoice
    --     (
    --         ChoiceId,
    --         QuestionId,
    --         ChoiceOrder,
    --         Rating,
    --         Isescalation,
    --         ChoiceText,
	-- 		surveychoice_cs_companyid
    --     )
    -- Select
	-- 		NewChoiceId,
    --         QuestionId,
    --         ChoiceOrder,
    --         Rating,
    --         Isescalation,
    --         ChoiceText
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempSurveyChoice


        PRINT 'Insert Campaign';
        SET @sql = '

Select next value for seq_Campaign over (order by p.CampaignId) as newCampaignId, p.*
into dbo.TempCampaign
from '+@Fromserver+'.'+@FromDB+'.dbo.Campaign p
where p.SurveyID in (Select SurveyID from dbo.tempSurvey)
--order by p.CampaignId

update TempCampaign set Surveyid = -3

update TempCampaign
set
	Surveyid = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCampaign vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Campaign Fvd on vd.Campaignid = Fvd.Campaignid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Surveyid = ulk.oldid
where
	vd.SurveyId = -3 and ulk.tablename = ''Survey''



if exists (select * from tempCampaign) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Campaign'',
        	''CampaignId'',
        	CampaignId,
        	newCampaignId
        From
           	dbo.tempCampaign

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempCampaign''
  ,@ToTable =''Campaign''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.Campaign
    --     (
    --         CampaignId,
    --         SurveyId,
    --         CampaignName,
    --         CampaignStatus,
    --         DateTimeCreated,
    --         DateTimeUpdated,
    --         DateLaunched,
    --         DateClosed,
    --         EndDate,
    --         Notes,
    --         WoFrequency,
    --         LocaleCode
	-- 		,campaign_cs_companyid
    --     )
    -- Select
	-- 		NewCampaignId,
    --         SurveyId,
    --         CampaignName,
    --         CampaignStatus,
    --         DateTimeCreated,
    --         DateTimeUpdated,
    --         DateLaunched,
    --         DateClosed,
    --         EndDate,
    --         Notes,
    --         WoFrequency,
    --         LocaleCode
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempCampaign


        PRINT 'Insert CampaignProperty';
        SET @sql = '
Select r.*
into dbo.tempCampaignProperty
from
    '+@Fromserver+'.'+@FromDB+'.dbo.CampaignProperty r  inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Property p  on p.Propertyid = r.Propertyid
where p.propertyid in '+@FromProperty+' and p.companyid in ('+@FromCompany+')
and
    r.CampaignId in (Select CampaignId from tempCampaign)
--order by r.CampaignId




update tempCampaignProperty
set Propertyid = tempProperty.NewPropertyId
from
    tempCampaignProperty inner join
    tempProperty on tempCampaignProperty.PropertyId = tempProperty.PropertyId

Update tempCampaignProperty
set
    CampaignId = tempCampaign.NewCampaignId
from
    tempCampaignProperty inner join
    tempCampaign on tempCampaignProperty.CampaignId = tempCampaign.CampaignId



if exists (select * from tempCampaignProperty) Begin

    Insert '+@ToDB+'.dbo.CampaignProperty
        (

            CampaignId,
            PropertyId,
            ContactSurveyCount
			,campaignproperty_cs_companyid
        )
    Select
			CampaignId,
            PropertyId,
            ContactSurveyCount
			,'+@ToCompany+' as cs_companyid
    From tempCampaignProperty
End

';
        EXEC (@sql);
        PRINT 'Insert SurveyInstance';
        SET @sql = '
 Select next value for seq_SurveyInstance over (order by p.InstanceId) as newInstanceId, p.*
into dbo.TempSurveyInstance
from '+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstance p
where p.CampaignId in (Select CampaignID from dbo.tempCampaign) and
PropertyId in '+@FromProperty+'
--order by p.InstanceId

Update tempSurveyInstance
set
    CampaignId = -3,PropertyId = -3,ContactId = -3

Update tempSurveyInstance
set
    Workorderid = -3 
where 
	Workorderid <> 0 and workorderid is not null

update tempSurveyInstance
set
	CampaignId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempSurveyInstance vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstance Fvd on vd.Instanceid = Fvd.Instanceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.CampaignId = ulk.oldid
where
	vd.CampaignId = -3 and ulk.tablename = ''Campaign''



update tempSurveyInstance
set
	PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempSurveyInstance vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstance Fvd on vd.Instanceid = Fvd.Instanceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.PropertyId = ulk.oldid
where
	vd.PropertyId = -3 and ulk.tablename = ''Property''


update tempSurveyInstance
set
	ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempSurveyInstance vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstance Fvd on vd.Instanceid = Fvd.Instanceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ContactId = ulk.oldid
where
	vd.ContactId = -3 and ulk.tablename = ''Contact''


update tempSurveyInstance
set
	WorkorderId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempSurveyInstance vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstance Fvd on vd.Instanceid = Fvd.Instanceid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.WorkorderId = ulk.oldid
where
	vd.WorkorderId = -3 and ulk.tablename = ''WorkOrder''


if exists (select * from tempSurveyInstance) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''SurveyInstance'',
        	''nstanceId'',
        	InstanceId,
        	NewInstanceId
        From
           	dbo.tempSurveyInstance

  Select
			NewInstanceId,
            InstanceId,
            CampaignId,
            PropertyId,
            ContactId,
            WorkorderId,
            AccessCode,
            DateTimeCreated,
            DateTimeCompleted
    From tempSurveyInstance where contactId not in (Select ContactId from Contact)

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempSurveyInstance''
  ,@ToTable =''SurveyInstance''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.SurveyInstance
    --     (
    --         InstanceId,
    --         CampaignId,
    --         PropertyId,
    --         ContactId,
    --         WorkorderId,
    --         AccessCode,
    --         DateTimeCreated,
    --         DateTimeCompleted
	-- 		,surveyinstance_cs_companyid
    --     )
    -- Select
	-- 		NewInstanceId,
    --         CampaignId,
    --         PropertyId,
    --         ContactId,
    --         WorkorderId,
    --         AccessCode,
    --         DateTimeCreated,
    --         DateTimeCompleted
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempSurveyInstance


        PRINT 'Insert SurveyInstanceResponse';
        SET @sql = '
Select next value for seq_SurveyInstanceResponse over (order by p.ResponseId) as newResponseId, p.*
into dbo.TempSurveyInstanceResponse
from '+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstanceResponse p
where p.QuestionId in (Select QuestionID from dbo.tempSurveyQuestion) and
p.instanceId in (Select InstanceId from tempSurveyInstance) and
(p.ChoiceId in (Select ChoiceId from tempSurveyChoice) or p.choiceid = 0)
--order by p.ResponseId

Update tempSurveyInstanceResponse
set
    InstanceId = -3,QuestionId = -3

Update tempSurveyInstanceResponse
set ChoiceId = -3
where ChoiceId <> 0 

update tempSurveyInstanceResponse
set
	InstanceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempSurveyInstanceResponse vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstanceResponse Fvd on vd.Responseid = Fvd.Responseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.InstanceId = ulk.oldid
where
	vd.InstanceId = -3 and ulk.tablename = ''SurveyInstance''

update tempSurveyInstanceResponse
set
	QuestionId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempSurveyInstanceResponse vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstanceResponse Fvd on vd.Responseid = Fvd.Responseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.QuestionId = ulk.oldid
where
	vd.QuestionId = -3 and ulk.tablename = ''SurveyQuestion''



update tempSurveyInstanceResponse
set
	ChoiceId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempSurveyInstanceResponse vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.SurveyInstanceResponse Fvd on vd.Responseid = Fvd.Responseid inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ChoiceId = ulk.oldid
where
	vd.ChoiceId = -3 and ulk.tablename = ''SurveyChoice''



if exists (select * from tempSurveyInstanceResponse) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''SurveyInstanceResponse'',
        	''SurveyInstanceResponseId'',
        	ResponseId,
        	NewResponseId
        From
           	dbo.tempSurveyInstanceResponse

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempSurveyInstanceResponse''
  ,@ToTable =''SurveyInstanceResponse''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.SurveyInstanceResponse
    --     (
    --         ResponseId,
    --         InstanceId,
    --         QuestionId,
    --         ChoiceID,
    --         ResponseText
	-- 		,surveyinstanceresponse_cs_companyid
    --     )
    -- Select
	-- 		NewResponseId,
    --         InstanceId,
    --         QuestionId,
    --         ChoiceID,
    --         ResponseText
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempSurveyInstanceResponse


    END;
    ---------Insert Survey end
    ---------Insert COI
    IF @DoCOI = 1
             BEGIN
        PRINT 'Insert COIProperty';
        SET @sql = '
Select r.*
into dbo.tempCOIProperty
from
    '+@Fromserver+'.'+@FromDB+'.dbo.COIProperty r  inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Property p  on p.Propertyid = r.Propertyid
where p.propertyid in '+@FromProperty+' and p.companyid = '+@FromCompany+'
--order by r.COIID

update tempCOIProperty
set Propertyid = NewPropertyId
From tempCOIProperty inner join
tempProperty on tempCOIProperty.PropertyId = tempProperty.PropertyId

';
        EXEC (@sql);
        PRINT 'Insert COIbuilding';
        SET @sql = '
Select r.*
into dbo.tempCOIbuilding
from
    '+@Fromserver+'.'+@FromDB+'.dbo.COIbuilding r  inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.building b  on b.buildingid = r.buildingid inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Property P on b.Propertyid = P.PropertyId
where p.propertyid in '+@FromProperty+' and p.companyid = '+@FromCompany+'


update tempCOIbuilding
set buildingid = NewbuildingId
From tempCOIbuilding inner join
tempbuilding on tempCOIbuilding.buildingId = tempbuilding.buildingId

';
        EXEC (@sql);

        PRINT 'Insert COI';
        SET @sql = '
Select
next value for seq_COI over (order by p.COIId) as newCOIId,
p.*
into dbo.TempCOI
from '+@Fromserver+'.'+@FromDB+'.dbo.COI p
where p.COIId in (Select COIID from dbo.tempCOIProperty)
--order by p.COIid

Update TempCOI
set VendorId = -3
Where vendorId is not null and VendorId <> 0

Update TempCOI
set tenantId = -3
Where TenantId is not null and TenantId <> 0

Update TempCOI
set LeaseId = -3
where leaseId is not null and LeaseId <> 0

Update tempCOI
set
    ContractAttachmentId = -3
where ContractAttachmentId is not null and ContractAttachmentId <> 0

Update tempCOI
set
    COIAttachmentId = -3
where
    COIAttachmentId is not null and COIAttachmentId <> 0

Update tempCOI
set
    EmployeeIdlastupdate = -3
where
    EmployeeIdLastUpdate is not null and EmployeeidLastupdate <> 0

Update tempCOI
set
    EmployeeIdSignature = -3
where
    EmployeeIdSignature is not null and EmployeeIdSignature <> 0

----Vendor COI
update vd
set
	VendorId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOI vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COI Fvd on vd.COIId = Fvd.COIId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Vendorid = ulk.oldid
where
	vd.VendorId = -3 and ulk.tablename = ''Vendor''

----Tenant COI
update vd
set
	TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOI vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COI Fvd on vd.COIId = Fvd.COIId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.Tenantid = ulk.oldid
where
	vd.TenantId = -3 and ulk.tablename = ''Tenant''


update vd
set
	LeaseId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOI vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COI Fvd on vd.COIId = Fvd.COIId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.LeaseId = ulk.oldid
where
	vd.LeaseId = -3 and ulk.tablename = ''Lease''


update vd
set
	ContractAttachmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOI vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COI Fvd on vd.COIId = Fvd.COIId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.ContractAttachmentId = ulk.oldid
where
	vd.ContractAttachmentId = -3 and ulk.tablename = ''FileAttachment''

update vd
set
	COIAttachmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOI vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COI Fvd on vd.COIId = Fvd.COIId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.COIAttachmentId = ulk.oldid
where
	vd.COIAttachmentId = -3 and ulk.tablename = ''FileAttachment''

update vd
set
	EmployeeIdlastUpdate = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOI vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COI Fvd on vd.COIId = Fvd.COIId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdlastUpdate = ulk.oldid
where
	vd.EmployeeIdlastUpdate = -3 and ulk.tablename = ''Employee''

update vd
set
	EmployeeIdSignature = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOI vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COI Fvd on vd.COIId = Fvd.COIId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdSignature = ulk.oldid
where
	vd.EmployeeIdSignature = -3 and ulk.tablename = ''Employee''

Update
'+@ToDB+'.dbo.tempCOI
set	CompanyId = '+@ToCompany+'

--select * from tempCOI where EmployeeIdLastUpdate
--not in (Select employeeid from employee)
Update tempCOI 
set EmployeeIdLastUpdate = 0 
where EmployeeIdLastUpdate
not in (Select employeeid from employee)

--select * from tempCOI where [EmployeeIdSignature] 
--not in (Select employeeid from employee)
Update tempCOI set EmployeeIdSignature = null where [EmployeeIdSignature] 
not in (Select employeeid from employee)

Select * From tempCOI where COIAttachmentId not in (Select attachmentId from FileAttachment)

if exists (select * from tempCOI) Begin

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''COI'',
        	''COIId'',
        	COIId,
        	NewCOIId
        From
           	dbo.tempCOI


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempCOI''
  ,@ToTable =''COI''
  ,@CompanyId = '+@ToCompany+'

Update tempCOIProperty
Set
    COIID = t.[NewCOIId]
from
    tempCOIProperty inner join tempCOI t
	on tempCOIProperty.coiid = t.coiid


Insert '+@ToDB+'.dbo.COIProperty
    (
    COIId,
    PropertyId
	,coiproperty_cs_companyid
    )
Select
    COIId,
    PropertyId
	,'+@ToCompany+' as cs_companyid
from
    tempCOIProperty
where COIid in (Select [NewCOIId] from tempCOI)


Update tempCOIBuilding
Set
    COIID = t.[NewCOIId]
from
    tempCOIBuilding inner join tempCOI t
	on tempCOIBuilding.coiid = t.coiid

	delete from tempCOIBuilding where coiid not in (Select newCOIId from tempCOI)

Insert '+@ToDB+'.dbo.COIBuilding
    (
    COIId,
    BuildingId
	,coibuilding_cs_companyid
    )
Select
    COIID,
    BuildingId
	,'+@ToCompany+' as cs_companyid
from
    tempCOIBuilding
	where COIid in (Select [NewCOIId] from tempCOI)

End
';
        --print (@sql)
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.COI
    --     (
    --       [COIId]
    --        ,[VendorId]
    --        ,[TenantId]
    --        ,[LeaseId]
    --        ,[EmployeeIdLastUpdate]
    --        ,[IsActive]
    --        ,[IsValidSignature]
    --        ,[IsValidNameInsured]
    --        ,[COITitle]
    --        ,[LastUpdateDate]
    --        ,[VendorExpiryDaysInAdvance]
    --        ,[VendorExpiryEndDate]
    --        ,[TenantExpiryDaysInAdvance]
    --        ,[TenantExpiryEndDate]
    --        ,[NotifyEmployeeDaysInAdvance]
    --        ,[NotifyEmployeeEndDate]
    --        ,[COIContactInformation]
    --        ,[COIAttachmentId]
    --        ,[ContractAttachmentId]
    --        ,[IsCustomVendorContact]
    --        ,[VendorContactName]
    --        ,[VendorContactEmail]
    --        ,[VendorContactPhone]
    --        ,[NotifyDaysInAdvance]
    --        ,[NotifyEndDate]
    --        ,[NotifyDaysInAdvance2]
    --        ,[NotifyEmployeeDaysInAdvance2]
    --        ,[IncludeRequirements]
    --        ,[tmpCOIID]
    --        ,[EmployeeIdSignature]
    --        ,[IsCompliant]
    --        ,[CompanyId]
	-- 	   ,coi_cs_companyid
	-- 	   )
    -- Select

    --       [NewCOIId]
    --        ,[VendorId]
    --        ,[TenantId]
    --        ,[LeaseId]
    --        ,[EmployeeIdLastUpdate]
    --        ,[IsActive]
    --        ,[IsValidSignature]
    --        ,[IsValidNameInsured]
    --        ,[COITitle]
    --        ,[LastUpdateDate]
    --        ,[VendorExpiryDaysInAdvance]
    --        ,[VendorExpiryEndDate]
    --        ,[TenantExpiryDaysInAdvance]
    --        ,[TenantExpiryEndDate]
    --        ,[NotifyEmployeeDaysInAdvance]
    --        ,[NotifyEmployeeEndDate]
    --        ,[COIContactInformation]
    --        ,[COIAttachmentId]
    --        ,[ContractAttachmentId]
    --        ,[IsCustomVendorContact]
    --        ,[VendorContactName]
    --        ,[VendorContactEmail]
    --        ,[VendorContactPhone]
    --        ,[NotifyDaysInAdvance]
    --        ,[NotifyEndDate]
    --        ,[NotifyDaysInAdvance2]
    --        ,[NotifyEmployeeDaysInAdvance2]
    --        ,[IncludeRequirements]
    --        ,[tmpCOIID]
    --        ,[EmployeeIdSignature]
    --        ,[IsCompliant]
    --        ,[CompanyId]
	-- 	   ,'+@ToCompany+' as cs_companyid

    -- From tempCOI


        PRINT 'Insert CoiCompliance';
        SET @sql = '
Select next value for seq_CoiCompliance over (order by p.CoiComplianceid) as NewCoiComplianceId , p.*
into dbo.TempCoiCompliance
from '+@Fromserver+'.'+@FromDB+'.dbo.CoiCompliance p
where p.COIId in (Select COIId from dbo.tempCOI)
and p.ComplianceRuleID in (
SELECT ComplianceRuleid FROM '+@Fromserver+'.'+@FromDB+'.dbo.CoiComplianceRuleCompany
where Companyid = '  + @FromCompany +  ')
--order by p.CoiComplianceid

Update TempCoiCompliance
set COIId = -3

update TempCoiCompliance
set
	COIId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCoiCompliance vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.CoiCompliance Fvd on vd.CoiComplianceId = Fvd.CoiComplianceId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.COIId = ulk.oldid
where
	vd.COIId = -3 and ulk.tablename = ''COI''


--update TempCoiCompliance
--set [ComplianceRuleId] = [NewId]
--from mapping with (nolock)
--where tablename = ''ComplianceRule'' and [ComplianceRuleId]id = fromid
--and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

select * from TempCoiCompliance where ComplianceRuleId > 5
Delete from TempCoiCompliance where ComplianceRuleId > 5

if exists (select * from tempCoiCompliance) Begin

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''CoiCompliance'',
        	''CoiComplianceId'',
        	CoiComplianceId,
        	NewCoiComplianceId
        From
           	dbo.tempCoiCompliance

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempCoiCompliance''
  ,@ToTable =''Coicompliance''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
-- Insert '+@ToDB+'.dbo.CoiCompliance
--         (
--         [CoiComplianceId]
--         ,[CoiId]
--         ,[ComplianceRuleId]
--         ,[Status]
--         ,[Notes]
--         ,[tmpCoiComplianceId]
-- 		,coicompliance_cs_companyid
-- 		)
--     Select
-- 		[NewCoiComplianceId]
--         ,[CoiId]
--         ,[ComplianceRuleId]
--         ,[Status]
--         ,[Notes]
--         ,[tmpCoiComplianceId]
-- 		,'+@ToCompany+' as cs_companyid
--     From tempCoiCompliance

        PRINT 'Insert COIPolicy';
        SET @sql = '

Select next value for seq_COIPolicy over (order by p.COIPolicyid) as NewCoiPolicyId, p.*
into dbo.TempCOIPolicy
from '+@Fromserver+'.'+@FromDB+'.dbo.COIPolicy p
where p.COIId in (Select COIId from dbo.tempCOI)
--order by p.COIPolicyid

Update TempCOIPolicy
set COIId = -3

update TempCOIPolicy
set
	COIId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCOIPolicy vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COIPolicy Fvd on vd.COIPolicyId = Fvd.COIPolicyId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.COIId = ulk.oldid
where
	vd.COIId = -3 and ulk.tablename = ''COI''

update TempCOIPolicy
set PolicyTypeId = [NewId]
from mapping with (nolock)
where tablename = ''PolicyType'' and PolicyTypeid = fromid
and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+'

if exists (select * from tempCOIPolicy) Begin


     Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''COIPolicy'',
        	''COIPolicyId'',
        	COIPolicyId,
        	NewCOIPolicyId
        From
           	dbo.tempCOIPolicy

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempCOIPolicy''
  ,@ToTable =''COIPolicy''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.COIPolicy
    --     (
    --       [COIPolicyId]
    --        ,[COIId]
    --        ,[PolicyTypeId]
    --        ,[StartDate]
    --        ,[ExpiryDate]
    --        ,[Notes]
    --        ,[Compliance]
    --        ,[ComplianceNotes]
    --        ,[Amount]
    --        ,[Minimum]
	-- 	   ,[tmpCOIPolicyID]
	-- 	   ,coipolicy_cs_companyid
	-- 	   )

    -- Select
	-- 		[NewCOIPolicyId]
    --        ,[COIId]
    --        ,[PolicyTypeId]
    --        ,[StartDate]
    --        ,[ExpiryDate]
    --        ,[Notes]
    --        ,[Compliance]
    --        ,[ComplianceNotes]
    --        ,[Amount]
    --        ,[Minimum]
    --        ,[tmpCOIPolicyID]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From tempCOIPolicy


        PRINT 'Insert COIHistory';
        SET @sql = '
Select next value for seq_COIHistory over (order by p.COIHistoryid) as newCOIHistoryId, p.*
into dbo.TempCOIHistory
from '+@Fromserver+'.'+@FromDB+'.dbo.COIHistory p
where p.COIId in (Select COIId from dbo.tempCOI)
--order by p.COIHistoryid

Update TempCOIHistory
set COIId = -3


Update TempCOIHistory
set EmployeeIdEnteredBy = -3
Where EmployeeIdEnteredBy is not null and EmployeeIdEnteredBy <> 0

Update TempCOIHistory
set
    COIAttachmentId = -3
where
    COIAttachmentId is not null and COIAttachmentId <> 0

update TempCOIHistory
set
	COIId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCOIHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COIHistory Fvd on vd.COIHistoryId = Fvd.COIHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.COIId = ulk.oldid
where
	vd.COIId = -3 and ulk.tablename = ''COI''

update TempCOIHistory
set
	EmployeeIdEnteredBy = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCOIHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COIHistory Fvd on vd.COIHistoryId = Fvd.COIHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdEnteredBy = ulk.oldid
where
	vd.EmployeeIdEnteredBy = -3 and ulk.tablename = ''Employee''


update TempCOIHistory
set
	COIAttachmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCOIHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COIHistory Fvd on vd.COIHistoryId = Fvd.COIHistoryId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.COIAttachmentId = ulk.oldid
where
	vd.COIAttachmentId = -3 and ulk.tablename = ''FileAttachment''

	select * from TempCOIHistory where [EmployeeIdEnteredBy] not in 
	(Select employeeid from employee)

	Update TempCOIHistory set EmployeeIdEnteredBy = 0 where [EmployeeIdEnteredBy] not in 
	(Select employeeid from employee)

if exists (select * from tempCOIHistory) Begin


     Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''COIHistory'',
        	''COIHistoryId'',
        	COIHistoryId,
        	NewCOIHistoryId
        From
           	dbo.tempCOIHistory


---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempCOIHistory''
  ,@ToTable =''COIHistory''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.COIHistory
    --     (
    --       [COIHistoryId]
    --        ,[COIId]
    --        ,[EmployeeIdEnteredBy]
    --        ,[COIAttachmentId]
    --        ,[COIHistoryEvent]
    --        ,[DateCreated]
    --        ,[tmpCOIHistoryID]
	-- 	   ,coihistory_cs_companyid
    --      )
    -- Select

    --      [NewCOIHistoryId]
    --        ,[COIId]
    --        ,[EmployeeIdEnteredBy]
    --        ,[COIAttachmentId]
    --        ,[COIHistoryEvent]
    --        ,[DateCreated]
    --        ,[tmpCOIHistoryID]
	-- 	   ,'+@ToCompany+' as cs_companyid
    -- From tempCOIHistory


        PRINT 'Insert COIAttachment';
        SET @sql = '
Select next value for seq_COIAttachment over (order by p.COIAttachmentId) as NewCOIAttachmentId, p.*
into dbo.TempCOIAttachment
from '+@Fromserver+'.'+@FromDB+'.dbo.COIAttachment p
where p.COIId in (Select COIId from dbo.tempCOI)


Update TempCOIAttachment
set COIId = -3
where COIID is not null

Update tempCOIAttachment
set
	AttachmentID = -3
where
Attachmentid is not null

update TempCOIAttachment
set
	AttachmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCOIAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COIAttachment Fvd on vd.COIAttachmentid = Fvd.COIAttachmentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.AttachmentId = ulk.oldid
where
	vd.AttachmentId = -3 and ulk.tablename = ''FileAttachment''


update TempCOIAttachment
set
	COIId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempCOIAttachment vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COIAttachment Fvd on vd.COIAttachmentid = Fvd.COIAttachmentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.COIID = ulk.oldid
where
	vd.COIID = -3 and ulk.tablename = ''COI''



     Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''COIAttachment'',
        	''COIAttachmentId'',
        	COIAttachmentId,
        	NewCOIAttachmentId
        From
           	dbo.TempCOIAttachment

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempCOIAttachment''
  ,@ToTable =''COIAttachment''
  ,@CompanyId = '+@ToCompany+'


update COI
set
	COIAttachmentId = ulk.[NewId]
From
    '+@ToDB+'.dbo.COI as COI inner join  '+@ToDB+'.dbo.'+@lookup+' as ULK1 on COI.COIID = ULK1.[NewID]  inner join
	'+@ToDB+'.dbo.tempCOI vd with (nolock) on COI.tmpCOIID = vd.COIID 	inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.COI Fvd on vd.COIId = Fvd.COIId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.COIAttachmentId = ulk.oldid
where
	vd.COIAttachmentId = 0 and ulk.tablename = ''COIAttachment''     and ULK1.tablename=''COI''
       ';
        EXEC (@sql);
-- INSERT INTO '+@ToDB+'.[dbo].[COIAttachment]
--            (
-- 		   [COIAttachmentId]
--            ,[COIId]
--            ,[AttachmentId]
--            ,[IncludeInExpiryEmail]
--            ,[DateUpdated]
--            ,[tmpCOIAttachmentID]
--            ,[IncludeInRequirementsEmail]
-- 		   ,coiattachment_cs_companyid

-- 	)
--     Select [NewCOIAttachmentId]
--            ,[COIId]
--            ,[AttachmentId]
--            ,[IncludeInExpiryEmail]
--            ,[DateUpdated]
--            ,[tmpCOIAttachmentID]
--            ,[IncludeInRequirementsEmail]
-- 		   ,'+@ToCompany+' as cs_companyid
--          From TempCOIAttachment




        PRINT 'insert Message COI';
        SET @c1 = '
Select  NEXT VALUE for seq_Message over (order by a.MessageId) as newMessageId, a.*
into dbo.tempCOImessage
from '+@Fromserver+'.'+@FromDB+'.dbo.message a  inner join tempCOI  on tempCOI.COIId = a.COIId
where
a.Propertyid is null
or a.propertyid in (Select propertyid from tempProperty where propertyid is not null and propertyid <> 0)



if exists (select * from tempCOImessage) Begin



update tempCOImessage set RequestId = case when RequestId is null then RequestId else -3 end,
TenantId = case when tenantid is null then tenantid else  -3 end,
ContactId = case when contactid is null then contactid else  -3 end,
EmployeeIDFrom = case when EmployeeIdFrom is null then EmployeeIDFrom else -3 end,
EmployeeIDTo = case when EmployeeIDTo is null then EmployeeIdTo Else -3 end,
EmployeeIdUpdated = case when EmployeeIdUpdated is null then EmployeeIdUpdated Else -3 end,
EmployeeIdCreated =  case when EmployeeIdCreated is null then EmployeeIdCreated Else -3 end

update tempCOImessage set COIID =-3 where COIID is not null and COIID <> 0

update tempCOImessage set PropertyId =-3 where PropertyId is not null and PropertyId <> 0



update trm
set trm.PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.PropertyId = ulk.oldid
where
	trm.PropertyId = -3 and ulk.tablename = ''Property''

';
        SET @c2 = '
update trm
set trm.RequestId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.RequestId = ulk.oldid
where
	trm.RequestId = -3 and ulk.tablename = ''Request''

update trm
set trm.COIId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.COIId = ulk.oldid
where
	trm.COIId = -3 and ulk.tablename = ''COI''

update trm
set trm.TenantId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.TenantId = ulk.oldid

where
	trm.TenantId = -3 and ulk.tablename = ''Tenant''

update trm
set trm.ContactId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.ContactId = ulk.oldid

where
	trm.ContactId = -3 and ulk.tablename = ''Contact''

update trm
set trm.EmployeeIdFrom = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdFrom = ulk.oldid

where
	trm.EmployeeIdFrom = -3 and ulk.tablename = ''Employee''

update trm
set trm.EmployeeIdTo = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdTo = ulk.oldid

where
	trm.EmployeeIdTo = -3 and ulk.tablename = ''Employee''


update trm
set trm.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdUpdated = ulk.oldid
where
	trm.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''

update trm
set trm.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdCreated = ulk.oldid
where
	trm.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''

-----------


update trm
set trm.EmployeeIdFrom = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdFrom = ulk.oldid

where
	trm.EmployeeIdFrom = -3 and ulk.tablename = ''CommonEmployee''

update trm
set trm.EmployeeIdTo = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdTo = ulk.oldid

where
	trm.EmployeeIdTo = -3 and ulk.tablename = ''CommonEmployee''


update trm
set trm.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdUpdated = ulk.oldid
where
	trm.EmployeeIdUpdated = -3 and ulk.tablename = ''CommonEmployee''

update trm
set trm.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempCOImessage trm with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.message Ftrm on trm.MessageId = Ftrm.MessageId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on Ftrm.EmployeeIdUpdated = ulk.oldid
where
	trm.EmployeeIdCreated = -3 and ulk.tablename = ''CommonEmployee''


     Select
       *
    From
        dbo.tempCOImessage  where contactid not in (select newcontactid from tempcontact)  and contactid <>0

Select
        *
    From
        dbo.tempCOImessage  where contactid not in (select contactid from contact)  and contactid <> 0


	Update	dbo.tempCOImessage
	set Tenantid = null
	where tenantid not in (Select tenantid from tenant)

	Update	dbo.tempCOImessage
	set contactid = null
	where contactid not in (select newcontactid from tempcontact)  and contactid <>0



	Update	dbo.tempCOImessage
	set [EmployeeIdFrom] = null
	where [EmployeeIdFrom] not in (select employeeid from employee)  AND
	[EmployeeIdFrom] <>0


	Update	dbo.tempCOImessage
	set [EmployeeIdTo] = null
	where [EmployeeIdTo] not in (select employeeid from employee)  AND
	 [EmployeeIdTo] <>0


	Update	dbo.tempCOImessage
	set [EmployeeIdCreated] = null
	where [EmployeeIdCreated] not in (select employeeid from employee)  AND
	 [EmployeeIdCreated] <>0


	 Update	dbo.tempCOImessage
	set [EmployeeIdUpdated] = 0
	where [EmployeeIdUpdated] not in (select employeeid from employee)  AND
	 [EmployeeIdUpdated] <>0

-- If we copy COI, there is an update for COIID





	 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Message'',
        	''MessageId'',
        	MessageId,
        	newMessageId
        From
           	dbo.tempCOImessage

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempCOImessage''
  ,@ToTable =''Message''
  ,@CompanyId = '+@ToCompany+'


End
';
        EXEC (@c1+@c2);
--    insert '+@ToDB+'.dbo.Message
--     (
--       [MessageId]
--     ,[DiscriminatorType]
--     ,[CoiId]
--     ,[PropertyId]
--     ,[RequestId]
--     ,[WorkOrderId]
--     ,[TenantId]
--     ,[ContactId]
--     ,[EmployeeIdFrom]
--     ,[EmployeeIdTo]
--     ,[IsMessageRead]
--     ,[MessageIdParent]
--     ,[DateSent]
--     ,[DateReceived]
--     ,[FromAddress]
--     ,[ToAddress]
--     ,[CcAddress]
--     ,[Subject]
--     ,[Body]
--     ,[tmpInboxid]
--     ,[MessageType]
--     ,[IsMessageDeleted]
--     ,[EmployeeIdCreated]
--     ,[DateCreated]
--     ,[tmpMessageID]
--    -- ,[DateCreatedUtc]
--     ,[Category]
-- 	,[ManuallyClassified]
-- 	,[EmployeeIdUpdated]
-- 	,[DateUpdated]
-- 	,message_cs_companyid



--     )
--     Select
-- 	 [NewMessageId]
--     ,[DiscriminatorType]
--     ,[CoiId]
--     ,[PropertyId]
--     ,[RequestId]
--     ,[WorkOrderId]
--     ,[TenantId]
--     ,[ContactId]
--     ,[EmployeeIdFrom]
--     ,[EmployeeIdTo]
--     ,[IsMessageRead]
--     ,Null as [MessageIdParent]
--     ,[DateSent]
--     ,[DateReceived]
--     ,[FromAddress]
--     ,[ToAddress]
--     ,[CcAddress]
--     ,[Subject]
--     ,[Body]
--     ,[tmpInboxid]
--     ,[MessageType]
--     ,[IsMessageDeleted]
--     ,[EmployeeIdCreated]
--     ,[DateCreated]
--     ,MessageID as [tmpMessageID]
--    -- ,[DateCreatedUtc]
--     ,[Category]
-- 	,[ManuallyClassified]
-- 	,[EmployeeIdUpdated]
-- 	,[DateUpdated]
-- 	,'+@ToCompany+' as cs_companyid
--     From
--         dbo.tempCOImessage

--print @@rowcount

        PRINT 'Insert MessageAttachement COI';
        SET @sql = 'SELECT NULL AS newMessageid, NULL AS newAttachmentid, ma.* into dbo.tempMessageAttachmentCOI from
               '+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment ma  inner join tempCOImessage tm  on ma.Messageid = tm.Messageid




Update ma
set
	NewMessageid = ulk.[NewID]
From
    '+@ToDB+'.dbo.tempMessageAttachmentCOI ma with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment Fma on ma.MessageID = fma.MessageID
	and Fma.AttachmentID = ma.AttachmentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fma.MessageId = ulk.oldid
where
   ulk.tablename = ''Message''

Update ma
set
	NewAttachmentID = ulk.[NewID]
From
    '+@ToDB+'.dbo.tempMessageAttachmentCOI ma with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.MessageAttachment Fma on ma.MessageID = fma.MessageID
	and Fma.AttachmentID = ma.AttachmentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fma.AttachmentID = ulk.oldid
where
	 ulk.tablename = ''FileAttachment''

 select * from tempMessageAttachmentCOI where newmessageid is null or newAttachmentid is null

delete from tempMessageAttachmentCOI where newmessageid is null or newAttachmentid is null


	insert '+@ToDB+'.dbo.[MessageAttachment]
           (
           [MessageId]
           ,[AttachmentId]
           ,[tmpMessageAttachmentID]
		   ,messageattachment_cs_companyid
           )

       select  [NewMessageId]
           ,[NewAttachmentId]
           ,[tmpMessageAttachmentID]
		   ,'+@ToCompany+' as cs_companyid
        From tempMessageAttachmentCOI
    ';
        EXEC (@sql);
    END;
    ------------Insert COI End
    ---- Insert Doc
    IF @DoDoc = 1
             BEGIN
        PRINT 'Insert DocumentRegion';
        SET @sql = '

Select Next value for seq_DocumentRegion over (order by p.DocumentRegionId) as newDocumentRegionId , p.*
into dbo.tempDocumentRegion
from
    '+@Fromserver+'.'+@FromDB+'.dbo.DocumentRegion p
where p.companyid = '+@FromCompany+'
--order by p.DocumentRegionId

Update tempDocumentRegion
set
    CompanyId = '+@ToCompany+'
Alter table  tempDocumentRegion
add newDocumentRegionId1 int

Update tempDocumentRegion
set newDocumentRegionId1 = newDocumentRegionId

Update tempDocumentRegion
set
    NewDocumentRegionId1 = D.DocumentRegionId
from
    tempDocumentRegion tD inner join
    '+@Fromserver+'.'+@ToDB+'.dbo.DocumentRegion D  on tD.CompanyId = D.CompanyId and
    td.DocumentRegionName = D.DocumentRegionname

If exists ( select * from tempDocumentRegion) begin
     Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''DocumentRegion'',
        	''DocumentRegionId'',
        	DocumentRegionId,
        	NewDocumentRegionId1
        From
           	dbo.TempDocumentRegion

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempDocumentRegion''
  ,@ToTable =''DocumentRegion''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.DocumentRegion
    --     (
    --         DocumentRegionId,
    --         CompanyId,
    --         DocumentRegionName
	-- 		,documentregion_cs_companyid
    --     )
    -- Select
	-- 		NewDocumentRegionId1,
    --         CompanyId,
    --         DocumentRegionName
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempDocumentRegion


        PRINT 'Insert Document';
        SET @sql = '
Select next value for seq_Document over (order by D.DocumentId) as newDocumentId, D.*
into dbo.TempDocument
from
'+@Fromserver+'.'+@FromDB+'.dbo.Document D  inner join
'+@Fromserver+'.'+@FromDB+'.dbo.Property p  on p.Propertyid = D.Propertyid
where p.propertyid in '+@FromProperty+' and p.companyid in ('+@FromCompany+')
--order by D.DocumentId


Update TempDocument
set
    DocumentRegionId = -3
where
    DocumentRegionId <> 0

Update TempDocument
set
    PropertyId = -3
Where
    PropertyId <> 0

Update TempDocument
set
    employeeIdCreated = -3
Where
    employeeIdCreated is not null and employeeIdCreated <> 0

Update TempDocument
set
    employeeIdUpdated = -3
Where
    employeeIdUpdated is not null and employeeIdUpdated <> 0


update TempDocument
set
	DocumentRegionId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempDocument vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Document Fvd on vd.DocumentId = Fvd.DocumentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.DocumentRegionId = ulk.oldid
where
	vd.DocumentRegionId = -3 and ulk.tablename = ''DocumentRegion''

update TempDocument
set
	PropertyId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempDocument vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Document Fvd on vd.DocumentId = Fvd.DocumentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.PropertyId = ulk.oldid
where
	vd.PropertyId = -3 and ulk.tablename = ''Property''


update TempDocument
set
	EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempDocument vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Document Fvd on vd.DocumentId = Fvd.DocumentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdCreated = ulk.oldid
where
	vd.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''


update TempDocument
set
	EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempDocument vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.Document Fvd on vd.DocumentId = Fvd.DocumentId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdUpdated = ulk.oldid
where
	vd.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''



update t1
set
	DocumentIdMaster = t2.NewDocumentId
From TempDocument t1 inner join
TempDocument t2 on t1.DocumentIdMaster = t2.DocumentId
where
    T1.DocumentIdMaster is not null and T1.DocumentIdMaster <> 0


update t1
set
	DocumentIdPublished = t2.NewDocumentId
From TempDocument t1 inner join
TempDocument t2 on t1.DocumentIdPublished = t2.DocumentId
where
    T1.DocumentIdPublished is not null and T1.DocumentIdPublished <> 0


if exists (select * from tempDocument) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''Document'',
        	''DocumentId'',
        	DocumentId,
        	newDocumentId
        From
           	dbo.tempDocument

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempDocument''
  ,@ToTable =''Document''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.Document
    --     (
    --         DocumentId,
    --         DocumentRegionId,
    --         PropertyId,
    --         DocumentIdMaster,
    --         DocumentIdPublished,
    --         DocumentStatus,
    --         DocumentType,
    --         DocumentTitle,
    --         EmployeeIdCreated,
    --         DateCreated,
    --         EmployeeIdUpdated,
    --         DateUpdated
	-- 		,document_cs_companyid
    --     )
    -- Select
	-- 		NewDocumentId,
    --         DocumentRegionId,
    --         PropertyId,
    --         DocumentIdMaster,
    --         DocumentIdPublished,
    --         DocumentStatus,
    --         DocumentType,
    --         DocumentTitle,
    --         EmployeeIdCreated,
    --         DateCreated,
    --         EmployeeIdUpdated,
    --         DateUpdated
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempDocument


        PRINT 'Insert DocumentSection';
        SET @sql = '
Select next value for seq_DocumentSection over (order by D.SectionId) as newSectionId, D.*
into dbo.TempDocumentSection
from
'+@Fromserver+'.'+@FromDB+'.dbo.DocumentSection D
where D.DocumentId in (Select DocumentId from tempDocument)
--order by D.SectionId



Update TempDocumentSection
set
    DocumentId = -3
where
    DocumentId <> 0

Update TempDocumentSection
set
    employeeIdCreated = -3
Where
    employeeIdCreated is not null and employeeIdCreated <> 0

Update TempDocumentSection
set
    employeeIdUpdated = -3
Where
    employeeIdUpdated is not null and employeeIdUpdated <> 0


update TempDocumentSection
set
	DocumentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempDocumentSection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.DocumentSection Fvd on vd.SectionId = Fvd.SectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.DocumentId = ulk.oldid
where
	vd.DocumentId = -3 and ulk.tablename = ''Document''



update TempDocumentSection
set
	EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempDocumentSection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.DocumentSection Fvd on vd.SectionId = Fvd.SectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdCreated = ulk.oldid
where
	vd.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''


update TempDocumentSection
set
	EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempDocumentSection vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.DocumentSection Fvd on vd.SectionId = Fvd.SectionId inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdUpdated = ulk.oldid
where
	vd.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''



update t1
set
	SectionIdMaster = t2.NewSectionId
From TempDocumentSection t1 inner join
TempDocumentSection t2 on t1.SectionIdMaster = t2.SectionId
where
     t1.SectionIdMaster is not null and t1.SectionIdMaster <> 0

update t1
set
	SectionIdParent = t2.NewSectionId
From TempDocumentSection t1 inner join
TempDocumentSection t2 on t1.SectionIdParent = t2.SectionId
where
   t1.SectionIdParent is not null and t1.SectionIdParent <> 0

update t1
set
	SectionIdPublished = t2.NewSectionId
From TempDocumentSection t1 inner join
TempDocumentSection t2 on t1.SectionIdPublished = t2.SectionId
where
   t1.SectionIdPublished is not null and t1.SectionIdPublished <> 0

if exists (select * from tempDocumentSection) Begin
    Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''DocumentSection'',
        	''SectionId'',
        	SectionId,
        	newSectionId
        From
           	dbo.tempDocumentSection

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempDocumentSection''
  ,@ToTable =''DocumentSection''
  ,@CompanyId = '+@ToCompany+'

End
';
        EXEC (@sql);
    -- Insert '+@ToDB+'.dbo.DocumentSection
    --     (
    --         SectionId,
    --         DocumentId,
    --         SectionIdMaster,
    --         SectionIdParent,
    --         SectionIdPublished,
    --         IsMandatory,
    --         IsOverrideable,
    --         IsHidden,
    --         IsOverridden,
    --         IsMarkDeleted,
    --         SectionSequence,
    --         SectionTitle,
    --         SectionContent,
    --         EmployeeIdCreated,
    --         DateCreated,
    --         EmployeeIdUpdated,
    --         DateUpdated
	-- 		,DocumentSection_cs_companyid
    --     )
    -- Select
	-- 		NewSectionId,
    --         DocumentId,
    --         SectionIdMaster,
    --         SectionIdParent,
    --         SectionIdPublished,
    --         IsMandatory,
    --         IsOverrideable,
    --         IsHidden,
    --         IsOverridden,
    --         IsMarkDeleted,
    --         SectionSequence,
    --         SectionTitle,
    --         SectionContent,
    --         EmployeeIdCreated,
    --         DateCreated,
    --         EmployeeIdUpdated,
    --         DateUpdated
	-- 		,'+@ToCompany+' as cs_companyid
    -- From tempDocumentSection


        PRINT 'Insert DocumentHistory';  --Multi Keys for PK
        SET @sql = '
Select  D.*
into dbo.TempDocumentHistory
from
'+@Fromserver+'.'+@FromDB+'.dbo.DocumentHistory D
where D.DocumentId in (Select DocumentId from tempDocument)
and D.SectionId in (Select SectionId from tempDocumentSection)

Update TempDocumentHistory
set
    DocumentId = D.NewDocumentId
from
    TempDocumentHistory DH inner join tempDocument D on DH.DocumentID = D.DocumentId
where
    DH.DocumentId <> 0 and DH.DocumentId is not null

Update TempDocumentHistory
set
    SectionId = D.NewSectionId
from
    TempDocumentHistory DH inner join tempDocumentSection D on DH.SectionID = D.SectionId
where
    DH.SectionId <> 0 and DH.SectionId is not null

Update TempDocumentHistory
set
    employeeIdCreated = -3
Where
    employeeIdCreated is not null and employeeIdCreated <> 0


update TempDocumentHistory
set
	EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.TempDocumentHistory vd with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.DocumentHistory Fvd on vd.SectionId = Fvd.SectionId and
    vd.DocumentId =Fvd.DocumentId and
    vd.DocumentHistoryEvent = Fvd.DocumentHistoryEvent and
    vd.DateCreated = Fvd.DateCreated
    inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on FVD.EmployeeIdCreated = ulk.oldid
where
	vd.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''



if exists (select * from tempDocumentHistory) Begin


---- merge data
  -- EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  --,@ToSchema =''dbo''
  --,@FromTable =''tempDocumentHistory''
  --,@ToTable =''DocumentHistory''
  --,@CompanyId = '+@ToCompany+'

     Insert '+@ToDB+'.dbo.DocumentHistory
         (
             DocumentId,
             SectionId,
             DocumentHistoryEvent,
             DocumentHistoryDetail,
             EmployeeIdCreated,
             DateCreated
	 		,documenthistory_cs_companyid
         )
     Select
	 		DocumentId,
             SectionId,
             DocumentHistoryEvent,
             DocumentHistoryDetail,
             EmployeeIdCreated,
             DateCreated
	 		,'+@ToCompany+' as cs_companyid
     From tempDocumentHistory

End
';
        EXEC (@sql);
    END;
    -- Insert DOC End

    ---- Insert FileDocument Begin
    IF @DoFileDoc = 1
             BEGIN
        PRINT 'Insert FileDocumentProperty';
        SET @sql = '
Select r.*
into dbo.tempFileDocumentProperty
from
    '+@Fromserver+'.'+@FromDB+'.dbo.FileDocumentProperty r  inner join
    '+@Fromserver+'.'+@FromDB+'.dbo.Property p  on p.Propertyid = r.Propertyid
where p.propertyid in '+@FromProperty+' and p.companyid = '+@FromCompany+'


update tempFileDocumentProperty
set Propertyid = NewPropertyId
From tempFileDocumentProperty inner join
tempProperty on tempFileDocumentProperty.PropertyId = tempProperty.PropertyId

';
        EXEC (@sql);

        PRINT 'Insert FileDocument';
        SET @sql = '

Select
next value for seq_FileDocument over (order by p.FileDocumentid) as NewFileDocumentID, 
p.*
into dbo.TempFileDocument
from '+@Fromserver+'.'+@FromDB+'.dbo.view_FileDocument p
--from '+@Fromserver+'.'+@FromDB+'.dbo.FileDocument p
where p.FileDocumentId in (Select FileDocumentID from dbo.tempFileDocumentProperty)
--order by p.FileDocumentid


update tempFileDocument
set tempFileDocument.CategoryID = mapping.[NewId]
from
    mapping with (nolock)
where
    tempFileDocument.CategoryID = mapping.fromId
    and FromCompany = '+@FromCompany+' and ToCompany = '+@ToCompany+' and
    mapping.tablename = ''Category''


Update tempFileDocument
set [EmployeeIdCreated]   = -3 where EmployeeIDCreated <> 0

Update tempFileDocument
set [EmployeeIdUpdated]   = -3 where EmployeeIdUpdated <> 0


update r
set r.EmployeeIdUpdated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempFileDocument r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.FileDocument Fr on r.FileDocumentID = Fr.FileDocumentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.EmployeeIdUpdated = ulk.oldid
where
	r.EmployeeIdUpdated = -3 and ulk.tablename = ''Employee''



update r
set r.EmployeeIdCreated = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempFileDocument r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.FileDocument Fr on r.FileDocumentID = Fr.FileDocumentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.EmployeeIdUpdated = ulk.oldid
where
	r.EmployeeIdCreated = -3 and ulk.tablename = ''Employee''



Update tempFileDocument
set [EmployeeIdCreated]   = 0 where EmployeeIDCreated = -3

Update tempFileDocument
set [EmployeeIdUpdated]   = 0 where EmployeeIdUpdated = -3




print ''insertFileDocumentattachment''


Select next value for seq_FileDocumentAttachment over (order by p.FileDocumentAttachmentId) as newFileDocumentAttachmentId,
p.*
into dbo.TempFileDocumentAttachment
from '+@Fromserver+'.'+@FromDB+'.dbo.view_FileDocumentAttachment p
--from '+@Fromserver+'.'+@FromDB+'.dbo.FileDocumentAttachment p
where p.FileDocumentAttachmentID in (Select FileDocumentAttachmentID from dbo.tempFileDocument)


 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''FileDocumentAttachment'',
        	''FileDocumentAttachmentId'',
        	FileDocumentAttachmentId,
        	NewFileDocumentAttachmentId
        From
           	dbo.tempFileDocumentAttachment

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempFileDocumentAttachment''
  ,@ToTable =''FileDocumentAttachment''
  ,@CompanyId = '+@ToCompany+'
  
-- INSERT INTO [dbo].[FileDocumentAttachment]
--            (
-- 		   FileDocumentAttachmentId,
-- 		   [FileData],
-- 		   [tmpFileDcoumentAttachmentID]
-- 		   ,filedocumentattachment_cs_companyid
-- 		   )

-- 	select
-- 	newFileDocumentAttachmentId,
-- 	 [FileData],
-- 	[tmpFileDcoumentAttachmentID]
-- 	,'+@ToCompany+' as cs_companyid
-- 	 From tempFileDocumentAttachment


update r
set r.FileDocumentAttachmentId = ulk.[NewId]
From
	'+@ToDB+'.dbo.tempFileDocument r with (nolock) inner join
	'+@Fromserver+'.'+@FromDB+'.dbo.FileDocument Fr on r.FileDocumentID = Fr.FileDocumentID inner join
	'+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on fr.FileDocumentAttachmentId = ulk.oldid
where
	 ulk.tablename = ''FileDocumentAttachment''


 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''FileDocument'',
        	''FileDocumentId'',
        	FileDocumentId,
        	NewFileDocumentId
        From
           	dbo.tempFileDocument

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempFileDocument''
  ,@ToTable =''FileDocument''
  ,@CompanyId = '+@ToCompany+'


Update tempFileDocumentProperty
Set
    FileDocumentID = ulk.[NewId]
from
    tempFileDocumentProperty inner join '+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on tempFileDocumentProperty.FileDocumentID = ulk.oldid
where
	ulk.tablename = ''FileDocument''



Insert '+@ToDB+'.dbo.FileDocumentProperty
    (
    FileDocumentID,
    PropertyId
	,filedocumentproperty_cs_companyid
    )
Select
    FileDocumentID,
    PropertyId
	,'+@ToCompany+' as cs_companyid
from
    tempFileDocumentProperty

';

        select @sql
        EXEC (@sql);
-- INSERT INTO [dbo].[FileDocument]
--            (
-- 		   [FileDocumentId]
--            ,[IsActive]
--            ,[CategoryId]
--            ,[EmployeeIdCreated]
--            ,[EmployeeIdUpdated]
--            ,[DateCreatedUtc]
--            ,[DateUpdatedUtc]
--            ,[FileTitle]
--            ,[FileUrl]
--            ,[FileDescription]
--            ,[ShowInTsi]
--            ,[ExpiryDate]
--            ,[FileDocumentAttachmentId]
--            ,[FileName]
--            ,[FileSize]
-- 		   ,filedocument_cs_companyid
-- 		   ,isResized
-- 		   )
-- 		select
-- 			[NewFileDocumentId]
--            ,[IsActive]
--            ,[CategoryId]
--            ,[EmployeeIdCreated]
--            ,[EmployeeIdUpdated]
--            ,[DateCreatedUtc]
--            ,[DateUpdatedUtc]
--            ,[FileTitle]
--            ,[FileUrl]
--            ,[FileDescription]
--            ,[ShowInTsi]
--            ,[ExpiryDate]
--            ,[FileDocumentAttachmentId]
--            ,[FileName]
--            ,[FileSize]
-- 		   ,'+@ToCompany+' as cs_companyid
-- 		   ,isResized
-- 		from
-- 			tempFileDocument



        PRINT 'insert FileDocumentEmployeeRole';
        SET @sql = '
Select
p.*
into dbo.tempFileDocumentEmployeeRole
from '+@Fromserver+'.'+@FromDB+'.dbo.FileDocumentEmployeeRole p
where p.FileDocumentId in (Select FileDocumentID from dbo.tempFileDocument)


Update tempFileDocumentEmployeeRole
Set
    FileDocumentID = ulk.[NewId]
from
    tempFileDocumentEmployeeRole inner join '+@ToDB+'.dbo.'+@lookup+' ulk with (nolock) on tempFileDocumentEmployeeRole.FileDocumentID = ulk.oldid
where
	ulk.tablename = ''FileDocument''

Insert '+@ToDB+'.dbo.FileDocumentEmployeeRole
    (
    FileDocumentID,
    Roleid
	,filedocumentemployeerole_cs_companyid
    )
Select
    FileDocumentID,
    Roleid
	,'+@ToCompany+' as cs_companyid
from
    tempFileDocumentEmployeeRole

';
        EXEC (@sql);
    END;
    ---- Insert FileDocument End

    PRINT 'insert PropertyReportConfig';
    SET @sql = '
Select  next value for seq_PropertyReportConfig over (order by p.PropertyReportId) as newPropertyReportId , p.*
into dbo.TempPropertyReportConfig
from '+@Fromserver+'.'+@FromDB+'.dbo.PropertyReportConfig p
where p.propertyid in '+@FromProperty+'
--order by p.propertyid

Update tpr
set
	PropertyID = tp.NewPropertyID
From TempPropertyReportConfig tpr inner join tempProperty tp on tpr.PropertyID = tp.PropertyID

Update TempPropertyReportConfig
set reportid = 273

 Insert  dbo.'+@lookup+'
        (
        	TableName,
        	ColumnName,
        	OldId,
        	[NewId]
        )
        Select
        	''PropertyReportConfig'',
        	''PropertyReportConfigId'',
        	PropertyReportId,
        	NewPropertyReportId
        From
           	dbo.TempPropertyReportConfig

---- merge data
   EXECUTE  [gpsAdmin].[Admin_PropertyMoveTable] @FromSchema =''dbo'' 
  ,@ToSchema =''dbo''
  ,@FromTable =''tempPropertyReportConfig''
  ,@ToTable =''PropertyReportConfig''
  ,@CompanyId = '+@ToCompany+'

';
    EXEC (@sql);
-- INSERT INTO [dbo].[PropertyReportConfig]
--            (
-- 		   [PropertyReportId]
--            ,[PropertyId]
--            ,[ReportId]
--            ,[BillingCycleStartDay]
--            ,[BasedOnDate]
-- 		   ,ShowAllBilling
-- 		   ,propertyreportconfig_cs_companyid
-- 		   )

-- select [NewPropertyReportId]
--            ,[PropertyId]
--            ,[ReportId]
--            ,[BillingCycleStartDay]
--            ,[BasedOnDate]
-- 		   ,ShowAllBilling
-- 		   ,'+@ToCompany+' as cs_companyid
-- from TempPropertyReportConfig

    print 'Insert QRSToken'

    SET @sql = '
	  select next value for v3_Common.[dbo].[seq_QRSToken] as newQRSTokenId,
	  ' + @ToCompany +' as newCompanyid,
	  ulk.[newid] as newworkorderid,
	  qrs.*

into dbo.TempQRSToken
from '+@FromServer+'.v3_common.dbo.QRSToken qrs inner join ' + @ToDB+'.dbo.'+@lookup+ ' ulk on qrs.workorderid = ulk.oldid
where ulk.tablename =''workorder''
and companyId = '+@FromCompany+'

if exists (Select * from TempQRSToken)
begin
	INSERT INTO v3_Common.[dbo].[QRSToken]
           ([QRSTokenId]
           ,[Token]
           ,[LoadDate]
           ,[ExpireDate]
           ,[CompanyId]
           ,[WorkOrderId])
	select
	        [newQRSTokenId]
           ,[Token]
           ,[LoadDate]
           ,[ExpireDate]
           ,[newCompanyid]
           ,[newworkorderid]
		from TempQRSToken

end

';
    print (@sql)

    EXEC (@sql);



    ---- Reset status
    SET @sql = '
		 
EXEC v3_Common.dbo.SetUserContext  ' + @fromcompany + '
update '+@FromServer+'.'+@FromDB+'.dbo.Property
set IsActiveProperty = 0 , ExternalPropertyCode=''''
--,IntegrationIdentifier = Newid()
where propertyid in '+@FromProperty+'
and Propertyid <> 0 


update '+@FromServer+'.'+@FromDB+'.dbo.Service
set IsActiveService = 0
where propertyid in '+@FromProperty+'
and propertyid <> 0 

update '+@FromServer+'.'+@FromDB+'.dbo.Building
set IsActiveBuilding = 0 --,IntegrationIdentifier = Newid()
,DateToDelete = dateadd(dd,90,getdate()),ActiveUntil=dbo.fnzerohour(Getdate()+1)
where propertyid in '+@FromProperty+'
and buildingid <> 0 

delete wv
From
    '+@FromServer+'.'+@FromDB+'.dbo.WorkOrderVirtual wv inner join
    '+@FromServer+'.'+@FromDB+'.dbo.schedule sc on wv.ScheduleId = sc.ScheduleId inner join
    '+@FromServer+'.'+@FromDB+'.dbo.equipment eq on eq.equipmentid = sc.equipmentid inner join
    '+@FromServer+'.'+@FromDB+'.dbo.area a on a.areaid = eq.areaid inner join
    '+@FromServer+'.'+@FromDB+'.dbo.building b on b.buildingid = a.buildingid
where propertyid in '+@FromProperty+'
and propertyid <> 0 

update a
set IsActiveArea = 0 --,IntegrationIdentifier = Newid()
from '+@FromServer+'.'+@FromDB+'.dbo.area  a inner join '+@FromServer+'.'+@FromDB+'.dbo.Building b
on b.buildingid =  a.buildingid
where b.propertyid in '+@FromProperty+'
and  a.areaid <> 0 


update '+@FromServer+'.'+@FromDB+'.dbo.Schedule
set IsActiveSchedule = 0
where ScheduleId in (select OldId from '+@lookup+' with (nolock) where tablename = ''schedule''
and oldid <> 0  )

update '+@FromServer+'.'+@FromDB+'.dbo.equipment
set IsActiveEquipment = 0
where equipmentid in (select OldId from '+@lookup+' with (nolock) where tablename = ''equipment'' 
and oldid <> 0 )

update '+@FromServer+'.'+@FromDB+'.dbo.task
set IsActiveTask = 0
where taskid in (select OldId from '+@lookup+' with (nolock) where tablename = ''task'' 
and oldid <> 0 )
and PropertyId <> 0

update '+@FromServer+'.'+@FromDB+'.dbo.building
set IsActiveBuilding = 0 
where buildingid in (select OldId from '+@lookup+' with (nolock) where tablename = ''building''
and oldid <> 0  )

update '+@FromServer+'.'+@FromDB+'.dbo.Tenant
set IsActiveTenant = 0 --,IntegrationIdentifier = Newid()
where TenantId in (select OldId from '+@lookup+' with (nolock) where tablename = ''Tenant''
and oldid <> 0 
 )
and BasePropertyID in  '+@FromProperty+'

update '+@FromServer+'.'+@FromDB+'.dbo.contact
set
	Username = ContactId,
	ContactEmailAddress = '''',
	IsActiveContact = 0 --, IntegrationIdentifier = Newid()
where ContactId in (select OldId from '+@lookup+' with (nolock) where tablename = ''contact''
and oldid <> 0  )


';
    EXEC (@sql);

     EXEC v3_Common.dbo.SetUserContext   @Tocompany 
    -------------------
     IF EXISTS
          (
              SELECT *
     FROM
         (
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              SELECT ERSRegionID AS ID
             FROM ERS_Market
             WHERE ERSRegionID = -3
         UNION
             SELECT MarketID AS ID
             FROM ERS_PropertySet
             WHERE MarketID = -3
         UNION
             SELECT PropertySetId AS ID
             FROM Property
             WHERE PropertySetId = -3
         UNION
             SELECT RegionId AS ID
             FROM Property
             WHERE RegionId = -3
         UNION
             SELECT VendorTypeId AS ID
             FROM Vendor
             WHERE VendorTypeId = -3
         UNION
             SELECT EmployeeId AS ID
             FROM Vendor
             WHERE EmployeeId = -3
         UNION
             SELECT PropertyId AS ID
             FROM building
             WHERE PropertyId = -3
         UNION
             SELECT BuildingId AS ID
             FROM area
             WHERE BuildingId = -3
         UNION
             SELECT BasePropertyId AS ID
             FROM Tenant
             WHERE BasePropertyId = -3
         UNION
             SELECT TenantId AS ID
             FROM Department
             WHERE TenantId = -3
         UNION
             SELECT BaseTenantId AS ID
             FROM contact
             WHERE BaseTenantId = -3
         UNION
             SELECT BaseAreaId AS ID
             FROM contact
             WHERE BaseAreaId = -3
         UNION
             SELECT DepartmentId AS ID
             FROM contact
             WHERE DepartmentId = -3
         UNION
             SELECT ContactId AS ID
             FROM Reservation
             WHERE ContactId = -3
         UNION
             SELECT TenantId AS ID
             FROM Reservation
             WHERE TenantId = -3
         --UNION
         --SELECT
         --    PropertyId AS ID
         --FROM
         --    Reservation
         --WHERE
         --    PropertyId = -3
         UNION
             SELECT ContactIdEnteredBy AS ID
             FROM Reservation
             WHERE ContactIdEnteredBy = -3
         UNION
             SELECT EmployeeIdEnteredBy AS ID
             FROM Reservation
             WHERE EmployeeIdEnteredBy = -3
         UNION
             SELECT AreaId AS ID
             FROM Resource
             WHERE AreaId = -3
         UNION
             SELECT TenantId AS ID
             FROM Lease
             WHERE TenantId = -3
         UNION
             SELECT BuildingId AS ID
             FROM Lease
             WHERE BuildingId = -3
         UNION
             SELECT TenantId AS ID
             FROM TenantAreaLease
             WHERE TenantId = -3
         UNION
             SELECT AreaId AS ID
             FROM TenantAreaLease
             WHERE AreaId = -3
         UNION
             SELECT LeaseId AS ID
             FROM TenantAreaLease
             WHERE LeaseId = -3
         UNION
             SELECT ContactId AS ID
             FROM ContactAddressBook
             WHERE ContactId = -3
         UNION
             SELECT ContactIdAdministrator AS ID
             FROM ContactInvited
             WHERE ContactIdAdministrator = -3
         UNION
             SELECT BaseTenantId AS ID
             FROM ContactInvited
             WHERE BaseTenantId = -3
         UNION
             SELECT BuildingId AS ID
             FROM Request
             WHERE BuildingId = -3
         UNION
             SELECT TenantId AS ID
             FROM Request
             WHERE TenantId = -3
         UNION
             SELECT ContactId AS ID
             FROM Request
             WHERE ContactId = -3
         UNION
             SELECT AreaId AS ID
             FROM Request
             WHERE AreaId = -3
         UNION
             SELECT RequestTypeId AS ID
             FROM Request
             WHERE RequestTypeId = -3
         UNION
             SELECT TradeId AS ID
             FROM Request
             WHERE TradeId = -3
         UNION
             SELECT EmployeeIdOwner AS ID
             FROM Request
             WHERE EmployeeIdOwner = -3
         UNION
             SELECT EmployeeIdRequested AS ID
             FROM Request
             WHERE EmployeeIdRequested = -3
         UNION
             SELECT EmployeeIdCreated AS ID
             FROM Request
             WHERE EmployeeIdCreated = -3
         UNION
             SELECT EmployeeIdUpdated AS ID
             FROM Request
             WHERE EmployeeIdUpdated = -3
         UNION
             SELECT RequestId AS ID
             FROM Reqhistory
             WHERE RequestId = -3
         UNION
             SELECT EmployeeIdCreated AS ID
             FROM Reqhistory
             WHERE EmployeeIdCreated = -3
         UNION
             SELECT EmployeeIdUpdated AS ID
             FROM Reqhistory
             WHERE EmployeeIdUpdated = -3
         UNION
             SELECT BuildingId AS ID
             FROM Workorder
             WHERE BuildingId = -3
         UNION
             SELECT AreaId AS ID
             FROM Workorder
             WHERE AreaId = -3
         UNION
             SELECT TradeId AS ID
             FROM Workorder
             WHERE TradeId = -3
         UNION
             SELECT RequestTypeId AS ID
             FROM Workorder
             WHERE RequestTypeId = -3
         UNION
             SELECT RequestId AS ID
             FROM Workorder
             WHERE RequestId = -3
         UNION
             SELECT TenantId AS ID
             FROM Workorder
             WHERE TenantId = -3
         UNION
             SELECT ContactId AS ID
             FROM Workorder
             WHERE ContactId = -3
         UNION
             SELECT LeaseId AS ID
             FROM Workorder
             WHERE LeaseId = -3
         UNION
             SELECT EmployeeIdAssigned AS ID
             FROM Workorder
             WHERE EmployeeIdAssigned = -3
         UNION
             SELECT EmployeeIdOwner AS ID
             FROM Workorder
             WHERE EmployeeIdOwner = -3
         UNION
             SELECT EmployeeIdRequested AS ID
             FROM Workorder
             WHERE EmployeeIdRequested = -3
         UNION
             SELECT ReservationId AS ID
             FROM Workorder
             WHERE ReservationId = -3
         UNION
             SELECT ResourceId AS ID
             FROM Workorder
             WHERE ResourceId = -3
         UNION
             SELECT EmployeeIdUpdated AS ID
             FROM Workorder
             WHERE EmployeeIdUpdated = -3
         UNION
             SELECT EmployeeIdCreated AS ID
             FROM Workorder
             WHERE EmployeeIdCreated = -3
         UNION
             SELECT EquipmentId AS ID
             FROM Workorder
             WHERE EquipmentId = -3
         UNION
             SELECT ScheduleId AS ID
             FROM Workorder
             WHERE ScheduleId = -3
         UNION
             SELECT WorkOrderId AS ID
             FROM WoHistory
             WHERE WorkOrderId = -3
         UNION
             SELECT WoTaskId AS ID
             FROM WoHistory
             WHERE WoTaskId = -3
         UNION
             SELECT EmployeeId AS ID
             FROM WoHistory
             WHERE EmployeeId = -3
         UNION
             SELECT EmployeeIdCreated AS ID
             FROM WoHistory
             WHERE EmployeeIdCreated = -3
         UNION
             SELECT EmployeeIdUpdated AS ID
             FROM WoHistory
             WHERE EmployeeIdUpdated = -3
         UNION
             SELECT PropertyId AS ID
             FROM Message
             WHERE PropertyId = -3
         UNION
             SELECT RequestId AS ID
             FROM Message
             WHERE RequestId = -3
         UNION
             SELECT WorkOrderId AS ID
             FROM Message
             WHERE WorkOrderId = -3
         UNION
             SELECT TenantId AS ID
             FROM Message
             WHERE TenantId = -3
         UNION
             SELECT ContactId AS ID
             FROM Message
             WHERE ContactId = -3
         UNION
             SELECT EmployeeIdFrom AS ID
             FROM Message
             WHERE EmployeeIdFrom = -3
         UNION
             SELECT EmployeeIdTo AS ID
             FROM Message
             WHERE EmployeeIdTo = -3
         UNION
             SELECT RequestTypeId AS ID
             FROM Service
             WHERE RequestTypeId = -3
         UNION
             SELECT PropertyId AS ID
             FROM Service
             WHERE PropertyId = -3
         UNION
             SELECT TenantId AS ID
             FROM Service
             WHERE TenantId = -3
         UNION
             SELECT WorkOrderId AS ID
             FROM WoService
             WHERE WorkOrderId = -3
         UNION
             SELECT ServiceId AS ID
             FROM WoService
             WHERE ServiceId = -3
         UNION
             SELECT EquipmentClassId AS ID
             FROM Equipment
             WHERE EquipmentClassId = -3
         UNION
             SELECT AreaId AS ID
             FROM Equipment
             WHERE AreaId = -3
         UNION
             SELECT EquipmentId AS ID
             FROM Schedule
             WHERE EquipmentId = -3
         UNION
             SELECT EmployeeIdAssigned AS ID
             FROM Schedule
             WHERE EmployeeIdAssigned = -3
         UNION
             SELECT RequestId AS ID
             FROM Schedule
             WHERE RequestId = -3
         UNION
             SELECT PropertyId AS ID
             FROM task
             WHERE PropertyId = -3
         UNION
             SELECT TradeId AS ID
             FROM task
             WHERE TradeId = -3
         UNION
             SELECT ScheduleId AS ID
             FROM Schedtask
             WHERE ScheduleId = -3
         UNION
             SELECT TaskId AS ID
             FROM Schedtask
             WHERE TaskId = -3
         UNION
             SELECT TaskId AS ID
             FROM Taskline
             WHERE TaskId = -3
         UNION
             SELECT ScheduleId AS ID
             FROM scheditem
             WHERE ScheduleId = -3
         UNION
             SELECT WorkOrderId AS ID
             FROM wotask
             WHERE WorkOrderId = -3
         UNION
             SELECT TaskId AS ID
             FROM wotask
             WHERE TaskId = -3
         UNION
             SELECT TradeId AS ID
             FROM wotask
             WHERE TradeId = -3
         UNION
             SELECT WorkOrderId AS ID
             FROM woitem
             WHERE WorkOrderId = -3
         UNION
             SELECT WoTaskId AS ID
             FROM Wotaskline
             WHERE WoTaskId = -3
         UNION
             SELECT ScheduleId AS ID
             FROM WorkOrderVirtual
             WHERE ScheduleId = -3
         UNION
             SELECT EmployeeIdAssigned AS ID
             FROM WorkOrderVirtual
             WHERE EmployeeIdAssigned = -3
         UNION
             SELECT SchedTaskId AS ID
             FROM WorkOrderVirtual
             WHERE SchedTaskId = -3
         UNION
             SELECT visitTypeID AS ID
             FROM Visit
             WHERE visitTypeID = -3
         UNION
             SELECT VendorID AS ID
             FROM Visit
             WHERE VendorID = -3
         UNION
             SELECT ContactIdEnteredBy AS ID
             FROM Visit
             WHERE ContactIdEnteredBy = -3
         UNION
             SELECT EmployeeIdEnteredBy AS ID
             FROM Visit
             WHERE EmployeeIdEnteredBy = -3
         UNION
             SELECT TenantIDHost AS ID
             FROM Visit
             WHERE TenantIDHost = -3
         UNION
             SELECT ContactIDHost AS ID
             FROM Visit
             WHERE ContactIDHost = -3
         UNION
             SELECT AreaIDdestination AS ID
             FROM Visit
             WHERE AreaIDdestination = -3
         UNION
             SELECT PropertyID AS ID
             FROM VisitType
             WHERE Propertyid = -3
         UNION
             SELECT visitID AS ID
             FROM Visitor
             WHERE VisitID = -3
         UNION
             SELECT EmployeeIdCheckedInBy AS ID
             FROM Visitor
             WHERE EmployeeIdCheckedInBy = -3
         UNION
             SELECT EmployeeIdCheckedOutBy AS ID
             FROM Visitor
             WHERE EmployeeIdCheckedOutBy = -3
         UNION
             SELECT EmployeeIdBadgePrintedBy AS ID
             FROM Visitor
             WHERE EmployeeIdBadgePrintedBy = -3
         UNION
             SELECT EmployeeIdUpdated AS ID
             FROM Estimate
             WHERE EmployeeIDUpdated = -3
         UNION
             SELECT EmployeeIdCreated AS ID
             FROM Estimate
             WHERE EmployeeIDCreated = -3
         UNION
             SELECT RequestID AS ID
             FROM Estimate
             WHERE RequestID = -3
         UNION
             SELECT EstimateID AS ID
             FROM EstimateHistory
             WHERE EstimateID = -3
         UNION
             SELECT ContactID AS ID
             FROM EstimateHistory
             WHERE ContactID = -3
         UNION
             SELECT EmployeeID AS ID
             FROM EstimateHistory
             WHERE EmployeeID = -3
         UNION
             SELECT EmployeeIDUpdated AS ID
             FROM EstimateHistory
             WHERE EmployeeIDUpdated = -3
         UNION
             SELECT EmployeeIDCreated AS ID
             FROM EstimateHistory
             WHERE EmployeeIDCreated = -3
         UNION
             SELECT EstimateID AS ID
             FROM EstimateService
             WHERE EstimateID = -3
         UNION
             SELECT ServiceID AS ID
             FROM EstimateService
             WHERE ServiceID = -3
         UNION
             SELECT EmployeeIDUpdated AS ID
             FROM EstimateService
             WHERE EmployeeIDUpdated = -3
         UNION
             SELECT EmployeeIDCreated AS ID
             FROM EstimateService
             WHERE EmployeeIDCreated = -3
              ) a
          )
              BEGIN
         --PRINT '-3 Found rolled back';
         SELECT *
         FROM ERS_Market
         WHERE ERSRegionID = -3;
         SELECT *
         FROM ERS_PropertySet
         WHERE MarketID = -3;
         SELECT *
         FROM Property
         WHERE PropertySetId = -3;
         SELECT *
         FROM Property
         WHERE RegionId = -3;
         SELECT *
         FROM Vendor
         WHERE VendorTypeId = -3;
         SELECT *
         FROM Vendor
         WHERE EmployeeId = -3;
         SELECT *
         FROM building
         WHERE PropertyId = -3;
         SELECT *
         FROM area
         WHERE BuildingId = -3;
         SELECT *
         FROM Tenant
         WHERE BasePropertyId = -3;
         SELECT *
         FROM Department
         WHERE TenantId = -3;
         SELECT *
         FROM contact
         WHERE BaseTenantId = -3;
         SELECT *
         FROM contact
         WHERE BaseAreaId = -3;
         SELECT *
         FROM contact
         WHERE DepartmentId = -3;
         SELECT *
         FROM Reservation
         WHERE ContactId = -3;
         SELECT *
         FROM Reservation
         WHERE TenantId = -3;
         SELECT *
         FROM Reservation
         WHERE ContactIdEnteredBy = -3;
         SELECT *
         FROM Reservation
         WHERE EmployeeIdEnteredBy = -3;
         SELECT *
         FROM Resource
         WHERE AreaId = -3;
         SELECT *
         FROM Lease
         WHERE TenantId = -3;
         SELECT *
         FROM Lease
         WHERE BuildingId = -3;
         SELECT *
         FROM TenantAreaLease
         WHERE TenantId = -3;
         SELECT *
         FROM TenantAreaLease
         WHERE AreaId = -3;
         SELECT *
         FROM TenantAreaLease
         WHERE LeaseId = -3;
         SELECT *
         FROM ContactAddressBook
         WHERE ContactId = -3;
         SELECT *
         FROM ContactInvited
         WHERE ContactIdAdministrator = -3;
         SELECT *
         FROM ContactInvited
         WHERE BaseTenantId = -3;
         SELECT *
         FROM Request
         WHERE BuildingId = -3;
         SELECT *
         FROM Request
         WHERE TenantId = -3;
         SELECT *
         FROM Request
         WHERE ContactId = -3;
         SELECT *
         FROM Request
         WHERE AreaId = -3;
         SELECT *
         FROM Request
         WHERE RequestTypeId = -3;
         SELECT *
         FROM Request
         WHERE TradeId = -3;
         SELECT *
         FROM Request
         WHERE EmployeeIdOwner = -3;
         SELECT *
         FROM Request
         WHERE EmployeeIdRequested = -3;
         SELECT *
         FROM Request
         WHERE EmployeeIdCreated = -3;
         SELECT *
         FROM Request
         WHERE EmployeeIdUpdated = -3;
         SELECT *
         FROM Reqhistory
         WHERE RequestId = -3;
         SELECT *
         FROM Reqhistory
         WHERE EmployeeIdCreated = -3;
         SELECT *
         FROM Reqhistory
         WHERE EmployeeIdUpdated = -3;
         SELECT *
         FROM Workorder
         WHERE BuildingId = -3;
         SELECT *
         FROM Workorder
         WHERE AreaId = -3;
         SELECT *
         FROM Workorder
         WHERE TradeId = -3;
         SELECT *
         FROM Workorder
         WHERE RequestTypeId = -3;
         SELECT *
         FROM Workorder
         WHERE RequestId = -3;
         SELECT *
         FROM Workorder
         WHERE TenantId = -3;
         SELECT *
         FROM Workorder
         WHERE ContactId = -3;
         SELECT *
         FROM Workorder
         WHERE LeaseId = -3;
         SELECT *
         FROM Workorder
         WHERE EmployeeIdAssigned = -3;
         SELECT *
         FROM Workorder
         WHERE EmployeeIdOwner = -3;
         SELECT *
         FROM Workorder
         WHERE EmployeeIdRequested = -3;
         SELECT *
         FROM Workorder
         WHERE ReservationId = -3;
         SELECT *
         FROM Workorder
         WHERE ResourceId = -3;
         SELECT *
         FROM Workorder
         WHERE EmployeeIdUpdated = -3;
         SELECT *
         FROM Workorder
         WHERE EmployeeIdCreated = -3;
         SELECT *
         FROM Workorder
         WHERE EquipmentId = -3;
         SELECT *
         FROM Workorder
         WHERE ScheduleId = -3;
         SELECT *
         FROM WoHistory
         WHERE WorkOrderId = -3;
         SELECT *
         FROM WoHistory
         WHERE WoTaskId = -3;
         SELECT *
         FROM WoHistory
         WHERE EmployeeId = -3;
         SELECT *
         FROM WoHistory
         WHERE EmployeeIdCreated = -3;
         SELECT *
         FROM WoHistory
         WHERE EmployeeIdUpdated = -3;
         SELECT *
         FROM Message
         WHERE PropertyId = -3;
         SELECT *
         FROM Message
         WHERE RequestId = -3;
         SELECT *
         FROM Message
         WHERE WorkOrderId = -3;
         SELECT *
         FROM Message
         WHERE TenantId = -3;
         SELECT *
         FROM Message
         WHERE ContactId = -3;
         SELECT *
         FROM Message
         WHERE EmployeeIdFrom = -3;
         SELECT *
         FROM Message
         WHERE EmployeeIdTo = -3;
         SELECT *
         FROM Service
         WHERE RequestTypeId = -3;
         SELECT *
         FROM Service
         WHERE PropertyId = -3;
         SELECT *
         FROM Service
         WHERE TenantId = -3;
         SELECT *
         FROM WoService
         WHERE WorkOrderId = -3;
         SELECT *
         FROM WoService
         WHERE ServiceId = -3;
         SELECT *
         FROM Equipment
         WHERE EquipmentClassId = -3;
         SELECT *
         FROM Equipment
         WHERE AreaId = -3;
         SELECT *
         FROM Schedule
         WHERE EquipmentId = -3;
         SELECT *
         FROM Schedule
         WHERE EmployeeIdAssigned = -3;
         SELECT *
         FROM Schedule
         WHERE RequestId = -3;
         SELECT *
         FROM task
         WHERE PropertyId = -3;
         SELECT *
         FROM task
         WHERE TradeId = -3;
         SELECT *
         FROM Schedtask
         WHERE ScheduleId = -3;
         SELECT *
         FROM Schedtask
         WHERE TaskId = -3;
         SELECT *
         FROM Taskline
         WHERE TaskId = -3;
         SELECT *
         FROM scheditem
         WHERE ScheduleId = -3;
         SELECT *
         FROM wotask
         WHERE WorkOrderId = -3;
         SELECT *
         FROM wotask
         WHERE TaskId = -3;
         SELECT *
         FROM wotask
         WHERE TradeId = -3;
         SELECT *
         FROM woitem
         WHERE WorkOrderId = -3;
         SELECT *
         FROM Wotaskline
         WHERE WoTaskId = -3;
         SELECT *
         FROM WorkOrderVirtual
         WHERE ScheduleId = -3;
         SELECT *
         FROM WorkOrderVirtual
         WHERE EmployeeIdAssigned = -3;
         SELECT *
         FROM WorkOrderVirtual
         WHERE SchedTaskId = -3;
         SELECT *
         FROM Visit
         WHERE visitTypeID = -3;
         SELECT *
         FROM Visit
         WHERE VendorID = -3;
         SELECT *
         FROM Visit
         WHERE ContactIdEnteredBy = -3;
         SELECT *
         FROM Visit
         WHERE EmployeeIdEnteredBy = -3;
         SELECT *
         FROM Visit
         WHERE TenantIDHost = -3;
         SELECT *
         FROM Visit
         WHERE ContactIDHost = -3;
         SELECT *
         FROM Visit
         WHERE AreaIDdestination = -3;
         SELECT *
         FROM VisitType
         WHERE Propertyid = -3;
         SELECT *
         FROM Visitor
         WHERE VisitID = -3;
         SELECT *
         FROM Visitor
         WHERE EmployeeIdCheckedInBy = -3;
         SELECT *
         FROM Visitor
         WHERE EmployeeIdCheckedOutBy = -3;
         SELECT *
         FROM Visitor
         WHERE EmployeeIdBadgePrintedBy = -3;
         SELECT *
         FROM Estimate
         WHERE EmployeeIDUpdated = -3;
         SELECT *
         FROM Estimate
         WHERE EmployeeIDCreated = -3;
         SELECT *
         FROM Estimate
         WHERE RequestID = -3;
         SELECT *
         FROM EstimateHistory
         WHERE EstimateID = -3;
         SELECT *
         FROM EstimateHistory
         WHERE ContactID = -3;
         SELECT *
         FROM EstimateHistory
         WHERE EmployeeID = -3;
         SELECT *
         FROM EstimateHistory
         WHERE EmployeeIDUpdated = -3;
         SELECT *
         FROM EstimateHistory
         WHERE EmployeeIDCreated = -3;
         SELECT *
         FROM EstimateService
         WHERE EstimateID = -3;
         SELECT *
         FROM EstimateService
         WHERE ServiceID = -3;
         SELECT *
         FROM EstimateService
         WHERE EmployeeIDUpdated = -3;
         SELECT *
         FROM EstimateService
         WHERE EmployeeIDCreated = -3;
        --ROLLBACK TRAN;
		throw 50015, N'-3 Found, Investigate in what table(s) happened.', 1;

        UPDATE V3_common.dbo.moveflag
                   SET
                       DateCompleted = GETDATE(),
                       IsMoved = 0,
                       IsRollback = 1
                 WHERE MoveId = @MoveId;
        RETURN;
    END;
    IF @@error = 0
             BEGIN
        PRINT 'Committed';
        --COMMIT TRAN;
        UPDATE V3_common.dbo.moveflag
                   SET
                       DateCompleted = GETDATE(),
                       IsMoved = 1,
                       IsRollback = 0
                 WHERE MoveId = @MoveId;
    END;
    --     ELSE
    --         BEGIN
    --    PRINT 'Rolled back';
    --    ROLLBACK TRAN;
    --    UPDATE V3_common.dbo.moveflag
    --               SET
    --                   DateCompleted = GETDATE(),
    --                   IsMoved = 0,
    --                   IsRollback = 1
    --             WHERE MoveId = @MoveId;
    --END;
    
    End Try 
    Begin Catch
        --SELECT 
        --ERROR_NUMBER() AS ErrorNumber,
        --ERROR_MESSAGE() AS ErrorMessage;

		   select
				 db_name() [DBName], 
				 suser_sname() [UserName], 
				 host_name() [HostName], 
				 @@SERVERNAME [Server Name], 				
				 error_number() [Error Number], 
				 error_message() [Error Message],
				 error_line() [Error Line] 



        PRINT 'Error happens';
        -- ROLLBACK TRAN;
        UPDATE V3_common.dbo.moveflag
                   SET
                       DateCompleted = GETDATE(),
                       IsMoved = 0,
                       IsRollback = 1
                 WHERE MoveId = @MoveId;
    End Catch;
    -- DECLARE deleteTemp CURSOR LOCAL
    --      FOR SELECT name
    -- FROM sysobjects
    -- WHERE name LIKE 'temp%'
    --     and Name<>'temp_Tyngsborough_contact_Import'
    --     AND xtype = 'U';
    -- OPEN deletetemp;
    -- FETCH NEXT FROM deletetemp INTO @name;
    -- WHILE @@fetch_status = 0
    --          BEGIN
    --     EXEC ('drop table '+@name+'');
    --     FETCH NEXT FROM deletetemp INTO @name;
    -- END;
    -- CLOSE deleteTemp;
    -- DEALLOCATE deletetemp;
    -- IF EXISTS
    --      (
    --          SELECT *
    -- FROM sysobjects
    -- WHERE TYPE = 'U'
    --     AND name = 'fep'
    --      )
    --          BEGIN
    --     DROP TABLE dbo.fep;
    -- END;
    -- IF EXISTS
    --      (
    --          SELECT *
    -- FROM sysobjects
    -- WHERE TYPE = 'U'
    --     AND name = 'tmpt'
    --      )
    --          BEGIN
    --     DROP TABLE tmpt;
    -- END;
    SET NOCOUNT OFF;
END;
GO
