/*
create schema GPSAdmin
CREATE TYPE dbo.PKListTableType AS TABLE 
(
    PrimaryKeyID int NOT NULL,
    PRIMARY KEY NONCLUSTERED (PrimaryKeyID)
)
go
create table TrackerMove (
fDB          varchar(128)
, tDB        varchar(128)
, fCompanyID varchar(128)
, tCompanyID varchar(128)
, fO         varchar(128)
, [tO]       varchar(128)
, fT         varchar(128)
, tT         varchar(128)
)
*/
create or alter function dbo.tvf_GetPK_Columns(
@s   varchar(128)
, @t varchar(128)
)
returns table
as
    return
    --with
    --    dup
    --as  (
    --    select
    --        kcu.TABLE_NAME
    --    from
    --        AngusDemo.INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
    --    where
    --        objectproperty(object_id(kcu.CONSTRAINT_SCHEMA + '.' + kcu.CONSTRAINT_NAME), 'IsPrimaryKey') = 1
    --        and kcu.CONSTRAINT_SCHEMA                                                                    = @s
    --        and kcu.TABLE_NAME                                                                           = @t
    --    group by
    --        kcu.TABLE_NAME
    --    having
    --        count(*) > 1
    --    )
    select
        kcu.TABLE_NAME
      , kcu.COLUMN_NAME
    from
        AngusDemo.INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
    --inner join dup on dup.TABLE_NAME = kcu.TABLE_NAME
    where
        objectproperty(object_id(kcu.CONSTRAINT_SCHEMA+'.'+kcu.CONSTRAINT_NAME), 'IsPrimaryKey') = 1
        and kcu.CONSTRAINT_SCHEMA = @s
        and kcu.TABLE_NAME = @t
go
-------------------------------------------------


create or alter procedure GPSAdmin.Admin_PropertyMoveTable(
@FromSchema  varchar(128)
, @ToSchema  varchar(128)
, @FromTable varchar(128)
, @ToTable   varchar(128)
, @CompanyID int
)
as
begin
    declare @s nvarchar(4000)
    declare @c varchar(128)
    declare @pkColumn varchar(128)
    declare @batchS varchar(8) = '100000'
    --declare @batchS varchar(8) = '100'
    declare @batch int = 100
    declare @fetch int = 0

    --
    select @s = N'select @c=count(*) From dbo.tvf_GetPK_Columns(@ToSchema,@ToTable)'
    exec sys.sp_executesql
        @s
      , N'@c int out, @ToSchema varchar(128), @ToTable varchar(128)'
      , @c out
      , @ToSchema
      , @ToTable
    if(@c <> 1)
    begin
        select
            @s = N'
'+          @FromSchema+N'.'+@FromTable+N'
Not programmed for PKs with more than 1 segment (yet).
ABORTING
--------------------------------------------------------------------------------
'
        raiserror(@s, 16, 1)
        return
    end
    select @s = N'select @pkColumn=COLUMN_NAME From dbo.tvf_GetPK_Columns(@ToSchema,@ToTable)'
    exec sys.sp_executesql
        @s
      , N'@pkColumn varchar(128) out, @ToSchema varchar(128), @ToTable varchar(128)'
      , @pkColumn out
      , @ToSchema
      , @ToTable
    --print @pkColumn
    print @FromSchema+N'.'+@FromTable

    --
    select
        @s = N'    
IF NOT EXISTS (
    SELECT 1 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = '''+@FromSchema+N''' and TABLE_NAME = '''+@FromTable+N'''
    AND COLUMN_NAME = ''mvIsDone''
)
BEGIN
alter table '+@FromSchema+N'.'+@FromTable+N' add mvIsDone int default 0 not null, mvPK int identity(1,1) not null
END'
    --print @s
    exec(@s)

    --
    declare @sqlCursor nvarchar(4000) = N'
declare cCursor cursor for
select
    COLUMN_NAME
from
    INFORMATION_SCHEMA.COLUMNS
where
    TABLE_SCHEMA = '''+@ToSchema+N''' and TABLE_NAME = '''+@ToTable+N'''
    and columnproperty(object_id(TABLE_SCHEMA + ''.'' + TABLE_NAME), COLUMN_NAME, ''IsComputed'') = 0 
order by
    ORDINAL_POSITION
'
    --print @sqlCursor
    exec(@sqlCursor)
    open cCursor
    fetch next from cCursor
    into
        @c
    select
        @s = N'
--declare @isThereMore int
declare @pk PKListTableType
insert into @pk
select top('+@batchS+N') mvPK 
from '+ @FromSchema+N'.'+@FromTable+N' ft
    --left join @pk it on ft.mvPK=it.PrimaryKeyID
    left join '+@ToSchema+N'.'+@ToTable+N' tt on ft.new'+@pkColumn+N'=tt.'+@pkColumn+N'
where 
    tt.'+@pkColumn+N' is null
    --and it.PrimaryKeyID is null
    and ft.mvIsDone=0
order by ft.new'+@pkColumn+N'

begin tran
begin try
    insert into '+@ToSchema+N'.'+@ToTable+N'
    select '
    --+ @c
    while(@fetch = 0)
    begin
        select
            @s = @s+N'
        '        +case
                       when @c = @pkColumn then 'new'+@pkColumn
                       when @c like '%CS_CompanyId' then convert(varchar(128), @CompanyID)
                       else @c
                  end
        fetch next from cCursor
        into
            @c
        select @fetch = @@fetch_status
        if(@fetch = 0)select @s = @s+N','
    end
    close cCursor
    deallocate cCursor
    select
        @s = @s+N'
    from 
        '    +@FromSchema+N'.'+@FromTable+N' ft
        inner join @pk       it on ft.mvPK = it.PrimaryKeyID
    where mvIsDone=0
    update
        '    +@FromSchema+N'.'+@FromTable+N'
    set
        mvIsDone = 1
    from
        '    +@FromSchema+N'.'+@FromTable+N' ft
        inner join @pk       it on ft.mvPK = it.PrimaryKeyID
        set @isThereMore = @@rowcount
    commit
end try
begin catch
    select * from @PK
    rollback;
    throw
end catch
'
    --print @s
    --
    declare @isThereMore int = 1
    while(@isThereMore > 0)
    begin
        exec sys.sp_executesql
            @s
          , N'@isThereMore int output'
          , @isThereMore output
    --set @isThereMore = iif(@@ROWCOUNT < @batch, 0, @isThereMore)
    end
end
go
--
