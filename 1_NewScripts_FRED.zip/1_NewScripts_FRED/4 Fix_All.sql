--before
Use v3Carter 
go 


SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
SET DEADLOCK_PRIORITY HIGH
GO
EXEC v3_Common.dbo.SetUserContext  1040
-- select * from e_MiamiCenter

Update ne
set
ne.isactiveemployee = oe.IsActiveEmployee
from v3Carter.dbo.employee ne 
inner join v3Carter.dbo.MoveMiamiCenter m on ne.employeeid = m.[newid] and m.tablename = 'employee'
inner join v3Carter.dbo.E_MiamiCenter oe on  m.oldid =oe.employeeid
where 1=1
go

/* -- turn on Subscribe to Ammouncements
UPDATE c
SET CanSubscribeToAnnouncement = 1
FROM v3Carter.dbo.contact c INNER JOIN v3Carter.dbo.MoveMiamiCenter m ON c.contactid = m.[newid]
AND m.tablename = 'contact' AND m.[newid] <> 0
*/

use v3Carter
GO

Update ne
set
    ne.TRDeviceAddress ='',
    ne.PMDeviceAddress ='',
    ne.TRCCEmailAddress ='',
    ne.NotifyEmailAddress ='',
	ne.[EmergencyEmail] = '',
	ne.[SubscriptionEmailAddress] = '',
	ne.TRDeviceType = 0,
	ne.PMDeviceType = 0,
	ne.TRDeviceTypeDescription = '',
	ne.PMDeviceTypeDescription = '',
	--ne.PrimaryEmailAddress ='',
	ne.IsActiveEmployee = 0
		
From 
    v3Carter.dbo.employee ne 
    inner join v3Carter.dbo.MoveMiamiCenter m on ne.employeeid = m.[newid] and m.tablename = 'employee'
	inner join v3Carter.dbo.E_MiamiCenter  oe on  m.oldid =oe.employeeid
where oe.iskeptuser = 0 
AND oe.IsVendor = 0

select * from E_MiamiCenter where isKeptUser =0
-- Keep old pass and user who cross mulitple properties

EXEC v3_Common.dbo.SetUserContext  5023 -- old companyid
Update v3Trizec.dbo.Employee
set
    v3Trizec.dbo.Employee.TRDeviceAddress =tmpEmp.TRDeviceAddress,
    v3Trizec.dbo.Employee.PMDeviceAddress =tmpEmp.PMDeviceAddress,
	--v3Trizec.dbo.Employee.PrimaryEmailAddress =tmpEmp.PrimaryEmailAddress,
    v3Trizec.dbo.Employee.TRCCEmailAddress =tmpEmp.TRCCEmailAddress,
    v3Trizec.dbo.Employee.NotifyEmailAddress =tmpEmp.NotifyEmailAddress,
	v3Trizec.dbo.Employee.[EmergencyEmail] = tmpEmp.[EmergencyEmail],
	v3Trizec.dbo.employee.[SubscriptionEmailAddress] = tmpEmp.[SubscriptionEmailAddress]
From 
    v3Trizec.dbo.employee 
	inner join v3Carter.dbo.E_MiamiCenter  tmpEmp on v3Trizec.dbo.employee.employeeid =tmpEmp.employeeid
Where
	tmpEmp.iskeptuser = 0
	AND tmpEmp.employeeid <> 0

/*



Update ne
set
ne.username = '',
ne.TRDeviceAddress = '',
ne.PMDeviceaddress = '',
ne.TRCCEmailAddress = '',
ne.NotifyEmailAddress = '',
ne.isactiveemployee = 0,
ne.Employeefirstname = '',
ne.EmployeeLastName = '',
ne.PrimaryEmailAddress ='',
TRDeviceType = 0,
PMDeviceType = 0

from v3Carter.dbo.employee ne inner join v3Carter.dbo.MoveMiamiCenter m on ne.employeeid = m.[newid]
and m.tablename = 'employee'
inner join v3Carter.dbo.E_MiamiCenter  oe on  m.oldid =oe.employeeid
where ne.isVendor = 0


-- Keep old pass and user who cross mulitple properties
Update v3Trizec.dbo.Employee
set
    v3Trizec.dbo.Employee.TRDeviceAddress =tmpEmp.TRDeviceAddress,
    v3Trizec.dbo.Employee.PMDeviceAddress =tmpEmp.PMDeviceAddress,
    v3Trizec.dbo.Employee.TRCCEmailAddress =tmpEmp.TRCCEmailAddress,
    v3Trizec.dbo.Employee.NotifyEmailAddress =tmpEmp.NotifyEmailAddress,
	v3Trizec.dbo.Employee.username =tmpEmp.username,
	v3Trizec.dbo.Employee.encryptedPassword =tmpEmp.encryptedPassword,
	v3Trizec.dbo.Employee.EmployeeFirstname =tmpEmp.EmployeeFirstname,
	v3Trizec.dbo.Employee.employeeLastname =tmpEmp.EmployeeLastname,
	v3Trizec.dbo.Employee.isactiveEmployee =tmpEmp.isactiveEmployee,
	v3Trizec.dbo.Employee.PrimaryEmailAddress = tmpEmp.PrimaryEmailAddress
From 
    v3Trizec.dbo.employee inner join v3Carter.dbo.E_MiamiCenter  tmpEmp on v3Trizec.dbo.employee.employeeid =tmpEmp.employeeid
where tmpEmp.IsVendor = 0

*/


--- Copy pass and user to new property

Update v3Trizec.dbo.Employee
set
    v3Trizec.dbo.Employee.username ='',
    v3Trizec.dbo.Employee.TRDeviceAddress ='',
    v3Trizec.dbo.Employee.PMDeviceAddress ='',
    v3Trizec.dbo.Employee.TRCCEmailAddress ='',
    v3Trizec.dbo.Employee.NotifyEmailAddress ='',
	v3Trizec.dbo.employee.TRDeviceType = 0,
	v3Trizec.dbo.employee.PMDeviceType = 0,
	--v3Trizec.dbo.Employee.PrimaryEmailAddress ='',
	v3Trizec.dbo.Employee.LearningId = 0 
From 
    v3Trizec.dbo.employee 
	inner join v3Carter.dbo.E_MiamiCenter  tmpEmp on v3Trizec.dbo.employee.employeeid =tmpEmp.employeeid
Where
	tmpEmp.iskeptuser = 1
	AND tmpEmp.IsVendor = 0


-------------------------------------	
EXEC v3_Common.dbo.SetUserContext  1040

Update ne
set
ne.username = oe.username
,ne.EncryptedPassword = oe.EncryptedPassword
,ne.TRDeviceAddress = oe.trdeviceaddress
,ne.PMDeviceaddress = oe.PMDeviceAddress
,ne.TRCCEmailAddress = oe.TRCCEmailAddress
,ne.NotifyEmailAddress = oe.NotifyEmailAddress
,ne.isactiveemployee = oe.IsActiveEmployee 
,ne.learningId = oe.learningId
--,ne.primaryemailaddress = oe.primaryemailaddress

from v3Carter.dbo.employee ne 
inner join v3Carter.dbo.MoveMiamiCenter m on ne.employeeid = m.[newid] and m.tablename = 'employee'
inner join v3Carter.dbo.E_MiamiCenter  oe on  m.oldid =oe.employeeid
where oe.iskeptuser = 1 
--AND oe.isVendor = 0 



Update ne
set
isactiveemployee = 0
from v3Carter.dbo.employee ne 
inner join v3Carter.dbo.MoveMiamiCenter m on ne.employeeid = m.[newid] and m.tablename = 'employee'
inner join v3Carter.dbo.E_MiamiCenter  oe on  m.oldid =oe.employeeid
where oe.iskeptuser = 0 
AND ne.IsVendor = 0 

-- Clean 
select * from employee where employeeid in (
select [newid] from moveMiamiCenter where tablename = 'employee'
and [newid] <> 0)
and roleid in (10,11)

Update employee 
set roleid = 5,
username = '',
isactiveEmployee = 0
where employeeid in (
select [newid] from moveMiamiCenter where tablename = 'employee'
and [newid] <> 0)
and roleid in (10,11)

--
--
--Update ne
--set
--ne.username = oe.username,
--ne.EncryptedPassword = oe.EncryptedPassword,
--ne.TRDeviceAddress = oe.trdeviceaddress,
--ne.PMDeviceaddress = oe.PMDeviceAddress,
--ne.TRCCEmailAddress = oe.TRCCEmailAddress,
--ne.NotifyEmailAddress = oe.NotifyEmailAddress,
--ne.isactiveemployee = oe.IsActiveEmployee
--from v3Carter.dbo.employee ne inner join v3Carter.dbo.MoveMiamiCenter m on ne.employeeid = m.[newid]
--and m.tablename = 'employee'
--inner join v3Carter.dbo.E_MiamiCenter  oe on  m.oldid =oe.employeeid
--where oe.iskeptuser = 1  and oe.trdeviceAddress not in (select trdeviceAddress from employee where trdeviceAddress <>'')


--
--Update ne
--set
--ne.username = oe.username,
--ne.EncryptedPassword = oe.EncryptedPassword,
--ne.TRDeviceAddress = oe.trdeviceaddress,
--ne.PMDeviceaddress = oe.PMDeviceAddress,
--ne.TRCCEmailAddress = oe.TRCCEmailAddress,
--ne.NotifyEmailAddress = oe.NotifyEmailAddress,
--ne.isactiveemployee = oe.IsActiveEmployee
--from v3Carter.dbo.employee ne inner join v3Carter.dbo.MoveMiamiCenter m on ne.employeeid = m.[newid]
--and m.tablename = 'employee'
--inner join v3Carter.dbo.E_MiamiCenter  oe on  m.oldid =oe.employeeid
--where oe.iskeptuser = 1 and oe.trdeviceaddress not in (Select trdeviceaddress from employee) 
--and oe.trdeviceaddress <>''
----
--
--Update ne
--set
--ne.username = '',
----ne.EncryptedPassword = '',
--ne.TRDeviceAddress = '',
--ne.PMDeviceaddress = '',
--ne.TRCCEmailAddress = '',
--ne.NotifyEmailAddress = '',
--ne.isactiveemployee = 0
--from v3Carter.dbo.employee ne inner join v3Carter.dbo.MoveMiamiCenter m on ne.employeeid = m.[newid]
--and m.tablename = 'employee'
--where m.[newid]  <>0

--select * from  v3Carter.dbo.MoveMiamiCenter where tablename = 'employee'
----Drop table tmpEmployee
--
--select * from property where propertyid in (19558,19559 )
--
---- Active
--Update Property
--set	
--isActiveProperty = 1
--where
--	PropertyID in
--(Select newid from moveMiamiCenter where tablename ='property' )
--and isactiveproperty = 0
--
--Update Building
--set	
--isActiveBuilding = 1
--where
--	BuildingID in
--(Select newid from moveMiamiCenter where tablename ='Building' and [newid] <>0 
--)
----select * from building where buildingid in 
----(Select newid from moveMiamiCenter where tablename ='Building')
----Select * from moveMiamiCenter where tablename ='Building'
--
--Update Area
--set
--	IsActiveArea = 1
--where
--	AreaID in
--(Select newid from moveMiamiCenter where tablename ='Area' and [newid] <>0  )
--
--
--Update Tenant
--set
--	IsactiveTenant = 1
--where 
--	tenantid in (select newid from moveMiamiCenter where tablename ='Tenant' and [newid] <>0 )
--
--
--
--Update Contact
--set
--	IsactiveContact = 1
--where 
--	Contactid in (select newid from moveMiamiCenter where tablename ='Contact' and [newid] <>0 )
--
--Update Service
--set
--	IsactiveService = 1
--where
--	ServiceID in (Select newid from MoveMiamiCenter where tablename ='Service' and [newid] <>0 )
--
--Update Schedule
--set
--	IsActiveSchedule = 1
--where
--	ScheduleID in
--(Select newid from moveMiamiCenter where tablename ='Schedule' and [newid] <>0 )
--
--
--Update Equipment
--set
--	IsActiveEquipment = 1
--where
--	EquipmentID in
--(Select newid from moveMiamiCenter where tablename ='Equipment' and [newid] <>0 )
--
--
--Update Task
--set
--	IsActiveTask = 1
--where
--	TaskID in
--(Select newid from moveMiamiCenter where tablename ='Task' and [newid] <>0 )

--
--select * from employee where companyid = 1040 and roleid in (10,11)
--and isactiveEmployee = 1 order by employeeid
----------
--Insert employeeproperty
--(employeeid,propertyid, isdefaultProperty)
--select 58339,newid,0 from MoveMiamiCenter where tablename ='property'


Insert employeeproperty
(employeeid,propertyid, isdefaultProperty)

SELECT c.employeeid,c.propertyid, c.isdefaultProperty FROM  
(
SELECT  b.employeeid ,a.PropertyID,a.IsDefaultProperty FROM 
(select 0 AS employeeid , NEWID AS PropertyID,0 AS IsDefaultProperty from MoveMiamiCenter where tablename ='property') a cross JOIN 
(
select Employeeid from employee where companyid = 1040 and roleid in (10,11)
and isactiveEmployee = 1 --order by employeeid
) b
) c 
 LEFT OUTER JOIN dbo.EmployeeProperty ep
ON c.employeeid = ep.EmployeeId
AND c.propertyid = ep.PropertyId
WHERE ep.employeeid IS null
go

-- After

Use v3Carter
go

select * from moveMiamiCenter
where tablename = 'property'



select * from requesttype
where requestTypeid in 
(
select requestTypeID from RequestTypeProperty
where 
propertyid in
(
select [NewID] from moveMiamiCenter
where tablename = 'property'
)

)


EXEC v3_Common.dbo.SetUserContext  5023
Update v3Trizec.dbo.Property
set
	IsactiveProperty = 1
where
	PropertyID in (select oldid from moveMiamiCenter where tablename = 'Property')
and
	IsactiveProperty = 0


Update v3Trizec.dbo.Property
set
	IsactiveProperty = 0
where
	PropertyID in (select oldid from moveMiamiCenter where tablename = 'Property')
and
	IsactiveProperty = 1

--
--Update RequestTypeProperty
--set
--Status = 1,
--ShowInTsi = 1
--where 
--propertyid in
--(
--select [NewID] from moveMiamiCenter
--where tablename = 'property'
--)


EXEC v3_Common.dbo.SetUserContext  1040
Update RequestTypeProperty
set
Status = -1,
ShowInTsi = 0
where 
propertyid in
(
select [NewID] from moveMiamiCenter
where tablename = 'property'
)
and requestTypeID not in
(Select RequestTypeId from RequestType where companyid = 1040
and IsCorporateRequestType = 1)
and requestTypeID <> 0
--
----- Fix ARSWorkorder Table


select * from ArsWorkOrder
where workorderid in 
(

 select
            [NewID] as workOrderId 
 from moveMiamiCenter
where tablename = 'Workorder'
)

--------------------------

--update requesttypeproperty set status = 1 where requesttypeid = 0 and status <> 1
--RequestTypeID = 0 record is being created correctly for the target property. It should have Status = 1 and ShowInTsi = 0.


-- Fix username

update
    v3_Common..CommonEmployee
set
    UserName = z.UserName
  , EncryptedPassword = z.EncryptedPassword
from
    (select
        e.CompanyId
      , e.EmployeeId
      , e.UserName
      , e.EncryptedPassword
     from
        dbo.Employee as e
     where
        e.IsActiveEmployee = 1
        and e.UserName <> ''
    ) z
where
    z.EmployeeId = v3_Common.dbo.CommonEmployee.EmployeeId
    and z.CompanyId = v3_Common.dbo.CommonEmployee.CompanyId
and z.companyid = (select ToCompany from v3_Common..moveflag where moveId = 905)


-- Fix displayId


update
Request
set
    DisplayId = convert(varchar(14),RequestId)
  , SortId = convert(char(14),RequestId) where
       ( DisplayId = ''
        or SortId = '')
	and RequestId in (Select [NewID] as RequestID 
 from moveMiamiCenter
where tablename = 'Request'
)

declare @w int
select WorkOrderId into #tmpW from WorkOrder with(nolock) where
WorkorderId in 
(select [NewID] as workOrderId 
 from moveMiamiCenter
where tablename = 'Workorder'
) and 
( (SortId='' or SortId<>dbo.fnSortId (RequestId, ReservationId, WorkOrderId, WoSequence)) or (DisplayId='' or DisplayId<>dbo.fnDisplayId (RequestId, ReservationId, WorkOrderId, ScheduleId, WoSequence)))

declare zcursor cursor for 
select WorkOrderId from #tmpW 
open zcursor fetch next from zcursor into @w
while(@@fetch_status=0) begin
    print @w
    update dbo.WorkOrder set
       DisplayId = dbo.fnDisplayId (RequestId, ReservationId, WorkOrderId, ScheduleId, WoSequence),
       SortId = dbo.fnSortId (RequestId, ReservationId, WorkOrderId, WoSequence)
    where WorkOrderId=@w
    --waitfor delay '00:00:00.1'
    fetch next from zcursor into @w
end
close zcursor
deallocate zcursor
go


--- fix route

--declare @n varchar(8000)
--declare @s varchar(8000)

--declare SyncCursor cursor
--for
--select
--    name
--from
--    sys.databases
--where
--    is_in_standby = 0
--    and is_read_only = 0
--    and state = 0
--    and is_cleanly_shutdown = 0
--    and user_access_desc = 'MULTI_USER'
--    and name in ('v3Carter')
--order by
--    1
--open SyncCursor
--fetch next from SyncCursor into @n
--while @@fetch_STATUS = 0 
--    begin
----shrink
--        print '--Start------------'
--        print '[' + @n + ']'
--        set @s = '
--USE [' + @n + ']
--insert  into dbo.Route
--        (
--		RouteId
--       , BuildingId
--       , RequestTypeId
--       , ShiftId
--       , EmployeeId
--       , DispatchNote
--       , IsPropertyLevelRoute
--       , IsPropertyLevelNote
--        )
--        select
--			next value for seq_Route
--          , Building.BuildingId
--          , RequestType.RequestTypeId
--          , WorkHour.ShiftId
--          , 0 as Employeeid
--          , '''' as DispatchNote
--          , Property.IsPropertyLevelRoute
--          , Property.IsPropertyLevelRoute as IsPropertyLevelNote
--        from
--            Building
--        inner join Property on Building.PropertyId = Property.PropertyId
--        inner join WorkHour on Property.PropertyId = WorkHour.PropertyId
--        inner join RequestType on Property.CompanyId = RequestType.CompanyId
--        left outer join Route on RequestType.RequestTypeId = Route.RequestTypeId
--                                 and Building.BuildingId = Route.BuildingId
--                                 and WorkHour.ShiftId = Route.ShiftId
--        where
--            Route.ShiftId is null

--insert  into dbo.Route
--        (
--		 RouteId
--       , BuildingId
--       , RequestTypeId
--       , ShiftId
--       , EmployeeId
--       , DispatchNote
--       , IsPropertyLevelRoute
--       , IsPropertyLevelNote
--        )
--        select
--		 next value for
--                seq_Route
--          ,  a.BuildingId
--          , a.RequestTypeId
--          , a.ShiftId
--          , a.Employeeid
--          , a.DispatchNote
--          , a.IsPropertyLevelRoute
--          , a.IsPropertyLevelNote
--        from
--            (select
--                Building.BuildingId
--              , RequestType.RequestTypeId
--              , WorkHour.ShiftId
--              , 0 as Employeeid
--              , '''' as DispatchNote
--              , Property.IsPropertyLevelRoute
--              , Property.IsPropertyLevelRoute as IsPropertyLevelNote
--             from
--                Building
--             inner join Property on Building.PropertyId = Property.PropertyId
--             inner join RequestType on Property.CompanyId = RequestType.CompanyId
--             cross join WorkHour
--             where
--                WorkHour.ShiftId = 0
--            ) a
--        left outer join route r on a.BuildingId = r.BuildingId
--                                   and a.RequestTypeId = r.RequestTypeId
--                                   and a.ShiftId = r.ShiftId
--        where
--            r.buildingid is null

--insert  into dbo.Route
--        (
--		RouteId
--       , BuildingId
--       , RequestTypeId
--       , ShiftId
--       , EmployeeId
--       , DispatchNote
--       , IsPropertyLevelRoute
--       , IsPropertyLevelNote
--        )
--        select
--		 next value for
--                seq_Route
--          ,  a.BuildingId
--          , a.RequestTypeId
--          , a.ShiftId
--          , a.Employeeid
--          , a.DispatchNote
--          , a.IsPropertyLevelRoute
--          , a.IsPropertyLevelNote
--        from
--            (select
--                0 as Requesttypeid
--              , Building.BuildingId
--              , 0 as Employeeid
--              , '''' as DispatchNote
--              , Property.IsPropertyLevelRoute
--              , Property.IsPropertyLevelRoute as IsPropertyLevelNote
--              , WorkHour.ShiftId
--             from
--                Building
--             inner join Property on Building.PropertyId = Property.PropertyId
--             inner join WorkHour on Property.PropertyId = WorkHour.PropertyId
--            ) a
--        left outer join route r on a.buildingid = r.buildingid
--                                   and a.shiftid = r.shiftid
--                                   and a.requesttypeid = r.requesttypeid
--        where
--            r.shiftid is null

--insert  into dbo.Route
--        (
--		RouteId
--       , BuildingId
--       , RequestTypeId
--       , ShiftId
--       , EmployeeId
--       , DispatchNote
--       , IsPropertyLevelRoute
--       , IsPropertyLevelNote
--        )
--        select
--		 next value for
--                seq_Route
--          , a.BuildingId
--          , a.RequestTypeId
--          , a.ShiftId
--          , a.Employeeid
--          , a.DispatchNote
--          , a.IsPropertyLevelRoute
--          , a.IsPropertyLevelNote
--        from
--            (select distinct
--                0 as Requesttypeid
--              , Building.BuildingId
--              , 0 as Employeeid
--              , '''' as DispatchNote
--              , Property.IsPropertyLevelRoute
--              , Property.IsPropertyLevelRoute as IsPropertyLevelNote
--              , 0 as ShiftId
--             from
--                Building
--             inner join Property on Building.PropertyId = Property.PropertyId
--             inner join WorkHour on Property.PropertyId = WorkHour.PropertyId
--            ) a
--        left outer join route r on a.buildingid = r.buildingid
--                                   and a.shiftid = r.shiftid
--                                   and a.requesttypeid = r.requesttypeid
--        where
--            r.shiftid is null



--insert  into dbo.Escalation
--        (
--		 EscalationId
--       , PropertyId
--       , RequestTypeId
--       , MinutesEscalateOne
--       , MinutesEscalateTwo
--       , MinutesEscalateThree
--        )
--        select 
--		 next value for
--                seq_Escalation
--          ,  Property.PropertyId
--          , RequestType.RequestTypeId
--          , 0 as MinutesEscalateOne
--          , 0 as MinutesEscalateTwo
--          , 0 as MinutesEscalateThree
--        from
--            RequestType
--        inner join Company on RequestType.CompanyId = Company.CompanyId
--        inner join Property on Company.CompanyId = Property.CompanyId
--        left outer join Escalation on RequestType.RequestTypeId = Escalation.RequestTypeId
--                                      and Property.PropertyId = Escalation.PropertyId
--        where
--            Escalation.RequestTypeId is null

--declare
--    @shiftid int
--  , @propertyid int

--declare whinsert cursor local
--for
--select
--    Property.PropertyId
--from
--    Property
--left outer join WorkHour on Property.PropertyId = WorkHour.PropertyId
--where
--    WorkHour.PropertyId is null
--open whinsert
--fetch next from whinsert into @propertyid
--while @@FETCH_STATUS = 0 
--    begin
--        select
--            @shiftid = next VALUE for seq_WorkHour     
--        from
--            workhour
--        insert  workhour
--                (
--                 ShiftId
--               , PropertyId
--               , DowStart
--               , DowEnd
--               , TimeStart
--               , TimeEnd
--               , tmpBuildingId
--                )
--        values
--                (
--                 @shiftId
--               , @propertyId
--               , 1
--               , 5
--               , 540
--               , 1020
--               , -1
--                )
--        fetch next from whinsert into @propertyid
--    end

--close whinsert
--deallocate whinsert


--insert  into escalation
--        (
--		EscalationId
--        , PropertyId
--       , RequestTypeId
--       , MinutesEscalateOne
--       , MinutesEscalateTwo
--       , MinutesEscalateThree
--       , tmpBuildingId
--        )
--        select
--		 next value for
--                seq_Escalation
--          ,  PropertyId
--          , 0
--          , 0
--          , 0
--          , 0
--          , 0
--        from
--            Property
--        where
--            PropertyId not in (select
--                                PropertyId
--                               from
--                                Escalation
--                               where
--                                RequestTypeId = 0)




--'
--        exec (@s)
--        fetch next from SyncCursor into @n
--    end
--close SyncCursor
--deallocate SyncCursor


